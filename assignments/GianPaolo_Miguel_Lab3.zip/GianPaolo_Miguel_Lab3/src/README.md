# Medical Imaging ETL and Analytics Project

## 👥 Authors
- Gian Paolo Bulleddu
- Miguel Leal Fernández

---

## 📌 Context
This project is part of the **Data Engineering** course in the **Master in Artificial Intelligence**.

The goal is to design and implement an **ETL (Extract, Transform, Load) pipeline** for medical imaging data in **DICOM format**, integrating metadata into a **MongoDB data warehouse**. The system enables multi-dimensional analytical queries and visualizations, allowing insights into exposure parameters, patient demographics, acquisition protocols, and imaging device usage.

---

## 🛠️ Software and Tools
The following tools were used in the development of the project:

- **Python 3.x** — Core programming language for data extraction and transformation.
- **MongoDB** — NoSQL database used for storing the star-schema data warehouse.
- **PyMongo** — MongoDB driver for Python, managing database operations and queries.
- **pydicom** — For reading and parsing DICOM metadata and pixel data.
- **Pillow (PIL)** — For image processing and JPEG conversion.
- **Matplotlib / Pandas** — For visualization and data exploration.
- **Jupyter Notebook** — Used to execute, visualize, and document ETL pipelines and analytical queries.

---

## 📂 Data Source
The main dataset used in this project comes from **Kaggle**:  
[SIIM Medical Images Dataset](https://www.kaggle.com/datasets/kmader/siim-medical-images?select=dicom_dir)

This dataset includes **DICOM files** representing various medical imaging modalities. Each file contains detailed metadata such as patient demographics, study parameters, and imaging acquisition details. These files are processed through the ETL pipeline to populate the MongoDB collections: **PATIENT**, **IMAGE**, **PROTOCOL**, **STATION**, **DATE**, and **STUDY**.

### 🗂️ Download Instructions

1. Go to the dataset page on Kaggle (link above).  
2. Download the folder named **`dicom_dir`**.  
3. Place it inside your project directory as follows:

```
/src/
│
├── dicom_dir/          # DICOM files (.dcm)
├── output/
├── config_template.json
├── ImageDataProcessing.ipynb
├── README.md
└── requirements.txt
```

The ETL pipeline automatically scans this `/dicom_dir/` directory to extract, transform, and load metadata into MongoDB.

---

## 🔑 Configuration

To run this project, you need a personal configuration file with your **MongoDB credentials**.

1. Copy the template provided in this repo:  
   ```bash
   cp config_template.json config.json
   ```

2. Open `config.json` and replace the user and password with your own MongoDB details:  

   ```json
   {
     "mongo": {
       "host": "localhost",
       "port": 27017,
       "user": "your_username_here",
       "password": "your_password_here",
       "database": "medical_data"
     }
   }
   ```

---

## 🐍 Virtual Environment Setup

To keep dependencies isolated, each collaborator should create a personal virtual environment named **`venv_de3`**.

### Steps:

1. **Create the virtual environment and install the dependencies**
   ```bash
   python3 -m venv venv_de3
   source venv_de3/bin/activate
   pip install -r requirements.txt
   ```

2. **Select the environment as the new Jupyter Notebook Kernel**
   - Open the Command Palette in VS Code (Ctrl+Shift+P / Cmd+Shift+P on Mac).
   - Search for:
     `Python: Select Interpreter`
   - Choose the interpreter from your virtual environment:
     `venv_de3/bin/python` or `venv_de3/bin/python3`

---

## ✅ Notes

- Always activate your virtual environment (`venv_de3/`) before running any code.  
- Start the MongoDB service before executing the ETL pipeline.  
- The ETL process is implemented and tested through the Jupyter Notebook **`ImageDataProcessing.ipynb`**, which performs data ingestion, cleaning, transformation, and loading into MongoDB.  
- Generated visualizations and aggregation queries (e.g., by contrast agent, patient position, or exposure time) are automatically displayed as figures in the analysis section.

---

## 📊 Project Overview

The implemented system extracts relevant metadata from DICOM headers, normalizes values such as **age**, **contrast agent**, and **pixel spacing**, and stores the processed results in MongoDB collections. Analytical queries are then executed to produce insights including:

- Equipment usage trends by **manufacturer** and **model**.
- Exposure time distribution by **contrast agent** and **patient position**.
- Correlation between **X-ray tube current** and **patient age**.
- Lung image exploration by **sex** and **patient position**.

This architecture provides a scalable and modular foundation for future medical imaging analytics and research projects.