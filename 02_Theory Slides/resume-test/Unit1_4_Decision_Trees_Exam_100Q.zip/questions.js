const QUESTIONS = [
  {
    "id": 1,
    "section": "Unit1_4_Decision_Trees",
    "text": "Decision tree structure: which statement is correct?",
    "options": [
      "Incorrect definition of Decision tree structure",
      "Typical misconception about Decision tree structure",
      "Correct principle related to Decision tree structure",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 2,
    "section": "Unit1_4_Decision_Trees",
    "text": "Decision tree structure: which statement is correct?",
    "options": [
      "Incorrect definition of Decision tree structure",
      "Typical misconception about Decision tree structure",
      "Correct principle related to Decision tree structure",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 3,
    "section": "Unit1_4_Decision_Trees",
    "text": "Decision tree structure: which statement is correct?",
    "options": [
      "Incorrect definition of Decision tree structure",
      "Typical misconception about Decision tree structure",
      "Correct principle related to Decision tree structure",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 4,
    "section": "Unit1_4_Decision_Trees",
    "text": "Decision tree structure: which statement is correct?",
    "options": [
      "Incorrect definition of Decision tree structure",
      "Typical misconception about Decision tree structure",
      "Correct principle related to Decision tree structure",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 5,
    "section": "Unit1_4_Decision_Trees",
    "text": "Decision tree structure: which statement is correct?",
    "options": [
      "Incorrect definition of Decision tree structure",
      "Typical misconception about Decision tree structure",
      "Correct principle related to Decision tree structure",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 6,
    "section": "Unit1_4_Decision_Trees",
    "text": "Decision tree structure: which statement is correct?",
    "options": [
      "Incorrect definition of Decision tree structure",
      "Typical misconception about Decision tree structure",
      "Correct principle related to Decision tree structure",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 7,
    "section": "Unit1_4_Decision_Trees",
    "text": "Decision tree structure: which statement is correct?",
    "options": [
      "Incorrect definition of Decision tree structure",
      "Typical misconception about Decision tree structure",
      "Correct principle related to Decision tree structure",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 8,
    "section": "Unit1_4_Decision_Trees",
    "text": "Decision tree structure: which statement is correct?",
    "options": [
      "Incorrect definition of Decision tree structure",
      "Typical misconception about Decision tree structure",
      "Correct principle related to Decision tree structure",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 9,
    "section": "Unit1_4_Decision_Trees",
    "text": "Decision tree structure: which statement is correct?",
    "options": [
      "Incorrect definition of Decision tree structure",
      "Typical misconception about Decision tree structure",
      "Correct principle related to Decision tree structure",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 10,
    "section": "Unit1_4_Decision_Trees",
    "text": "Decision tree structure: which statement is correct?",
    "options": [
      "Incorrect definition of Decision tree structure",
      "Typical misconception about Decision tree structure",
      "Correct principle related to Decision tree structure",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 11,
    "section": "Unit1_4_Decision_Trees",
    "text": "Internal nodes: which statement is correct?",
    "options": [
      "Incorrect definition of Internal nodes",
      "Typical misconception about Internal nodes",
      "Correct principle related to Internal nodes",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 12,
    "section": "Unit1_4_Decision_Trees",
    "text": "Internal nodes: which statement is correct?",
    "options": [
      "Incorrect definition of Internal nodes",
      "Typical misconception about Internal nodes",
      "Correct principle related to Internal nodes",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 13,
    "section": "Unit1_4_Decision_Trees",
    "text": "Internal nodes: which statement is correct?",
    "options": [
      "Incorrect definition of Internal nodes",
      "Typical misconception about Internal nodes",
      "Correct principle related to Internal nodes",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 14,
    "section": "Unit1_4_Decision_Trees",
    "text": "Internal nodes: which statement is correct?",
    "options": [
      "Incorrect definition of Internal nodes",
      "Typical misconception about Internal nodes",
      "Correct principle related to Internal nodes",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 15,
    "section": "Unit1_4_Decision_Trees",
    "text": "Internal nodes: which statement is correct?",
    "options": [
      "Incorrect definition of Internal nodes",
      "Typical misconception about Internal nodes",
      "Correct principle related to Internal nodes",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 16,
    "section": "Unit1_4_Decision_Trees",
    "text": "Internal nodes: which statement is correct?",
    "options": [
      "Incorrect definition of Internal nodes",
      "Typical misconception about Internal nodes",
      "Correct principle related to Internal nodes",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 17,
    "section": "Unit1_4_Decision_Trees",
    "text": "Internal nodes: which statement is correct?",
    "options": [
      "Incorrect definition of Internal nodes",
      "Typical misconception about Internal nodes",
      "Correct principle related to Internal nodes",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 18,
    "section": "Unit1_4_Decision_Trees",
    "text": "Internal nodes: which statement is correct?",
    "options": [
      "Incorrect definition of Internal nodes",
      "Typical misconception about Internal nodes",
      "Correct principle related to Internal nodes",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 19,
    "section": "Unit1_4_Decision_Trees",
    "text": "Internal nodes: which statement is correct?",
    "options": [
      "Incorrect definition of Internal nodes",
      "Typical misconception about Internal nodes",
      "Correct principle related to Internal nodes",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 20,
    "section": "Unit1_4_Decision_Trees",
    "text": "Internal nodes: which statement is correct?",
    "options": [
      "Incorrect definition of Internal nodes",
      "Typical misconception about Internal nodes",
      "Correct principle related to Internal nodes",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 21,
    "section": "Unit1_4_Decision_Trees",
    "text": "Leaves: which statement is correct?",
    "options": [
      "Incorrect definition of Leaves",
      "Typical misconception about Leaves",
      "Correct principle related to Leaves",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 22,
    "section": "Unit1_4_Decision_Trees",
    "text": "Leaves: which statement is correct?",
    "options": [
      "Incorrect definition of Leaves",
      "Typical misconception about Leaves",
      "Correct principle related to Leaves",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 23,
    "section": "Unit1_4_Decision_Trees",
    "text": "Leaves: which statement is correct?",
    "options": [
      "Incorrect definition of Leaves",
      "Typical misconception about Leaves",
      "Correct principle related to Leaves",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 24,
    "section": "Unit1_4_Decision_Trees",
    "text": "Leaves: which statement is correct?",
    "options": [
      "Incorrect definition of Leaves",
      "Typical misconception about Leaves",
      "Correct principle related to Leaves",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 25,
    "section": "Unit1_4_Decision_Trees",
    "text": "Leaves: which statement is correct?",
    "options": [
      "Incorrect definition of Leaves",
      "Typical misconception about Leaves",
      "Correct principle related to Leaves",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 26,
    "section": "Unit1_4_Decision_Trees",
    "text": "Leaves: which statement is correct?",
    "options": [
      "Incorrect definition of Leaves",
      "Typical misconception about Leaves",
      "Correct principle related to Leaves",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 27,
    "section": "Unit1_4_Decision_Trees",
    "text": "Leaves: which statement is correct?",
    "options": [
      "Incorrect definition of Leaves",
      "Typical misconception about Leaves",
      "Correct principle related to Leaves",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 28,
    "section": "Unit1_4_Decision_Trees",
    "text": "Leaves: which statement is correct?",
    "options": [
      "Incorrect definition of Leaves",
      "Typical misconception about Leaves",
      "Correct principle related to Leaves",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 29,
    "section": "Unit1_4_Decision_Trees",
    "text": "Leaves: which statement is correct?",
    "options": [
      "Incorrect definition of Leaves",
      "Typical misconception about Leaves",
      "Correct principle related to Leaves",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 30,
    "section": "Unit1_4_Decision_Trees",
    "text": "Leaves: which statement is correct?",
    "options": [
      "Incorrect definition of Leaves",
      "Typical misconception about Leaves",
      "Correct principle related to Leaves",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 31,
    "section": "Unit1_4_Decision_Trees",
    "text": "Disjunction of conjunctions: which statement is correct?",
    "options": [
      "Incorrect definition of Disjunction of conjunctions",
      "Typical misconception about Disjunction of conjunctions",
      "Correct principle related to Disjunction of conjunctions",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 32,
    "section": "Unit1_4_Decision_Trees",
    "text": "Disjunction of conjunctions: which statement is correct?",
    "options": [
      "Incorrect definition of Disjunction of conjunctions",
      "Typical misconception about Disjunction of conjunctions",
      "Correct principle related to Disjunction of conjunctions",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 33,
    "section": "Unit1_4_Decision_Trees",
    "text": "Disjunction of conjunctions: which statement is correct?",
    "options": [
      "Incorrect definition of Disjunction of conjunctions",
      "Typical misconception about Disjunction of conjunctions",
      "Correct principle related to Disjunction of conjunctions",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 34,
    "section": "Unit1_4_Decision_Trees",
    "text": "Disjunction of conjunctions: which statement is correct?",
    "options": [
      "Incorrect definition of Disjunction of conjunctions",
      "Typical misconception about Disjunction of conjunctions",
      "Correct principle related to Disjunction of conjunctions",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 35,
    "section": "Unit1_4_Decision_Trees",
    "text": "Disjunction of conjunctions: which statement is correct?",
    "options": [
      "Incorrect definition of Disjunction of conjunctions",
      "Typical misconception about Disjunction of conjunctions",
      "Correct principle related to Disjunction of conjunctions",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 36,
    "section": "Unit1_4_Decision_Trees",
    "text": "Disjunction of conjunctions: which statement is correct?",
    "options": [
      "Incorrect definition of Disjunction of conjunctions",
      "Typical misconception about Disjunction of conjunctions",
      "Correct principle related to Disjunction of conjunctions",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 37,
    "section": "Unit1_4_Decision_Trees",
    "text": "Disjunction of conjunctions: which statement is correct?",
    "options": [
      "Incorrect definition of Disjunction of conjunctions",
      "Typical misconception about Disjunction of conjunctions",
      "Correct principle related to Disjunction of conjunctions",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 38,
    "section": "Unit1_4_Decision_Trees",
    "text": "Disjunction of conjunctions: which statement is correct?",
    "options": [
      "Incorrect definition of Disjunction of conjunctions",
      "Typical misconception about Disjunction of conjunctions",
      "Correct principle related to Disjunction of conjunctions",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 39,
    "section": "Unit1_4_Decision_Trees",
    "text": "Disjunction of conjunctions: which statement is correct?",
    "options": [
      "Incorrect definition of Disjunction of conjunctions",
      "Typical misconception about Disjunction of conjunctions",
      "Correct principle related to Disjunction of conjunctions",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 40,
    "section": "Unit1_4_Decision_Trees",
    "text": "Disjunction of conjunctions: which statement is correct?",
    "options": [
      "Incorrect definition of Disjunction of conjunctions",
      "Typical misconception about Disjunction of conjunctions",
      "Correct principle related to Disjunction of conjunctions",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 41,
    "section": "Unit1_4_Decision_Trees",
    "text": "Rule extraction: which statement is correct?",
    "options": [
      "Incorrect definition of Rule extraction",
      "Typical misconception about Rule extraction",
      "Correct principle related to Rule extraction",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 42,
    "section": "Unit1_4_Decision_Trees",
    "text": "Rule extraction: which statement is correct?",
    "options": [
      "Incorrect definition of Rule extraction",
      "Typical misconception about Rule extraction",
      "Correct principle related to Rule extraction",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 43,
    "section": "Unit1_4_Decision_Trees",
    "text": "Rule extraction: which statement is correct?",
    "options": [
      "Incorrect definition of Rule extraction",
      "Typical misconception about Rule extraction",
      "Correct principle related to Rule extraction",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 44,
    "section": "Unit1_4_Decision_Trees",
    "text": "Rule extraction: which statement is correct?",
    "options": [
      "Incorrect definition of Rule extraction",
      "Typical misconception about Rule extraction",
      "Correct principle related to Rule extraction",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 45,
    "section": "Unit1_4_Decision_Trees",
    "text": "Rule extraction: which statement is correct?",
    "options": [
      "Incorrect definition of Rule extraction",
      "Typical misconception about Rule extraction",
      "Correct principle related to Rule extraction",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 46,
    "section": "Unit1_4_Decision_Trees",
    "text": "Rule extraction: which statement is correct?",
    "options": [
      "Incorrect definition of Rule extraction",
      "Typical misconception about Rule extraction",
      "Correct principle related to Rule extraction",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 47,
    "section": "Unit1_4_Decision_Trees",
    "text": "Rule extraction: which statement is correct?",
    "options": [
      "Incorrect definition of Rule extraction",
      "Typical misconception about Rule extraction",
      "Correct principle related to Rule extraction",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 48,
    "section": "Unit1_4_Decision_Trees",
    "text": "Rule extraction: which statement is correct?",
    "options": [
      "Incorrect definition of Rule extraction",
      "Typical misconception about Rule extraction",
      "Correct principle related to Rule extraction",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 49,
    "section": "Unit1_4_Decision_Trees",
    "text": "Rule extraction: which statement is correct?",
    "options": [
      "Incorrect definition of Rule extraction",
      "Typical misconception about Rule extraction",
      "Correct principle related to Rule extraction",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 50,
    "section": "Unit1_4_Decision_Trees",
    "text": "Rule extraction: which statement is correct?",
    "options": [
      "Incorrect definition of Rule extraction",
      "Typical misconception about Rule extraction",
      "Correct principle related to Rule extraction",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 51,
    "section": "Unit1_4_Decision_Trees",
    "text": "Information gain: which statement is correct?",
    "options": [
      "Incorrect definition of Information gain",
      "Typical misconception about Information gain",
      "Correct principle related to Information gain",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 52,
    "section": "Unit1_4_Decision_Trees",
    "text": "Information gain: which statement is correct?",
    "options": [
      "Incorrect definition of Information gain",
      "Typical misconception about Information gain",
      "Correct principle related to Information gain",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 53,
    "section": "Unit1_4_Decision_Trees",
    "text": "Information gain: which statement is correct?",
    "options": [
      "Incorrect definition of Information gain",
      "Typical misconception about Information gain",
      "Correct principle related to Information gain",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 54,
    "section": "Unit1_4_Decision_Trees",
    "text": "Information gain: which statement is correct?",
    "options": [
      "Incorrect definition of Information gain",
      "Typical misconception about Information gain",
      "Correct principle related to Information gain",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 55,
    "section": "Unit1_4_Decision_Trees",
    "text": "Information gain: which statement is correct?",
    "options": [
      "Incorrect definition of Information gain",
      "Typical misconception about Information gain",
      "Correct principle related to Information gain",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 56,
    "section": "Unit1_4_Decision_Trees",
    "text": "Information gain: which statement is correct?",
    "options": [
      "Incorrect definition of Information gain",
      "Typical misconception about Information gain",
      "Correct principle related to Information gain",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 57,
    "section": "Unit1_4_Decision_Trees",
    "text": "Information gain: which statement is correct?",
    "options": [
      "Incorrect definition of Information gain",
      "Typical misconception about Information gain",
      "Correct principle related to Information gain",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 58,
    "section": "Unit1_4_Decision_Trees",
    "text": "Information gain: which statement is correct?",
    "options": [
      "Incorrect definition of Information gain",
      "Typical misconception about Information gain",
      "Correct principle related to Information gain",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 59,
    "section": "Unit1_4_Decision_Trees",
    "text": "Information gain: which statement is correct?",
    "options": [
      "Incorrect definition of Information gain",
      "Typical misconception about Information gain",
      "Correct principle related to Information gain",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 60,
    "section": "Unit1_4_Decision_Trees",
    "text": "Information gain: which statement is correct?",
    "options": [
      "Incorrect definition of Information gain",
      "Typical misconception about Information gain",
      "Correct principle related to Information gain",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 61,
    "section": "Unit1_4_Decision_Trees",
    "text": "Entropy: which statement is correct?",
    "options": [
      "Incorrect definition of Entropy",
      "Typical misconception about Entropy",
      "Correct principle related to Entropy",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 62,
    "section": "Unit1_4_Decision_Trees",
    "text": "Entropy: which statement is correct?",
    "options": [
      "Incorrect definition of Entropy",
      "Typical misconception about Entropy",
      "Correct principle related to Entropy",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 63,
    "section": "Unit1_4_Decision_Trees",
    "text": "Entropy: which statement is correct?",
    "options": [
      "Incorrect definition of Entropy",
      "Typical misconception about Entropy",
      "Correct principle related to Entropy",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 64,
    "section": "Unit1_4_Decision_Trees",
    "text": "Entropy: which statement is correct?",
    "options": [
      "Incorrect definition of Entropy",
      "Typical misconception about Entropy",
      "Correct principle related to Entropy",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 65,
    "section": "Unit1_4_Decision_Trees",
    "text": "Entropy: which statement is correct?",
    "options": [
      "Incorrect definition of Entropy",
      "Typical misconception about Entropy",
      "Correct principle related to Entropy",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 66,
    "section": "Unit1_4_Decision_Trees",
    "text": "Entropy: which statement is correct?",
    "options": [
      "Incorrect definition of Entropy",
      "Typical misconception about Entropy",
      "Correct principle related to Entropy",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 67,
    "section": "Unit1_4_Decision_Trees",
    "text": "Entropy: which statement is correct?",
    "options": [
      "Incorrect definition of Entropy",
      "Typical misconception about Entropy",
      "Correct principle related to Entropy",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 68,
    "section": "Unit1_4_Decision_Trees",
    "text": "Entropy: which statement is correct?",
    "options": [
      "Incorrect definition of Entropy",
      "Typical misconception about Entropy",
      "Correct principle related to Entropy",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 69,
    "section": "Unit1_4_Decision_Trees",
    "text": "Entropy: which statement is correct?",
    "options": [
      "Incorrect definition of Entropy",
      "Typical misconception about Entropy",
      "Correct principle related to Entropy",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 70,
    "section": "Unit1_4_Decision_Trees",
    "text": "Entropy: which statement is correct?",
    "options": [
      "Incorrect definition of Entropy",
      "Typical misconception about Entropy",
      "Correct principle related to Entropy",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 71,
    "section": "Unit1_4_Decision_Trees",
    "text": "ID3 algorithm: which statement is correct?",
    "options": [
      "Incorrect definition of ID3 algorithm",
      "Typical misconception about ID3 algorithm",
      "Correct principle related to ID3 algorithm",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 72,
    "section": "Unit1_4_Decision_Trees",
    "text": "ID3 algorithm: which statement is correct?",
    "options": [
      "Incorrect definition of ID3 algorithm",
      "Typical misconception about ID3 algorithm",
      "Correct principle related to ID3 algorithm",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 73,
    "section": "Unit1_4_Decision_Trees",
    "text": "ID3 algorithm: which statement is correct?",
    "options": [
      "Incorrect definition of ID3 algorithm",
      "Typical misconception about ID3 algorithm",
      "Correct principle related to ID3 algorithm",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 74,
    "section": "Unit1_4_Decision_Trees",
    "text": "ID3 algorithm: which statement is correct?",
    "options": [
      "Incorrect definition of ID3 algorithm",
      "Typical misconception about ID3 algorithm",
      "Correct principle related to ID3 algorithm",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 75,
    "section": "Unit1_4_Decision_Trees",
    "text": "ID3 algorithm: which statement is correct?",
    "options": [
      "Incorrect definition of ID3 algorithm",
      "Typical misconception about ID3 algorithm",
      "Correct principle related to ID3 algorithm",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 76,
    "section": "Unit1_4_Decision_Trees",
    "text": "ID3 algorithm: which statement is correct?",
    "options": [
      "Incorrect definition of ID3 algorithm",
      "Typical misconception about ID3 algorithm",
      "Correct principle related to ID3 algorithm",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 77,
    "section": "Unit1_4_Decision_Trees",
    "text": "ID3 algorithm: which statement is correct?",
    "options": [
      "Incorrect definition of ID3 algorithm",
      "Typical misconception about ID3 algorithm",
      "Correct principle related to ID3 algorithm",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 78,
    "section": "Unit1_4_Decision_Trees",
    "text": "ID3 algorithm: which statement is correct?",
    "options": [
      "Incorrect definition of ID3 algorithm",
      "Typical misconception about ID3 algorithm",
      "Correct principle related to ID3 algorithm",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 79,
    "section": "Unit1_4_Decision_Trees",
    "text": "ID3 algorithm: which statement is correct?",
    "options": [
      "Incorrect definition of ID3 algorithm",
      "Typical misconception about ID3 algorithm",
      "Correct principle related to ID3 algorithm",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 80,
    "section": "Unit1_4_Decision_Trees",
    "text": "ID3 algorithm: which statement is correct?",
    "options": [
      "Incorrect definition of ID3 algorithm",
      "Typical misconception about ID3 algorithm",
      "Correct principle related to ID3 algorithm",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 81,
    "section": "Unit1_4_Decision_Trees",
    "text": "Recursive partitioning: which statement is correct?",
    "options": [
      "Incorrect definition of Recursive partitioning",
      "Typical misconception about Recursive partitioning",
      "Correct principle related to Recursive partitioning",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 82,
    "section": "Unit1_4_Decision_Trees",
    "text": "Recursive partitioning: which statement is correct?",
    "options": [
      "Incorrect definition of Recursive partitioning",
      "Typical misconception about Recursive partitioning",
      "Correct principle related to Recursive partitioning",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 83,
    "section": "Unit1_4_Decision_Trees",
    "text": "Recursive partitioning: which statement is correct?",
    "options": [
      "Incorrect definition of Recursive partitioning",
      "Typical misconception about Recursive partitioning",
      "Correct principle related to Recursive partitioning",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 84,
    "section": "Unit1_4_Decision_Trees",
    "text": "Recursive partitioning: which statement is correct?",
    "options": [
      "Incorrect definition of Recursive partitioning",
      "Typical misconception about Recursive partitioning",
      "Correct principle related to Recursive partitioning",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 85,
    "section": "Unit1_4_Decision_Trees",
    "text": "Recursive partitioning: which statement is correct?",
    "options": [
      "Incorrect definition of Recursive partitioning",
      "Typical misconception about Recursive partitioning",
      "Correct principle related to Recursive partitioning",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 86,
    "section": "Unit1_4_Decision_Trees",
    "text": "Recursive partitioning: which statement is correct?",
    "options": [
      "Incorrect definition of Recursive partitioning",
      "Typical misconception about Recursive partitioning",
      "Correct principle related to Recursive partitioning",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 87,
    "section": "Unit1_4_Decision_Trees",
    "text": "Recursive partitioning: which statement is correct?",
    "options": [
      "Incorrect definition of Recursive partitioning",
      "Typical misconception about Recursive partitioning",
      "Correct principle related to Recursive partitioning",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 88,
    "section": "Unit1_4_Decision_Trees",
    "text": "Recursive partitioning: which statement is correct?",
    "options": [
      "Incorrect definition of Recursive partitioning",
      "Typical misconception about Recursive partitioning",
      "Correct principle related to Recursive partitioning",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 89,
    "section": "Unit1_4_Decision_Trees",
    "text": "Recursive partitioning: which statement is correct?",
    "options": [
      "Incorrect definition of Recursive partitioning",
      "Typical misconception about Recursive partitioning",
      "Correct principle related to Recursive partitioning",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 90,
    "section": "Unit1_4_Decision_Trees",
    "text": "Recursive partitioning: which statement is correct?",
    "options": [
      "Incorrect definition of Recursive partitioning",
      "Typical misconception about Recursive partitioning",
      "Correct principle related to Recursive partitioning",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 91,
    "section": "Unit1_4_Decision_Trees",
    "text": "Overfitting in trees: which statement is correct?",
    "options": [
      "Incorrect definition of Overfitting in trees",
      "Typical misconception about Overfitting in trees",
      "Correct principle related to Overfitting in trees",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 92,
    "section": "Unit1_4_Decision_Trees",
    "text": "Overfitting in trees: which statement is correct?",
    "options": [
      "Incorrect definition of Overfitting in trees",
      "Typical misconception about Overfitting in trees",
      "Correct principle related to Overfitting in trees",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 93,
    "section": "Unit1_4_Decision_Trees",
    "text": "Overfitting in trees: which statement is correct?",
    "options": [
      "Incorrect definition of Overfitting in trees",
      "Typical misconception about Overfitting in trees",
      "Correct principle related to Overfitting in trees",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 94,
    "section": "Unit1_4_Decision_Trees",
    "text": "Overfitting in trees: which statement is correct?",
    "options": [
      "Incorrect definition of Overfitting in trees",
      "Typical misconception about Overfitting in trees",
      "Correct principle related to Overfitting in trees",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 95,
    "section": "Unit1_4_Decision_Trees",
    "text": "Overfitting in trees: which statement is correct?",
    "options": [
      "Incorrect definition of Overfitting in trees",
      "Typical misconception about Overfitting in trees",
      "Correct principle related to Overfitting in trees",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 96,
    "section": "Unit1_4_Decision_Trees",
    "text": "Overfitting in trees: which statement is correct?",
    "options": [
      "Incorrect definition of Overfitting in trees",
      "Typical misconception about Overfitting in trees",
      "Correct principle related to Overfitting in trees",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 97,
    "section": "Unit1_4_Decision_Trees",
    "text": "Overfitting in trees: which statement is correct?",
    "options": [
      "Incorrect definition of Overfitting in trees",
      "Typical misconception about Overfitting in trees",
      "Correct principle related to Overfitting in trees",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 98,
    "section": "Unit1_4_Decision_Trees",
    "text": "Overfitting in trees: which statement is correct?",
    "options": [
      "Incorrect definition of Overfitting in trees",
      "Typical misconception about Overfitting in trees",
      "Correct principle related to Overfitting in trees",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 99,
    "section": "Unit1_4_Decision_Trees",
    "text": "Overfitting in trees: which statement is correct?",
    "options": [
      "Incorrect definition of Overfitting in trees",
      "Typical misconception about Overfitting in trees",
      "Correct principle related to Overfitting in trees",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 100,
    "section": "Unit1_4_Decision_Trees",
    "text": "Overfitting in trees: which statement is correct?",
    "options": [
      "Incorrect definition of Overfitting in trees",
      "Typical misconception about Overfitting in trees",
      "Correct principle related to Overfitting in trees",
      "Unrelated concept"
    ],
    "answer": 2
  }
];