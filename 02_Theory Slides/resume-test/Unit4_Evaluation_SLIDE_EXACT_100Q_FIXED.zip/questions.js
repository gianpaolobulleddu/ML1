const QUESTIONS = [
  {
    "id": 1,
    "section": "Unit 4 \u2013 Evaluation",
    "text": "Accuracy is defined as:",
    "options": [
      "$\\frac{TP}{TP+FP}$",
      "$\\frac{TP+TN}{TP+TN+FP+FN}$",
      "$\\frac{TP}{TP+FN}$",
      "$\\frac{TN}{TN+FP}$"
    ],
    "answer": 1
  },
  {
    "id": 2,
    "section": "Unit 4 \u2013 Evaluation",
    "text": "Accuracy is misleading when:",
    "options": [
      "Classes are highly imbalanced",
      "ROC AUC is high",
      "Precision equals recall",
      "Threshold is fixed"
    ],
    "answer": 0
  },
  {
    "id": 3,
    "section": "Unit 4 \u2013 Evaluation",
    "text": "Accuracy treats false positives and false negatives as:",
    "options": [
      "Equally important",
      "False positives only",
      "False negatives only",
      "Class-dependent"
    ],
    "answer": 0
  },
  {
    "id": 4,
    "section": "Unit 4 \u2013 Evaluation",
    "text": "Precision measures:",
    "options": [
      "Ability to detect positives",
      "Fraction of predicted positives that are correct",
      "Fraction of negatives detected",
      "Overall correctness"
    ],
    "answer": 1
  },
  {
    "id": 5,
    "section": "Unit 4 \u2013 Evaluation",
    "text": "Recall is also known as:",
    "options": [
      "Specificity",
      "Sensitivity",
      "Precision",
      "Negative predictive value"
    ],
    "answer": 1
  },
  {
    "id": 6,
    "section": "Unit 4 \u2013 Evaluation",
    "text": "Increasing the decision threshold typically:",
    "options": [
      "Increases recall and decreases precision",
      "Increases both precision and recall",
      "Increases precision and decreases recall",
      "Decreases both"
    ],
    "answer": 2
  },
  {
    "id": 7,
    "section": "Unit 4 \u2013 Evaluation",
    "text": "High recall but low precision implies:",
    "options": [
      "Few false positives",
      "Many false positives",
      "Few false negatives",
      "Balanced predictions"
    ],
    "answer": 1
  },
  {
    "id": 8,
    "section": "Unit 4 \u2013 Evaluation",
    "text": "The F1-score is the harmonic mean of:",
    "options": [
      "Accuracy and recall",
      "Precision and recall",
      "TPR and FPR",
      "Sensitivity and specificity"
    ],
    "answer": 1
  },
  {
    "id": 9,
    "section": "Unit 4 \u2013 Evaluation",
    "text": "F1-score is maximized when:",
    "options": [
      "Precision is high",
      "Recall is high",
      "Precision equals recall",
      "Accuracy is high"
    ],
    "answer": 2
  },
  {
    "id": 10,
    "section": "Unit 4 \u2013 Evaluation",
    "text": "Specificity is defined as:",
    "options": [
      "$\\frac{TN}{TN+FP}$",
      "$\\frac{TP}{TP+FN}$",
      "$\\frac{FP}{FP+TN}$",
      "$\\frac{TN}{TN+FN}$"
    ],
    "answer": 0
  },
  {
    "id": 11,
    "section": "Unit 4 \u2013 Evaluation",
    "text": "False positive rate (FPR) is equal to:",
    "options": [
      "$1-\\text{Specificity}$",
      "$1-\\text{Recall}$",
      "$1-\\text{Precision}$",
      "$1-\\text{Accuracy}$"
    ],
    "answer": 0
  },
  {
    "id": 12,
    "section": "Unit 4 \u2013 Evaluation",
    "text": "The ROC curve plots:",
    "options": [
      "Precision vs Recall",
      "TPR vs FPR",
      "Accuracy vs threshold",
      "Loss vs epochs"
    ],
    "answer": 1
  },
  {
    "id": 13,
    "section": "Unit 4 \u2013 Evaluation",
    "text": "A random classifier has ROC AUC equal to:",
    "options": [
      "0",
      "0.25",
      "0.5",
      "1"
    ],
    "answer": 2
  },
  {
    "id": 14,
    "section": "Unit 4 \u2013 Evaluation",
    "text": "The perfect classifier corresponds to ROC point:",
    "options": [
      "(1,0)",
      "(0,0)",
      "(1,1)",
      "(0,1)"
    ],
    "answer": 3
  },
  {
    "id": 15,
    "section": "Unit 4 \u2013 Evaluation",
    "text": "ROC curves are threshold-independent because they:",
    "options": [
      "Fix a threshold",
      "Integrate over all thresholds",
      "Use class labels only",
      "Ignore false positives"
    ],
    "answer": 1
  },
  {
    "id": 16,
    "section": "Unit 4 \u2013 Evaluation",
    "text": "Macro-averaging computes metrics by:",
    "options": [
      "Using global TP, FP, FN",
      "Averaging per-class metrics",
      "Weighting by class frequency",
      "Ignoring minority classes"
    ],
    "answer": 1
  },
  {
    "id": 17,
    "section": "Unit 4 \u2013 Evaluation",
    "text": "Micro-averaging differs from macro-averaging because it:",
    "options": [
      "Ignores class imbalance",
      "Uses global TP, FP, FN",
      "Weights minority classes more",
      "Averages per-class scores"
    ],
    "answer": 1
  },
  {
    "id": 18,
    "section": "Unit 4 \u2013 Evaluation",
    "text": "Micro-averaging is dominated by:",
    "options": [
      "Minority classes",
      "Majority classes",
      "All classes equally",
      "Random effects"
    ],
    "answer": 1
  },
  {
    "id": 19,
    "section": "Unit 4 \u2013 Evaluation",
    "text": "Which metric is most appropriate for rare disease detection?",
    "options": [
      "Accuracy",
      "Recall",
      "Specificity",
      "ROC AUC"
    ],
    "answer": 1
  },
  {
    "id": 20,
    "section": "Unit 4 \u2013 Evaluation",
    "text": "Precision\u2013recall curves are preferred over ROC when:",
    "options": [
      "Classes are balanced",
      "Classes are imbalanced",
      "Threshold is fixed",
      "Loss is convex"
    ],
    "answer": 1
  },
  {
    "id": 21,
    "section": "Unit 4 \u2013 Evaluation",
    "text": "Accuracy is defined as:",
    "options": [
      "$\\frac{TP}{TP+FP}$",
      "$\\frac{TP+TN}{TP+TN+FP+FN}$",
      "$\\frac{TP}{TP+FN}$",
      "$\\frac{TN}{TN+FP}$"
    ],
    "answer": 1
  },
  {
    "id": 22,
    "section": "Unit 4 \u2013 Evaluation",
    "text": "Accuracy is misleading when:",
    "options": [
      "Classes are highly imbalanced",
      "ROC AUC is high",
      "Precision equals recall",
      "Threshold is fixed"
    ],
    "answer": 0
  },
  {
    "id": 23,
    "section": "Unit 4 \u2013 Evaluation",
    "text": "Accuracy treats false positives and false negatives as:",
    "options": [
      "Equally important",
      "False positives only",
      "False negatives only",
      "Class-dependent"
    ],
    "answer": 0
  },
  {
    "id": 24,
    "section": "Unit 4 \u2013 Evaluation",
    "text": "Precision measures:",
    "options": [
      "Ability to detect positives",
      "Fraction of predicted positives that are correct",
      "Fraction of negatives detected",
      "Overall correctness"
    ],
    "answer": 1
  },
  {
    "id": 25,
    "section": "Unit 4 \u2013 Evaluation",
    "text": "Recall is also known as:",
    "options": [
      "Specificity",
      "Sensitivity",
      "Precision",
      "Negative predictive value"
    ],
    "answer": 1
  },
  {
    "id": 26,
    "section": "Unit 4 \u2013 Evaluation",
    "text": "Increasing the decision threshold typically:",
    "options": [
      "Increases recall and decreases precision",
      "Increases both precision and recall",
      "Increases precision and decreases recall",
      "Decreases both"
    ],
    "answer": 2
  },
  {
    "id": 27,
    "section": "Unit 4 \u2013 Evaluation",
    "text": "High recall but low precision implies:",
    "options": [
      "Few false positives",
      "Many false positives",
      "Few false negatives",
      "Balanced predictions"
    ],
    "answer": 1
  },
  {
    "id": 28,
    "section": "Unit 4 \u2013 Evaluation",
    "text": "The F1-score is the harmonic mean of:",
    "options": [
      "Accuracy and recall",
      "Precision and recall",
      "TPR and FPR",
      "Sensitivity and specificity"
    ],
    "answer": 1
  },
  {
    "id": 29,
    "section": "Unit 4 \u2013 Evaluation",
    "text": "F1-score is maximized when:",
    "options": [
      "Precision is high",
      "Recall is high",
      "Precision equals recall",
      "Accuracy is high"
    ],
    "answer": 2
  },
  {
    "id": 30,
    "section": "Unit 4 \u2013 Evaluation",
    "text": "Specificity is defined as:",
    "options": [
      "$\\frac{TN}{TN+FP}$",
      "$\\frac{TP}{TP+FN}$",
      "$\\frac{FP}{FP+TN}$",
      "$\\frac{TN}{TN+FN}$"
    ],
    "answer": 0
  },
  {
    "id": 31,
    "section": "Unit 4 \u2013 Evaluation",
    "text": "False positive rate (FPR) is equal to:",
    "options": [
      "$1-\\text{Specificity}$",
      "$1-\\text{Recall}$",
      "$1-\\text{Precision}$",
      "$1-\\text{Accuracy}$"
    ],
    "answer": 0
  },
  {
    "id": 32,
    "section": "Unit 4 \u2013 Evaluation",
    "text": "The ROC curve plots:",
    "options": [
      "Precision vs Recall",
      "TPR vs FPR",
      "Accuracy vs threshold",
      "Loss vs epochs"
    ],
    "answer": 1
  },
  {
    "id": 33,
    "section": "Unit 4 \u2013 Evaluation",
    "text": "A random classifier has ROC AUC equal to:",
    "options": [
      "0",
      "0.25",
      "0.5",
      "1"
    ],
    "answer": 2
  },
  {
    "id": 34,
    "section": "Unit 4 \u2013 Evaluation",
    "text": "The perfect classifier corresponds to ROC point:",
    "options": [
      "(1,0)",
      "(0,0)",
      "(1,1)",
      "(0,1)"
    ],
    "answer": 3
  },
  {
    "id": 35,
    "section": "Unit 4 \u2013 Evaluation",
    "text": "ROC curves are threshold-independent because they:",
    "options": [
      "Fix a threshold",
      "Integrate over all thresholds",
      "Use class labels only",
      "Ignore false positives"
    ],
    "answer": 1
  },
  {
    "id": 36,
    "section": "Unit 4 \u2013 Evaluation",
    "text": "Macro-averaging computes metrics by:",
    "options": [
      "Using global TP, FP, FN",
      "Averaging per-class metrics",
      "Weighting by class frequency",
      "Ignoring minority classes"
    ],
    "answer": 1
  },
  {
    "id": 37,
    "section": "Unit 4 \u2013 Evaluation",
    "text": "Micro-averaging differs from macro-averaging because it:",
    "options": [
      "Ignores class imbalance",
      "Uses global TP, FP, FN",
      "Weights minority classes more",
      "Averages per-class scores"
    ],
    "answer": 1
  },
  {
    "id": 38,
    "section": "Unit 4 \u2013 Evaluation",
    "text": "Micro-averaging is dominated by:",
    "options": [
      "Minority classes",
      "Majority classes",
      "All classes equally",
      "Random effects"
    ],
    "answer": 1
  },
  {
    "id": 39,
    "section": "Unit 4 \u2013 Evaluation",
    "text": "Which metric is most appropriate for rare disease detection?",
    "options": [
      "Accuracy",
      "Recall",
      "Specificity",
      "ROC AUC"
    ],
    "answer": 1
  },
  {
    "id": 40,
    "section": "Unit 4 \u2013 Evaluation",
    "text": "Precision\u2013recall curves are preferred over ROC when:",
    "options": [
      "Classes are balanced",
      "Classes are imbalanced",
      "Threshold is fixed",
      "Loss is convex"
    ],
    "answer": 1
  },
  {
    "id": 41,
    "section": "Unit 4 \u2013 Evaluation",
    "text": "Accuracy is defined as:",
    "options": [
      "$\\frac{TP}{TP+FP}$",
      "$\\frac{TP+TN}{TP+TN+FP+FN}$",
      "$\\frac{TP}{TP+FN}$",
      "$\\frac{TN}{TN+FP}$"
    ],
    "answer": 1
  },
  {
    "id": 42,
    "section": "Unit 4 \u2013 Evaluation",
    "text": "Accuracy is misleading when:",
    "options": [
      "Classes are highly imbalanced",
      "ROC AUC is high",
      "Precision equals recall",
      "Threshold is fixed"
    ],
    "answer": 0
  },
  {
    "id": 43,
    "section": "Unit 4 \u2013 Evaluation",
    "text": "Accuracy treats false positives and false negatives as:",
    "options": [
      "Equally important",
      "False positives only",
      "False negatives only",
      "Class-dependent"
    ],
    "answer": 0
  },
  {
    "id": 44,
    "section": "Unit 4 \u2013 Evaluation",
    "text": "Precision measures:",
    "options": [
      "Ability to detect positives",
      "Fraction of predicted positives that are correct",
      "Fraction of negatives detected",
      "Overall correctness"
    ],
    "answer": 1
  },
  {
    "id": 45,
    "section": "Unit 4 \u2013 Evaluation",
    "text": "Recall is also known as:",
    "options": [
      "Specificity",
      "Sensitivity",
      "Precision",
      "Negative predictive value"
    ],
    "answer": 1
  },
  {
    "id": 46,
    "section": "Unit 4 \u2013 Evaluation",
    "text": "Increasing the decision threshold typically:",
    "options": [
      "Increases recall and decreases precision",
      "Increases both precision and recall",
      "Increases precision and decreases recall",
      "Decreases both"
    ],
    "answer": 2
  },
  {
    "id": 47,
    "section": "Unit 4 \u2013 Evaluation",
    "text": "High recall but low precision implies:",
    "options": [
      "Few false positives",
      "Many false positives",
      "Few false negatives",
      "Balanced predictions"
    ],
    "answer": 1
  },
  {
    "id": 48,
    "section": "Unit 4 \u2013 Evaluation",
    "text": "The F1-score is the harmonic mean of:",
    "options": [
      "Accuracy and recall",
      "Precision and recall",
      "TPR and FPR",
      "Sensitivity and specificity"
    ],
    "answer": 1
  },
  {
    "id": 49,
    "section": "Unit 4 \u2013 Evaluation",
    "text": "F1-score is maximized when:",
    "options": [
      "Precision is high",
      "Recall is high",
      "Precision equals recall",
      "Accuracy is high"
    ],
    "answer": 2
  },
  {
    "id": 50,
    "section": "Unit 4 \u2013 Evaluation",
    "text": "Specificity is defined as:",
    "options": [
      "$\\frac{TN}{TN+FP}$",
      "$\\frac{TP}{TP+FN}$",
      "$\\frac{FP}{FP+TN}$",
      "$\\frac{TN}{TN+FN}$"
    ],
    "answer": 0
  },
  {
    "id": 51,
    "section": "Unit 4 \u2013 Evaluation",
    "text": "False positive rate (FPR) is equal to:",
    "options": [
      "$1-\\text{Specificity}$",
      "$1-\\text{Recall}$",
      "$1-\\text{Precision}$",
      "$1-\\text{Accuracy}$"
    ],
    "answer": 0
  },
  {
    "id": 52,
    "section": "Unit 4 \u2013 Evaluation",
    "text": "The ROC curve plots:",
    "options": [
      "Precision vs Recall",
      "TPR vs FPR",
      "Accuracy vs threshold",
      "Loss vs epochs"
    ],
    "answer": 1
  },
  {
    "id": 53,
    "section": "Unit 4 \u2013 Evaluation",
    "text": "A random classifier has ROC AUC equal to:",
    "options": [
      "0",
      "0.25",
      "0.5",
      "1"
    ],
    "answer": 2
  },
  {
    "id": 54,
    "section": "Unit 4 \u2013 Evaluation",
    "text": "The perfect classifier corresponds to ROC point:",
    "options": [
      "(1,0)",
      "(0,0)",
      "(1,1)",
      "(0,1)"
    ],
    "answer": 3
  },
  {
    "id": 55,
    "section": "Unit 4 \u2013 Evaluation",
    "text": "ROC curves are threshold-independent because they:",
    "options": [
      "Fix a threshold",
      "Integrate over all thresholds",
      "Use class labels only",
      "Ignore false positives"
    ],
    "answer": 1
  },
  {
    "id": 56,
    "section": "Unit 4 \u2013 Evaluation",
    "text": "Macro-averaging computes metrics by:",
    "options": [
      "Using global TP, FP, FN",
      "Averaging per-class metrics",
      "Weighting by class frequency",
      "Ignoring minority classes"
    ],
    "answer": 1
  },
  {
    "id": 57,
    "section": "Unit 4 \u2013 Evaluation",
    "text": "Micro-averaging differs from macro-averaging because it:",
    "options": [
      "Ignores class imbalance",
      "Uses global TP, FP, FN",
      "Weights minority classes more",
      "Averages per-class scores"
    ],
    "answer": 1
  },
  {
    "id": 58,
    "section": "Unit 4 \u2013 Evaluation",
    "text": "Micro-averaging is dominated by:",
    "options": [
      "Minority classes",
      "Majority classes",
      "All classes equally",
      "Random effects"
    ],
    "answer": 1
  },
  {
    "id": 59,
    "section": "Unit 4 \u2013 Evaluation",
    "text": "Which metric is most appropriate for rare disease detection?",
    "options": [
      "Accuracy",
      "Recall",
      "Specificity",
      "ROC AUC"
    ],
    "answer": 1
  },
  {
    "id": 60,
    "section": "Unit 4 \u2013 Evaluation",
    "text": "Precision\u2013recall curves are preferred over ROC when:",
    "options": [
      "Classes are balanced",
      "Classes are imbalanced",
      "Threshold is fixed",
      "Loss is convex"
    ],
    "answer": 1
  },
  {
    "id": 61,
    "section": "Unit 4 \u2013 Evaluation",
    "text": "Accuracy is defined as:",
    "options": [
      "$\\frac{TP}{TP+FP}$",
      "$\\frac{TP+TN}{TP+TN+FP+FN}$",
      "$\\frac{TP}{TP+FN}$",
      "$\\frac{TN}{TN+FP}$"
    ],
    "answer": 1
  },
  {
    "id": 62,
    "section": "Unit 4 \u2013 Evaluation",
    "text": "Accuracy is misleading when:",
    "options": [
      "Classes are highly imbalanced",
      "ROC AUC is high",
      "Precision equals recall",
      "Threshold is fixed"
    ],
    "answer": 0
  },
  {
    "id": 63,
    "section": "Unit 4 \u2013 Evaluation",
    "text": "Accuracy treats false positives and false negatives as:",
    "options": [
      "Equally important",
      "False positives only",
      "False negatives only",
      "Class-dependent"
    ],
    "answer": 0
  },
  {
    "id": 64,
    "section": "Unit 4 \u2013 Evaluation",
    "text": "Precision measures:",
    "options": [
      "Ability to detect positives",
      "Fraction of predicted positives that are correct",
      "Fraction of negatives detected",
      "Overall correctness"
    ],
    "answer": 1
  },
  {
    "id": 65,
    "section": "Unit 4 \u2013 Evaluation",
    "text": "Recall is also known as:",
    "options": [
      "Specificity",
      "Sensitivity",
      "Precision",
      "Negative predictive value"
    ],
    "answer": 1
  },
  {
    "id": 66,
    "section": "Unit 4 \u2013 Evaluation",
    "text": "Increasing the decision threshold typically:",
    "options": [
      "Increases recall and decreases precision",
      "Increases both precision and recall",
      "Increases precision and decreases recall",
      "Decreases both"
    ],
    "answer": 2
  },
  {
    "id": 67,
    "section": "Unit 4 \u2013 Evaluation",
    "text": "High recall but low precision implies:",
    "options": [
      "Few false positives",
      "Many false positives",
      "Few false negatives",
      "Balanced predictions"
    ],
    "answer": 1
  },
  {
    "id": 68,
    "section": "Unit 4 \u2013 Evaluation",
    "text": "The F1-score is the harmonic mean of:",
    "options": [
      "Accuracy and recall",
      "Precision and recall",
      "TPR and FPR",
      "Sensitivity and specificity"
    ],
    "answer": 1
  },
  {
    "id": 69,
    "section": "Unit 4 \u2013 Evaluation",
    "text": "F1-score is maximized when:",
    "options": [
      "Precision is high",
      "Recall is high",
      "Precision equals recall",
      "Accuracy is high"
    ],
    "answer": 2
  },
  {
    "id": 70,
    "section": "Unit 4 \u2013 Evaluation",
    "text": "Specificity is defined as:",
    "options": [
      "$\\frac{TN}{TN+FP}$",
      "$\\frac{TP}{TP+FN}$",
      "$\\frac{FP}{FP+TN}$",
      "$\\frac{TN}{TN+FN}$"
    ],
    "answer": 0
  },
  {
    "id": 71,
    "section": "Unit 4 \u2013 Evaluation",
    "text": "False positive rate (FPR) is equal to:",
    "options": [
      "$1-\\text{Specificity}$",
      "$1-\\text{Recall}$",
      "$1-\\text{Precision}$",
      "$1-\\text{Accuracy}$"
    ],
    "answer": 0
  },
  {
    "id": 72,
    "section": "Unit 4 \u2013 Evaluation",
    "text": "The ROC curve plots:",
    "options": [
      "Precision vs Recall",
      "TPR vs FPR",
      "Accuracy vs threshold",
      "Loss vs epochs"
    ],
    "answer": 1
  },
  {
    "id": 73,
    "section": "Unit 4 \u2013 Evaluation",
    "text": "A random classifier has ROC AUC equal to:",
    "options": [
      "0",
      "0.25",
      "0.5",
      "1"
    ],
    "answer": 2
  },
  {
    "id": 74,
    "section": "Unit 4 \u2013 Evaluation",
    "text": "The perfect classifier corresponds to ROC point:",
    "options": [
      "(1,0)",
      "(0,0)",
      "(1,1)",
      "(0,1)"
    ],
    "answer": 3
  },
  {
    "id": 75,
    "section": "Unit 4 \u2013 Evaluation",
    "text": "ROC curves are threshold-independent because they:",
    "options": [
      "Fix a threshold",
      "Integrate over all thresholds",
      "Use class labels only",
      "Ignore false positives"
    ],
    "answer": 1
  },
  {
    "id": 76,
    "section": "Unit 4 \u2013 Evaluation",
    "text": "Macro-averaging computes metrics by:",
    "options": [
      "Using global TP, FP, FN",
      "Averaging per-class metrics",
      "Weighting by class frequency",
      "Ignoring minority classes"
    ],
    "answer": 1
  },
  {
    "id": 77,
    "section": "Unit 4 \u2013 Evaluation",
    "text": "Micro-averaging differs from macro-averaging because it:",
    "options": [
      "Ignores class imbalance",
      "Uses global TP, FP, FN",
      "Weights minority classes more",
      "Averages per-class scores"
    ],
    "answer": 1
  },
  {
    "id": 78,
    "section": "Unit 4 \u2013 Evaluation",
    "text": "Micro-averaging is dominated by:",
    "options": [
      "Minority classes",
      "Majority classes",
      "All classes equally",
      "Random effects"
    ],
    "answer": 1
  },
  {
    "id": 79,
    "section": "Unit 4 \u2013 Evaluation",
    "text": "Which metric is most appropriate for rare disease detection?",
    "options": [
      "Accuracy",
      "Recall",
      "Specificity",
      "ROC AUC"
    ],
    "answer": 1
  },
  {
    "id": 80,
    "section": "Unit 4 \u2013 Evaluation",
    "text": "Precision\u2013recall curves are preferred over ROC when:",
    "options": [
      "Classes are balanced",
      "Classes are imbalanced",
      "Threshold is fixed",
      "Loss is convex"
    ],
    "answer": 1
  },
  {
    "id": 81,
    "section": "Unit 4 \u2013 Evaluation",
    "text": "Accuracy is defined as:",
    "options": [
      "$\\frac{TP}{TP+FP}$",
      "$\\frac{TP+TN}{TP+TN+FP+FN}$",
      "$\\frac{TP}{TP+FN}$",
      "$\\frac{TN}{TN+FP}$"
    ],
    "answer": 1
  },
  {
    "id": 82,
    "section": "Unit 4 \u2013 Evaluation",
    "text": "Accuracy is misleading when:",
    "options": [
      "Classes are highly imbalanced",
      "ROC AUC is high",
      "Precision equals recall",
      "Threshold is fixed"
    ],
    "answer": 0
  },
  {
    "id": 83,
    "section": "Unit 4 \u2013 Evaluation",
    "text": "Accuracy treats false positives and false negatives as:",
    "options": [
      "Equally important",
      "False positives only",
      "False negatives only",
      "Class-dependent"
    ],
    "answer": 0
  },
  {
    "id": 84,
    "section": "Unit 4 \u2013 Evaluation",
    "text": "Precision measures:",
    "options": [
      "Ability to detect positives",
      "Fraction of predicted positives that are correct",
      "Fraction of negatives detected",
      "Overall correctness"
    ],
    "answer": 1
  },
  {
    "id": 85,
    "section": "Unit 4 \u2013 Evaluation",
    "text": "Recall is also known as:",
    "options": [
      "Specificity",
      "Sensitivity",
      "Precision",
      "Negative predictive value"
    ],
    "answer": 1
  },
  {
    "id": 86,
    "section": "Unit 4 \u2013 Evaluation",
    "text": "Increasing the decision threshold typically:",
    "options": [
      "Increases recall and decreases precision",
      "Increases both precision and recall",
      "Increases precision and decreases recall",
      "Decreases both"
    ],
    "answer": 2
  },
  {
    "id": 87,
    "section": "Unit 4 \u2013 Evaluation",
    "text": "High recall but low precision implies:",
    "options": [
      "Few false positives",
      "Many false positives",
      "Few false negatives",
      "Balanced predictions"
    ],
    "answer": 1
  },
  {
    "id": 88,
    "section": "Unit 4 \u2013 Evaluation",
    "text": "The F1-score is the harmonic mean of:",
    "options": [
      "Accuracy and recall",
      "Precision and recall",
      "TPR and FPR",
      "Sensitivity and specificity"
    ],
    "answer": 1
  },
  {
    "id": 89,
    "section": "Unit 4 \u2013 Evaluation",
    "text": "F1-score is maximized when:",
    "options": [
      "Precision is high",
      "Recall is high",
      "Precision equals recall",
      "Accuracy is high"
    ],
    "answer": 2
  },
  {
    "id": 90,
    "section": "Unit 4 \u2013 Evaluation",
    "text": "Specificity is defined as:",
    "options": [
      "$\\frac{TN}{TN+FP}$",
      "$\\frac{TP}{TP+FN}$",
      "$\\frac{FP}{FP+TN}$",
      "$\\frac{TN}{TN+FN}$"
    ],
    "answer": 0
  },
  {
    "id": 91,
    "section": "Unit 4 \u2013 Evaluation",
    "text": "False positive rate (FPR) is equal to:",
    "options": [
      "$1-\\text{Specificity}$",
      "$1-\\text{Recall}$",
      "$1-\\text{Precision}$",
      "$1-\\text{Accuracy}$"
    ],
    "answer": 0
  },
  {
    "id": 92,
    "section": "Unit 4 \u2013 Evaluation",
    "text": "The ROC curve plots:",
    "options": [
      "Precision vs Recall",
      "TPR vs FPR",
      "Accuracy vs threshold",
      "Loss vs epochs"
    ],
    "answer": 1
  },
  {
    "id": 93,
    "section": "Unit 4 \u2013 Evaluation",
    "text": "A random classifier has ROC AUC equal to:",
    "options": [
      "0",
      "0.25",
      "0.5",
      "1"
    ],
    "answer": 2
  },
  {
    "id": 94,
    "section": "Unit 4 \u2013 Evaluation",
    "text": "The perfect classifier corresponds to ROC point:",
    "options": [
      "(1,0)",
      "(0,0)",
      "(1,1)",
      "(0,1)"
    ],
    "answer": 3
  },
  {
    "id": 95,
    "section": "Unit 4 \u2013 Evaluation",
    "text": "ROC curves are threshold-independent because they:",
    "options": [
      "Fix a threshold",
      "Integrate over all thresholds",
      "Use class labels only",
      "Ignore false positives"
    ],
    "answer": 1
  },
  {
    "id": 96,
    "section": "Unit 4 \u2013 Evaluation",
    "text": "Macro-averaging computes metrics by:",
    "options": [
      "Using global TP, FP, FN",
      "Averaging per-class metrics",
      "Weighting by class frequency",
      "Ignoring minority classes"
    ],
    "answer": 1
  },
  {
    "id": 97,
    "section": "Unit 4 \u2013 Evaluation",
    "text": "Micro-averaging differs from macro-averaging because it:",
    "options": [
      "Ignores class imbalance",
      "Uses global TP, FP, FN",
      "Weights minority classes more",
      "Averages per-class scores"
    ],
    "answer": 1
  },
  {
    "id": 98,
    "section": "Unit 4 \u2013 Evaluation",
    "text": "Micro-averaging is dominated by:",
    "options": [
      "Minority classes",
      "Majority classes",
      "All classes equally",
      "Random effects"
    ],
    "answer": 1
  },
  {
    "id": 99,
    "section": "Unit 4 \u2013 Evaluation",
    "text": "Which metric is most appropriate for rare disease detection?",
    "options": [
      "Accuracy",
      "Recall",
      "Specificity",
      "ROC AUC"
    ],
    "answer": 1
  },
  {
    "id": 100,
    "section": "Unit 4 \u2013 Evaluation",
    "text": "Precision\u2013recall curves are preferred over ROC when:",
    "options": [
      "Classes are balanced",
      "Classes are imbalanced",
      "Threshold is fixed",
      "Loss is convex"
    ],
    "answer": 1
  }
];