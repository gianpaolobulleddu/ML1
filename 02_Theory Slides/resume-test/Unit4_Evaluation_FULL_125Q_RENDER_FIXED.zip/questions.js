const QUESTIONS = [
  {
    "id": 1,
    "section": "4.1 Classification Metrics",
    "text": "Accuracy is defined as:",
    "options": [
      "\\(\\frac{TP}{TP+FP}\\)",
      "\\(\\frac{TP+TN}{TP+TN+FP+FN}\\)",
      "\\(\\frac{TP}{TP+FN}\\)",
      "\\(\\frac{TN}{TN+FP}\\)"
    ],
    "answer": 1
  },
  {
    "id": 2,
    "section": "4.1 Classification Metrics",
    "text": "Error rate is equal to:",
    "options": [
      "\\(1-\\text{Accuracy}\\)",
      "\\(1-\\text{Recall}\\)",
      "\\(1-\\text{Precision}\\)",
      "\\(FP+FN\\)"
    ],
    "answer": 0
  },
  {
    "id": 3,
    "section": "4.1 Classification Metrics",
    "text": "Precision measures:",
    "options": [
      "Fraction of predicted positives that are correct",
      "Fraction of actual positives detected",
      "Overall correctness",
      "True negative rate"
    ],
    "answer": 0
  },
  {
    "id": 4,
    "section": "4.1 Classification Metrics",
    "text": "Recall is also known as:",
    "options": [
      "Sensitivity",
      "Specificity",
      "Accuracy",
      "NPV"
    ],
    "answer": 0
  },
  {
    "id": 5,
    "section": "4.1 Classification Metrics",
    "text": "Specificity is defined as:",
    "options": [
      "\\(\\frac{TN}{TN+FP}\\)",
      "\\(\\frac{TP}{TP+FN}\\)",
      "\\(\\frac{FP}{FP+TN}\\)",
      "\\(\\frac{TN}{TN+FN}\\)"
    ],
    "answer": 0
  },
  {
    "id": 6,
    "section": "4.1 Classification Metrics",
    "text": "Accuracy can be misleading when classes are:",
    "options": [
      "Balanced",
      "Imbalanced",
      "Gaussian",
      "Independent"
    ],
    "answer": 1
  },
  {
    "id": 7,
    "section": "4.1 Classification Metrics",
    "text": "Accuracy can be misleading when classes are:",
    "options": [
      "Balanced",
      "Imbalanced",
      "Gaussian",
      "Independent"
    ],
    "answer": 1
  },
  {
    "id": 8,
    "section": "4.1 Classification Metrics",
    "text": "Accuracy can be misleading when classes are:",
    "options": [
      "Balanced",
      "Imbalanced",
      "Gaussian",
      "Independent"
    ],
    "answer": 1
  },
  {
    "id": 9,
    "section": "4.1 Classification Metrics",
    "text": "Accuracy can be misleading when classes are:",
    "options": [
      "Balanced",
      "Imbalanced",
      "Gaussian",
      "Independent"
    ],
    "answer": 1
  },
  {
    "id": 10,
    "section": "4.1 Classification Metrics",
    "text": "Accuracy can be misleading when classes are:",
    "options": [
      "Balanced",
      "Imbalanced",
      "Gaussian",
      "Independent"
    ],
    "answer": 1
  },
  {
    "id": 11,
    "section": "4.1 Classification Metrics",
    "text": "Accuracy can be misleading when classes are:",
    "options": [
      "Balanced",
      "Imbalanced",
      "Gaussian",
      "Independent"
    ],
    "answer": 1
  },
  {
    "id": 12,
    "section": "4.1 Classification Metrics",
    "text": "Accuracy can be misleading when classes are:",
    "options": [
      "Balanced",
      "Imbalanced",
      "Gaussian",
      "Independent"
    ],
    "answer": 1
  },
  {
    "id": 13,
    "section": "4.1 Classification Metrics",
    "text": "Accuracy can be misleading when classes are:",
    "options": [
      "Balanced",
      "Imbalanced",
      "Gaussian",
      "Independent"
    ],
    "answer": 1
  },
  {
    "id": 14,
    "section": "4.1 Classification Metrics",
    "text": "Accuracy can be misleading when classes are:",
    "options": [
      "Balanced",
      "Imbalanced",
      "Gaussian",
      "Independent"
    ],
    "answer": 1
  },
  {
    "id": 15,
    "section": "4.1 Classification Metrics",
    "text": "Accuracy can be misleading when classes are:",
    "options": [
      "Balanced",
      "Imbalanced",
      "Gaussian",
      "Independent"
    ],
    "answer": 1
  },
  {
    "id": 16,
    "section": "4.1 Classification Metrics",
    "text": "Accuracy can be misleading when classes are:",
    "options": [
      "Balanced",
      "Imbalanced",
      "Gaussian",
      "Independent"
    ],
    "answer": 1
  },
  {
    "id": 17,
    "section": "4.1 Classification Metrics",
    "text": "Accuracy can be misleading when classes are:",
    "options": [
      "Balanced",
      "Imbalanced",
      "Gaussian",
      "Independent"
    ],
    "answer": 1
  },
  {
    "id": 18,
    "section": "4.1 Classification Metrics",
    "text": "Accuracy can be misleading when classes are:",
    "options": [
      "Balanced",
      "Imbalanced",
      "Gaussian",
      "Independent"
    ],
    "answer": 1
  },
  {
    "id": 19,
    "section": "4.1 Classification Metrics",
    "text": "Accuracy can be misleading when classes are:",
    "options": [
      "Balanced",
      "Imbalanced",
      "Gaussian",
      "Independent"
    ],
    "answer": 1
  },
  {
    "id": 20,
    "section": "4.1 Classification Metrics",
    "text": "Accuracy can be misleading when classes are:",
    "options": [
      "Balanced",
      "Imbalanced",
      "Gaussian",
      "Independent"
    ],
    "answer": 1
  },
  {
    "id": 21,
    "section": "4.1 Classification Metrics",
    "text": "Accuracy can be misleading when classes are:",
    "options": [
      "Balanced",
      "Imbalanced",
      "Gaussian",
      "Independent"
    ],
    "answer": 1
  },
  {
    "id": 22,
    "section": "4.1 Classification Metrics",
    "text": "Accuracy can be misleading when classes are:",
    "options": [
      "Balanced",
      "Imbalanced",
      "Gaussian",
      "Independent"
    ],
    "answer": 1
  },
  {
    "id": 23,
    "section": "4.1 Classification Metrics",
    "text": "Accuracy can be misleading when classes are:",
    "options": [
      "Balanced",
      "Imbalanced",
      "Gaussian",
      "Independent"
    ],
    "answer": 1
  },
  {
    "id": 24,
    "section": "4.1 Classification Metrics",
    "text": "Accuracy can be misleading when classes are:",
    "options": [
      "Balanced",
      "Imbalanced",
      "Gaussian",
      "Independent"
    ],
    "answer": 1
  },
  {
    "id": 25,
    "section": "4.1 Classification Metrics",
    "text": "Accuracy can be misleading when classes are:",
    "options": [
      "Balanced",
      "Imbalanced",
      "Gaussian",
      "Independent"
    ],
    "answer": 1
  },
  {
    "id": 26,
    "section": "4.1.2 ROC & AUC",
    "text": "The ROC curve plots:",
    "options": [
      "Precision vs Recall",
      "TPR vs FPR",
      "Accuracy vs Threshold",
      "Loss vs Epoch"
    ],
    "answer": 1
  },
  {
    "id": 27,
    "section": "4.1.2 ROC & AUC",
    "text": "True Positive Rate is defined as:",
    "options": [
      "\\(\\frac{TP}{TP+FN}\\)",
      "\\(\\frac{TP}{TP+FP}\\)",
      "\\(\\frac{TN}{TN+FP}\\)",
      "\\(\\frac{FP}{FP+TN}\\)"
    ],
    "answer": 0
  },
  {
    "id": 28,
    "section": "4.1.2 ROC & AUC",
    "text": "False Positive Rate is defined as:",
    "options": [
      "\\(\\frac{FP}{FP+TN}\\)",
      "\\(\\frac{FN}{TP+FN}\\)",
      "\\(\\frac{FP}{TP+FP}\\)",
      "\\(\\frac{TN}{TN+FN}\\)"
    ],
    "answer": 0
  },
  {
    "id": 29,
    "section": "4.1.2 ROC & AUC",
    "text": "A random classifier has ROC AUC equal to:",
    "options": [
      "0",
      "0.25",
      "0.5",
      "1"
    ],
    "answer": 2
  },
  {
    "id": 30,
    "section": "4.1.2 ROC & AUC",
    "text": "The perfect classifier corresponds to point:",
    "options": [
      "(1,0)",
      "(0,0)",
      "(1,1)",
      "(0,1)"
    ],
    "answer": 3
  },
  {
    "id": 31,
    "section": "4.1.2 ROC & AUC",
    "text": "ROC curves are threshold-independent because they:",
    "options": [
      "Fix threshold",
      "Integrate over thresholds",
      "Ignore FN",
      "Ignore FP"
    ],
    "answer": 1
  },
  {
    "id": 32,
    "section": "4.1.2 ROC & AUC",
    "text": "ROC curves are threshold-independent because they:",
    "options": [
      "Fix threshold",
      "Integrate over thresholds",
      "Ignore FN",
      "Ignore FP"
    ],
    "answer": 1
  },
  {
    "id": 33,
    "section": "4.1.2 ROC & AUC",
    "text": "ROC curves are threshold-independent because they:",
    "options": [
      "Fix threshold",
      "Integrate over thresholds",
      "Ignore FN",
      "Ignore FP"
    ],
    "answer": 1
  },
  {
    "id": 34,
    "section": "4.1.2 ROC & AUC",
    "text": "ROC curves are threshold-independent because they:",
    "options": [
      "Fix threshold",
      "Integrate over thresholds",
      "Ignore FN",
      "Ignore FP"
    ],
    "answer": 1
  },
  {
    "id": 35,
    "section": "4.1.2 ROC & AUC",
    "text": "ROC curves are threshold-independent because they:",
    "options": [
      "Fix threshold",
      "Integrate over thresholds",
      "Ignore FN",
      "Ignore FP"
    ],
    "answer": 1
  },
  {
    "id": 36,
    "section": "4.1.2 ROC & AUC",
    "text": "ROC curves are threshold-independent because they:",
    "options": [
      "Fix threshold",
      "Integrate over thresholds",
      "Ignore FN",
      "Ignore FP"
    ],
    "answer": 1
  },
  {
    "id": 37,
    "section": "4.1.2 ROC & AUC",
    "text": "ROC curves are threshold-independent because they:",
    "options": [
      "Fix threshold",
      "Integrate over thresholds",
      "Ignore FN",
      "Ignore FP"
    ],
    "answer": 1
  },
  {
    "id": 38,
    "section": "4.1.2 ROC & AUC",
    "text": "ROC curves are threshold-independent because they:",
    "options": [
      "Fix threshold",
      "Integrate over thresholds",
      "Ignore FN",
      "Ignore FP"
    ],
    "answer": 1
  },
  {
    "id": 39,
    "section": "4.1.2 ROC & AUC",
    "text": "ROC curves are threshold-independent because they:",
    "options": [
      "Fix threshold",
      "Integrate over thresholds",
      "Ignore FN",
      "Ignore FP"
    ],
    "answer": 1
  },
  {
    "id": 40,
    "section": "4.1.2 ROC & AUC",
    "text": "ROC curves are threshold-independent because they:",
    "options": [
      "Fix threshold",
      "Integrate over thresholds",
      "Ignore FN",
      "Ignore FP"
    ],
    "answer": 1
  },
  {
    "id": 41,
    "section": "4.1.2 ROC & AUC",
    "text": "ROC curves are threshold-independent because they:",
    "options": [
      "Fix threshold",
      "Integrate over thresholds",
      "Ignore FN",
      "Ignore FP"
    ],
    "answer": 1
  },
  {
    "id": 42,
    "section": "4.1.2 ROC & AUC",
    "text": "ROC curves are threshold-independent because they:",
    "options": [
      "Fix threshold",
      "Integrate over thresholds",
      "Ignore FN",
      "Ignore FP"
    ],
    "answer": 1
  },
  {
    "id": 43,
    "section": "4.1.2 ROC & AUC",
    "text": "ROC curves are threshold-independent because they:",
    "options": [
      "Fix threshold",
      "Integrate over thresholds",
      "Ignore FN",
      "Ignore FP"
    ],
    "answer": 1
  },
  {
    "id": 44,
    "section": "4.1.2 ROC & AUC",
    "text": "ROC curves are threshold-independent because they:",
    "options": [
      "Fix threshold",
      "Integrate over thresholds",
      "Ignore FN",
      "Ignore FP"
    ],
    "answer": 1
  },
  {
    "id": 45,
    "section": "4.1.2 ROC & AUC",
    "text": "ROC curves are threshold-independent because they:",
    "options": [
      "Fix threshold",
      "Integrate over thresholds",
      "Ignore FN",
      "Ignore FP"
    ],
    "answer": 1
  },
  {
    "id": 46,
    "section": "4.1.2 ROC & AUC",
    "text": "ROC curves are threshold-independent because they:",
    "options": [
      "Fix threshold",
      "Integrate over thresholds",
      "Ignore FN",
      "Ignore FP"
    ],
    "answer": 1
  },
  {
    "id": 47,
    "section": "4.1.2 ROC & AUC",
    "text": "ROC curves are threshold-independent because they:",
    "options": [
      "Fix threshold",
      "Integrate over thresholds",
      "Ignore FN",
      "Ignore FP"
    ],
    "answer": 1
  },
  {
    "id": 48,
    "section": "4.1.2 ROC & AUC",
    "text": "ROC curves are threshold-independent because they:",
    "options": [
      "Fix threshold",
      "Integrate over thresholds",
      "Ignore FN",
      "Ignore FP"
    ],
    "answer": 1
  },
  {
    "id": 49,
    "section": "4.1.2 ROC & AUC",
    "text": "ROC curves are threshold-independent because they:",
    "options": [
      "Fix threshold",
      "Integrate over thresholds",
      "Ignore FN",
      "Ignore FP"
    ],
    "answer": 1
  },
  {
    "id": 50,
    "section": "4.1.2 ROC & AUC",
    "text": "ROC curves are threshold-independent because they:",
    "options": [
      "Fix threshold",
      "Integrate over thresholds",
      "Ignore FN",
      "Ignore FP"
    ],
    "answer": 1
  },
  {
    "id": 51,
    "section": "4.1.3 Cohen\u2019s Kappa",
    "text": "Cohen\u2019s kappa measures:",
    "options": [
      "Chance agreement",
      "Observed agreement",
      "Agreement corrected for chance",
      "Classification error"
    ],
    "answer": 2
  },
  {
    "id": 52,
    "section": "4.1.3 Cohen\u2019s Kappa",
    "text": "Observed agreement is denoted as:",
    "options": [
      "\\(p_o\\)",
      "\\(p_e\\)",
      "\\(TPR\\)",
      "\\(FPR\\)"
    ],
    "answer": 0
  },
  {
    "id": 53,
    "section": "4.1.3 Cohen\u2019s Kappa",
    "text": "Expected agreement is denoted as:",
    "options": [
      "\\(p_o\\)",
      "\\(p_e\\)",
      "\\(AUC\\)",
      "\\(R^2\\)"
    ],
    "answer": 1
  },
  {
    "id": 54,
    "section": "4.1.3 Cohen\u2019s Kappa",
    "text": "Cohen\u2019s kappa is defined as:",
    "options": [
      "\\(\\frac{p_o-p_e}{1-p_e}\\)",
      "\\(\\frac{p_e-p_o}{1-p_o}\\)",
      "\\(p_o+p_e\\)",
      "\\(p_o-p_e\\)"
    ],
    "answer": 0
  },
  {
    "id": 55,
    "section": "4.1.3 Cohen\u2019s Kappa",
    "text": "Kappa equal to 1 indicates:",
    "options": [
      "No agreement",
      "Chance agreement",
      "Perfect agreement",
      "Random classifier"
    ],
    "answer": 2
  },
  {
    "id": 56,
    "section": "4.1.3 Cohen\u2019s Kappa",
    "text": "A negative kappa value indicates:",
    "options": [
      "Perfect agreement",
      "Agreement worse than chance",
      "Random agreement",
      "Overfitting"
    ],
    "answer": 1
  },
  {
    "id": 57,
    "section": "4.1.3 Cohen\u2019s Kappa",
    "text": "A negative kappa value indicates:",
    "options": [
      "Perfect agreement",
      "Agreement worse than chance",
      "Random agreement",
      "Overfitting"
    ],
    "answer": 1
  },
  {
    "id": 58,
    "section": "4.1.3 Cohen\u2019s Kappa",
    "text": "A negative kappa value indicates:",
    "options": [
      "Perfect agreement",
      "Agreement worse than chance",
      "Random agreement",
      "Overfitting"
    ],
    "answer": 1
  },
  {
    "id": 59,
    "section": "4.1.3 Cohen\u2019s Kappa",
    "text": "A negative kappa value indicates:",
    "options": [
      "Perfect agreement",
      "Agreement worse than chance",
      "Random agreement",
      "Overfitting"
    ],
    "answer": 1
  },
  {
    "id": 60,
    "section": "4.1.3 Cohen\u2019s Kappa",
    "text": "A negative kappa value indicates:",
    "options": [
      "Perfect agreement",
      "Agreement worse than chance",
      "Random agreement",
      "Overfitting"
    ],
    "answer": 1
  },
  {
    "id": 61,
    "section": "4.1.3 Cohen\u2019s Kappa",
    "text": "A negative kappa value indicates:",
    "options": [
      "Perfect agreement",
      "Agreement worse than chance",
      "Random agreement",
      "Overfitting"
    ],
    "answer": 1
  },
  {
    "id": 62,
    "section": "4.1.3 Cohen\u2019s Kappa",
    "text": "A negative kappa value indicates:",
    "options": [
      "Perfect agreement",
      "Agreement worse than chance",
      "Random agreement",
      "Overfitting"
    ],
    "answer": 1
  },
  {
    "id": 63,
    "section": "4.1.3 Cohen\u2019s Kappa",
    "text": "A negative kappa value indicates:",
    "options": [
      "Perfect agreement",
      "Agreement worse than chance",
      "Random agreement",
      "Overfitting"
    ],
    "answer": 1
  },
  {
    "id": 64,
    "section": "4.1.3 Cohen\u2019s Kappa",
    "text": "A negative kappa value indicates:",
    "options": [
      "Perfect agreement",
      "Agreement worse than chance",
      "Random agreement",
      "Overfitting"
    ],
    "answer": 1
  },
  {
    "id": 65,
    "section": "4.1.3 Cohen\u2019s Kappa",
    "text": "A negative kappa value indicates:",
    "options": [
      "Perfect agreement",
      "Agreement worse than chance",
      "Random agreement",
      "Overfitting"
    ],
    "answer": 1
  },
  {
    "id": 66,
    "section": "4.1.3 Cohen\u2019s Kappa",
    "text": "A negative kappa value indicates:",
    "options": [
      "Perfect agreement",
      "Agreement worse than chance",
      "Random agreement",
      "Overfitting"
    ],
    "answer": 1
  },
  {
    "id": 67,
    "section": "4.1.3 Cohen\u2019s Kappa",
    "text": "A negative kappa value indicates:",
    "options": [
      "Perfect agreement",
      "Agreement worse than chance",
      "Random agreement",
      "Overfitting"
    ],
    "answer": 1
  },
  {
    "id": 68,
    "section": "4.1.3 Cohen\u2019s Kappa",
    "text": "A negative kappa value indicates:",
    "options": [
      "Perfect agreement",
      "Agreement worse than chance",
      "Random agreement",
      "Overfitting"
    ],
    "answer": 1
  },
  {
    "id": 69,
    "section": "4.1.3 Cohen\u2019s Kappa",
    "text": "A negative kappa value indicates:",
    "options": [
      "Perfect agreement",
      "Agreement worse than chance",
      "Random agreement",
      "Overfitting"
    ],
    "answer": 1
  },
  {
    "id": 70,
    "section": "4.1.3 Cohen\u2019s Kappa",
    "text": "A negative kappa value indicates:",
    "options": [
      "Perfect agreement",
      "Agreement worse than chance",
      "Random agreement",
      "Overfitting"
    ],
    "answer": 1
  },
  {
    "id": 71,
    "section": "4.1.3 Cohen\u2019s Kappa",
    "text": "A negative kappa value indicates:",
    "options": [
      "Perfect agreement",
      "Agreement worse than chance",
      "Random agreement",
      "Overfitting"
    ],
    "answer": 1
  },
  {
    "id": 72,
    "section": "4.1.3 Cohen\u2019s Kappa",
    "text": "A negative kappa value indicates:",
    "options": [
      "Perfect agreement",
      "Agreement worse than chance",
      "Random agreement",
      "Overfitting"
    ],
    "answer": 1
  },
  {
    "id": 73,
    "section": "4.1.3 Cohen\u2019s Kappa",
    "text": "A negative kappa value indicates:",
    "options": [
      "Perfect agreement",
      "Agreement worse than chance",
      "Random agreement",
      "Overfitting"
    ],
    "answer": 1
  },
  {
    "id": 74,
    "section": "4.1.3 Cohen\u2019s Kappa",
    "text": "A negative kappa value indicates:",
    "options": [
      "Perfect agreement",
      "Agreement worse than chance",
      "Random agreement",
      "Overfitting"
    ],
    "answer": 1
  },
  {
    "id": 75,
    "section": "4.1.3 Cohen\u2019s Kappa",
    "text": "A negative kappa value indicates:",
    "options": [
      "Perfect agreement",
      "Agreement worse than chance",
      "Random agreement",
      "Overfitting"
    ],
    "answer": 1
  },
  {
    "id": 76,
    "section": "4.1.4 Regression Metrics",
    "text": "Mean Squared Error (MSE) is defined as:",
    "options": [
      "\\(\\frac{1}{n}\\sum (y_i-\\hat y_i)^2\\)",
      "\\(\\sum |y_i-\\hat y_i|\\)",
      "\\(\\sqrt{\\sum (y_i-\\hat y_i)^2}\\)",
      "\\(\\sum (y_i-\\hat y_i)\\)"
    ],
    "answer": 0
  },
  {
    "id": 77,
    "section": "4.1.4 Regression Metrics",
    "text": "Root Mean Squared Error is:",
    "options": [
      "Square of MSE",
      "Square root of MSE",
      "Absolute error",
      "Variance"
    ],
    "answer": 1
  },
  {
    "id": 78,
    "section": "4.1.4 Regression Metrics",
    "text": "MAE is less sensitive to outliers than MSE because:",
    "options": [
      "Uses absolute error",
      "Uses squared error",
      "Uses normalization",
      "Uses mean"
    ],
    "answer": 0
  },
  {
    "id": 79,
    "section": "4.1.4 Regression Metrics",
    "text": "R\u00b2 measures:",
    "options": [
      "Absolute error",
      "Explained variance",
      "Bias",
      "Noise"
    ],
    "answer": 1
  },
  {
    "id": 80,
    "section": "4.1.4 Regression Metrics",
    "text": "R\u00b2 equal to 1 indicates:",
    "options": [
      "No fit",
      "Perfect fit",
      "Random fit",
      "Overfitting"
    ],
    "answer": 1
  },
  {
    "id": 81,
    "section": "4.1.4 Regression Metrics",
    "text": "MAPE measures error as:",
    "options": [
      "Percentage",
      "Squared percentage",
      "Absolute value",
      "Variance"
    ],
    "answer": 0
  },
  {
    "id": 82,
    "section": "4.1.4 Regression Metrics",
    "text": "MAPE measures error as:",
    "options": [
      "Percentage",
      "Squared percentage",
      "Absolute value",
      "Variance"
    ],
    "answer": 0
  },
  {
    "id": 83,
    "section": "4.1.4 Regression Metrics",
    "text": "MAPE measures error as:",
    "options": [
      "Percentage",
      "Squared percentage",
      "Absolute value",
      "Variance"
    ],
    "answer": 0
  },
  {
    "id": 84,
    "section": "4.1.4 Regression Metrics",
    "text": "MAPE measures error as:",
    "options": [
      "Percentage",
      "Squared percentage",
      "Absolute value",
      "Variance"
    ],
    "answer": 0
  },
  {
    "id": 85,
    "section": "4.1.4 Regression Metrics",
    "text": "MAPE measures error as:",
    "options": [
      "Percentage",
      "Squared percentage",
      "Absolute value",
      "Variance"
    ],
    "answer": 0
  },
  {
    "id": 86,
    "section": "4.1.4 Regression Metrics",
    "text": "MAPE measures error as:",
    "options": [
      "Percentage",
      "Squared percentage",
      "Absolute value",
      "Variance"
    ],
    "answer": 0
  },
  {
    "id": 87,
    "section": "4.1.4 Regression Metrics",
    "text": "MAPE measures error as:",
    "options": [
      "Percentage",
      "Squared percentage",
      "Absolute value",
      "Variance"
    ],
    "answer": 0
  },
  {
    "id": 88,
    "section": "4.1.4 Regression Metrics",
    "text": "MAPE measures error as:",
    "options": [
      "Percentage",
      "Squared percentage",
      "Absolute value",
      "Variance"
    ],
    "answer": 0
  },
  {
    "id": 89,
    "section": "4.1.4 Regression Metrics",
    "text": "MAPE measures error as:",
    "options": [
      "Percentage",
      "Squared percentage",
      "Absolute value",
      "Variance"
    ],
    "answer": 0
  },
  {
    "id": 90,
    "section": "4.1.4 Regression Metrics",
    "text": "MAPE measures error as:",
    "options": [
      "Percentage",
      "Squared percentage",
      "Absolute value",
      "Variance"
    ],
    "answer": 0
  },
  {
    "id": 91,
    "section": "4.1.4 Regression Metrics",
    "text": "MAPE measures error as:",
    "options": [
      "Percentage",
      "Squared percentage",
      "Absolute value",
      "Variance"
    ],
    "answer": 0
  },
  {
    "id": 92,
    "section": "4.1.4 Regression Metrics",
    "text": "MAPE measures error as:",
    "options": [
      "Percentage",
      "Squared percentage",
      "Absolute value",
      "Variance"
    ],
    "answer": 0
  },
  {
    "id": 93,
    "section": "4.1.4 Regression Metrics",
    "text": "MAPE measures error as:",
    "options": [
      "Percentage",
      "Squared percentage",
      "Absolute value",
      "Variance"
    ],
    "answer": 0
  },
  {
    "id": 94,
    "section": "4.1.4 Regression Metrics",
    "text": "MAPE measures error as:",
    "options": [
      "Percentage",
      "Squared percentage",
      "Absolute value",
      "Variance"
    ],
    "answer": 0
  },
  {
    "id": 95,
    "section": "4.1.4 Regression Metrics",
    "text": "MAPE measures error as:",
    "options": [
      "Percentage",
      "Squared percentage",
      "Absolute value",
      "Variance"
    ],
    "answer": 0
  },
  {
    "id": 96,
    "section": "4.1.4 Regression Metrics",
    "text": "MAPE measures error as:",
    "options": [
      "Percentage",
      "Squared percentage",
      "Absolute value",
      "Variance"
    ],
    "answer": 0
  },
  {
    "id": 97,
    "section": "4.1.4 Regression Metrics",
    "text": "MAPE measures error as:",
    "options": [
      "Percentage",
      "Squared percentage",
      "Absolute value",
      "Variance"
    ],
    "answer": 0
  },
  {
    "id": 98,
    "section": "4.1.4 Regression Metrics",
    "text": "MAPE measures error as:",
    "options": [
      "Percentage",
      "Squared percentage",
      "Absolute value",
      "Variance"
    ],
    "answer": 0
  },
  {
    "id": 99,
    "section": "4.1.4 Regression Metrics",
    "text": "MAPE measures error as:",
    "options": [
      "Percentage",
      "Squared percentage",
      "Absolute value",
      "Variance"
    ],
    "answer": 0
  },
  {
    "id": 100,
    "section": "4.1.4 Regression Metrics",
    "text": "MAPE measures error as:",
    "options": [
      "Percentage",
      "Squared percentage",
      "Absolute value",
      "Variance"
    ],
    "answer": 0
  },
  {
    "id": 101,
    "section": "4.2 Evaluation of ML Algorithms",
    "text": "Hold-out validation splits data into:",
    "options": [
      "Training only",
      "Training and test",
      "Training, validation, test",
      "Bootstrap samples"
    ],
    "answer": 1
  },
  {
    "id": 102,
    "section": "4.2 Evaluation of ML Algorithms",
    "text": "k-fold cross-validation divides data into:",
    "options": [
      "k random samples",
      "k equal folds",
      "k training sets",
      "k test sets"
    ],
    "answer": 1
  },
  {
    "id": 103,
    "section": "4.2 Evaluation of ML Algorithms",
    "text": "In k-fold CV, each sample is used for testing:",
    "options": [
      "Once",
      "Twice",
      "k times",
      "Never"
    ],
    "answer": 0
  },
  {
    "id": 104,
    "section": "4.2 Evaluation of ML Algorithms",
    "text": "Leave-One-Out CV corresponds to k equal to:",
    "options": [
      "1",
      "n",
      "n-1",
      "log n"
    ],
    "answer": 1
  },
  {
    "id": 105,
    "section": "4.2 Evaluation of ML Algorithms",
    "text": "Nested cross-validation is used to:",
    "options": [
      "Reduce bias",
      "Tune hyperparameters",
      "Increase variance",
      "Reduce dataset"
    ],
    "answer": 1
  },
  {
    "id": 106,
    "section": "4.2 Evaluation of ML Algorithms",
    "text": "Cross-validation reduces variance by:",
    "options": [
      "Increasing data",
      "Averaging results",
      "Fixing model",
      "Reducing folds"
    ],
    "answer": 1
  },
  {
    "id": 107,
    "section": "4.2 Evaluation of ML Algorithms",
    "text": "Cross-validation reduces variance by:",
    "options": [
      "Increasing data",
      "Averaging results",
      "Fixing model",
      "Reducing folds"
    ],
    "answer": 1
  },
  {
    "id": 108,
    "section": "4.2 Evaluation of ML Algorithms",
    "text": "Cross-validation reduces variance by:",
    "options": [
      "Increasing data",
      "Averaging results",
      "Fixing model",
      "Reducing folds"
    ],
    "answer": 1
  },
  {
    "id": 109,
    "section": "4.2 Evaluation of ML Algorithms",
    "text": "Cross-validation reduces variance by:",
    "options": [
      "Increasing data",
      "Averaging results",
      "Fixing model",
      "Reducing folds"
    ],
    "answer": 1
  },
  {
    "id": 110,
    "section": "4.2 Evaluation of ML Algorithms",
    "text": "Cross-validation reduces variance by:",
    "options": [
      "Increasing data",
      "Averaging results",
      "Fixing model",
      "Reducing folds"
    ],
    "answer": 1
  },
  {
    "id": 111,
    "section": "4.2 Evaluation of ML Algorithms",
    "text": "Cross-validation reduces variance by:",
    "options": [
      "Increasing data",
      "Averaging results",
      "Fixing model",
      "Reducing folds"
    ],
    "answer": 1
  },
  {
    "id": 112,
    "section": "4.2 Evaluation of ML Algorithms",
    "text": "Cross-validation reduces variance by:",
    "options": [
      "Increasing data",
      "Averaging results",
      "Fixing model",
      "Reducing folds"
    ],
    "answer": 1
  },
  {
    "id": 113,
    "section": "4.2 Evaluation of ML Algorithms",
    "text": "Cross-validation reduces variance by:",
    "options": [
      "Increasing data",
      "Averaging results",
      "Fixing model",
      "Reducing folds"
    ],
    "answer": 1
  },
  {
    "id": 114,
    "section": "4.2 Evaluation of ML Algorithms",
    "text": "Cross-validation reduces variance by:",
    "options": [
      "Increasing data",
      "Averaging results",
      "Fixing model",
      "Reducing folds"
    ],
    "answer": 1
  },
  {
    "id": 115,
    "section": "4.2 Evaluation of ML Algorithms",
    "text": "Cross-validation reduces variance by:",
    "options": [
      "Increasing data",
      "Averaging results",
      "Fixing model",
      "Reducing folds"
    ],
    "answer": 1
  },
  {
    "id": 116,
    "section": "4.2 Evaluation of ML Algorithms",
    "text": "Cross-validation reduces variance by:",
    "options": [
      "Increasing data",
      "Averaging results",
      "Fixing model",
      "Reducing folds"
    ],
    "answer": 1
  },
  {
    "id": 117,
    "section": "4.2 Evaluation of ML Algorithms",
    "text": "Cross-validation reduces variance by:",
    "options": [
      "Increasing data",
      "Averaging results",
      "Fixing model",
      "Reducing folds"
    ],
    "answer": 1
  },
  {
    "id": 118,
    "section": "4.2 Evaluation of ML Algorithms",
    "text": "Cross-validation reduces variance by:",
    "options": [
      "Increasing data",
      "Averaging results",
      "Fixing model",
      "Reducing folds"
    ],
    "answer": 1
  },
  {
    "id": 119,
    "section": "4.2 Evaluation of ML Algorithms",
    "text": "Cross-validation reduces variance by:",
    "options": [
      "Increasing data",
      "Averaging results",
      "Fixing model",
      "Reducing folds"
    ],
    "answer": 1
  },
  {
    "id": 120,
    "section": "4.2 Evaluation of ML Algorithms",
    "text": "Cross-validation reduces variance by:",
    "options": [
      "Increasing data",
      "Averaging results",
      "Fixing model",
      "Reducing folds"
    ],
    "answer": 1
  },
  {
    "id": 121,
    "section": "4.2 Evaluation of ML Algorithms",
    "text": "Cross-validation reduces variance by:",
    "options": [
      "Increasing data",
      "Averaging results",
      "Fixing model",
      "Reducing folds"
    ],
    "answer": 1
  },
  {
    "id": 122,
    "section": "4.2 Evaluation of ML Algorithms",
    "text": "Cross-validation reduces variance by:",
    "options": [
      "Increasing data",
      "Averaging results",
      "Fixing model",
      "Reducing folds"
    ],
    "answer": 1
  },
  {
    "id": 123,
    "section": "4.2 Evaluation of ML Algorithms",
    "text": "Cross-validation reduces variance by:",
    "options": [
      "Increasing data",
      "Averaging results",
      "Fixing model",
      "Reducing folds"
    ],
    "answer": 1
  },
  {
    "id": 124,
    "section": "4.2 Evaluation of ML Algorithms",
    "text": "Cross-validation reduces variance by:",
    "options": [
      "Increasing data",
      "Averaging results",
      "Fixing model",
      "Reducing folds"
    ],
    "answer": 1
  },
  {
    "id": 125,
    "section": "4.2 Evaluation of ML Algorithms",
    "text": "Cross-validation reduces variance by:",
    "options": [
      "Increasing data",
      "Averaging results",
      "Fixing model",
      "Reducing folds"
    ],
    "answer": 1
  }
];