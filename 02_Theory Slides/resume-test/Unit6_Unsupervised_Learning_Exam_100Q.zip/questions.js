const QUESTIONS = [
  {
    "id": 1,
    "section": "Unit6_Unsupervised_Learning",
    "text": "Clustering: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Clustering",
      "Common pitfall in Clustering",
      "Correct principle of Clustering",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 2,
    "section": "Unit6_Unsupervised_Learning",
    "text": "Clustering: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Clustering",
      "Common pitfall in Clustering",
      "Correct principle of Clustering",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 3,
    "section": "Unit6_Unsupervised_Learning",
    "text": "Clustering: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Clustering",
      "Common pitfall in Clustering",
      "Correct principle of Clustering",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 4,
    "section": "Unit6_Unsupervised_Learning",
    "text": "Clustering: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Clustering",
      "Common pitfall in Clustering",
      "Correct principle of Clustering",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 5,
    "section": "Unit6_Unsupervised_Learning",
    "text": "Clustering: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Clustering",
      "Common pitfall in Clustering",
      "Correct principle of Clustering",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 6,
    "section": "Unit6_Unsupervised_Learning",
    "text": "Clustering: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Clustering",
      "Common pitfall in Clustering",
      "Correct principle of Clustering",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 7,
    "section": "Unit6_Unsupervised_Learning",
    "text": "Clustering: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Clustering",
      "Common pitfall in Clustering",
      "Correct principle of Clustering",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 8,
    "section": "Unit6_Unsupervised_Learning",
    "text": "Clustering: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Clustering",
      "Common pitfall in Clustering",
      "Correct principle of Clustering",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 9,
    "section": "Unit6_Unsupervised_Learning",
    "text": "Clustering: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Clustering",
      "Common pitfall in Clustering",
      "Correct principle of Clustering",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 10,
    "section": "Unit6_Unsupervised_Learning",
    "text": "Clustering: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Clustering",
      "Common pitfall in Clustering",
      "Correct principle of Clustering",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 11,
    "section": "Unit6_Unsupervised_Learning",
    "text": "k-means: Which statement is correct?",
    "options": [
      "Incorrect interpretation of k-means",
      "Common pitfall in k-means",
      "Correct principle of k-means",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 12,
    "section": "Unit6_Unsupervised_Learning",
    "text": "k-means: Which statement is correct?",
    "options": [
      "Incorrect interpretation of k-means",
      "Common pitfall in k-means",
      "Correct principle of k-means",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 13,
    "section": "Unit6_Unsupervised_Learning",
    "text": "k-means: Which statement is correct?",
    "options": [
      "Incorrect interpretation of k-means",
      "Common pitfall in k-means",
      "Correct principle of k-means",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 14,
    "section": "Unit6_Unsupervised_Learning",
    "text": "k-means: Which statement is correct?",
    "options": [
      "Incorrect interpretation of k-means",
      "Common pitfall in k-means",
      "Correct principle of k-means",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 15,
    "section": "Unit6_Unsupervised_Learning",
    "text": "k-means: Which statement is correct?",
    "options": [
      "Incorrect interpretation of k-means",
      "Common pitfall in k-means",
      "Correct principle of k-means",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 16,
    "section": "Unit6_Unsupervised_Learning",
    "text": "k-means: Which statement is correct?",
    "options": [
      "Incorrect interpretation of k-means",
      "Common pitfall in k-means",
      "Correct principle of k-means",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 17,
    "section": "Unit6_Unsupervised_Learning",
    "text": "k-means: Which statement is correct?",
    "options": [
      "Incorrect interpretation of k-means",
      "Common pitfall in k-means",
      "Correct principle of k-means",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 18,
    "section": "Unit6_Unsupervised_Learning",
    "text": "k-means: Which statement is correct?",
    "options": [
      "Incorrect interpretation of k-means",
      "Common pitfall in k-means",
      "Correct principle of k-means",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 19,
    "section": "Unit6_Unsupervised_Learning",
    "text": "k-means: Which statement is correct?",
    "options": [
      "Incorrect interpretation of k-means",
      "Common pitfall in k-means",
      "Correct principle of k-means",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 20,
    "section": "Unit6_Unsupervised_Learning",
    "text": "k-means: Which statement is correct?",
    "options": [
      "Incorrect interpretation of k-means",
      "Common pitfall in k-means",
      "Correct principle of k-means",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 21,
    "section": "Unit6_Unsupervised_Learning",
    "text": "Hierarchical clustering: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Hierarchical clustering",
      "Common pitfall in Hierarchical clustering",
      "Correct principle of Hierarchical clustering",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 22,
    "section": "Unit6_Unsupervised_Learning",
    "text": "Hierarchical clustering: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Hierarchical clustering",
      "Common pitfall in Hierarchical clustering",
      "Correct principle of Hierarchical clustering",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 23,
    "section": "Unit6_Unsupervised_Learning",
    "text": "Hierarchical clustering: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Hierarchical clustering",
      "Common pitfall in Hierarchical clustering",
      "Correct principle of Hierarchical clustering",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 24,
    "section": "Unit6_Unsupervised_Learning",
    "text": "Hierarchical clustering: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Hierarchical clustering",
      "Common pitfall in Hierarchical clustering",
      "Correct principle of Hierarchical clustering",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 25,
    "section": "Unit6_Unsupervised_Learning",
    "text": "Hierarchical clustering: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Hierarchical clustering",
      "Common pitfall in Hierarchical clustering",
      "Correct principle of Hierarchical clustering",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 26,
    "section": "Unit6_Unsupervised_Learning",
    "text": "Hierarchical clustering: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Hierarchical clustering",
      "Common pitfall in Hierarchical clustering",
      "Correct principle of Hierarchical clustering",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 27,
    "section": "Unit6_Unsupervised_Learning",
    "text": "Hierarchical clustering: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Hierarchical clustering",
      "Common pitfall in Hierarchical clustering",
      "Correct principle of Hierarchical clustering",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 28,
    "section": "Unit6_Unsupervised_Learning",
    "text": "Hierarchical clustering: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Hierarchical clustering",
      "Common pitfall in Hierarchical clustering",
      "Correct principle of Hierarchical clustering",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 29,
    "section": "Unit6_Unsupervised_Learning",
    "text": "Hierarchical clustering: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Hierarchical clustering",
      "Common pitfall in Hierarchical clustering",
      "Correct principle of Hierarchical clustering",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 30,
    "section": "Unit6_Unsupervised_Learning",
    "text": "Hierarchical clustering: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Hierarchical clustering",
      "Common pitfall in Hierarchical clustering",
      "Correct principle of Hierarchical clustering",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 31,
    "section": "Unit6_Unsupervised_Learning",
    "text": "DBSCAN: Which statement is correct?",
    "options": [
      "Incorrect interpretation of DBSCAN",
      "Common pitfall in DBSCAN",
      "Correct principle of DBSCAN",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 32,
    "section": "Unit6_Unsupervised_Learning",
    "text": "DBSCAN: Which statement is correct?",
    "options": [
      "Incorrect interpretation of DBSCAN",
      "Common pitfall in DBSCAN",
      "Correct principle of DBSCAN",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 33,
    "section": "Unit6_Unsupervised_Learning",
    "text": "DBSCAN: Which statement is correct?",
    "options": [
      "Incorrect interpretation of DBSCAN",
      "Common pitfall in DBSCAN",
      "Correct principle of DBSCAN",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 34,
    "section": "Unit6_Unsupervised_Learning",
    "text": "DBSCAN: Which statement is correct?",
    "options": [
      "Incorrect interpretation of DBSCAN",
      "Common pitfall in DBSCAN",
      "Correct principle of DBSCAN",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 35,
    "section": "Unit6_Unsupervised_Learning",
    "text": "DBSCAN: Which statement is correct?",
    "options": [
      "Incorrect interpretation of DBSCAN",
      "Common pitfall in DBSCAN",
      "Correct principle of DBSCAN",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 36,
    "section": "Unit6_Unsupervised_Learning",
    "text": "DBSCAN: Which statement is correct?",
    "options": [
      "Incorrect interpretation of DBSCAN",
      "Common pitfall in DBSCAN",
      "Correct principle of DBSCAN",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 37,
    "section": "Unit6_Unsupervised_Learning",
    "text": "DBSCAN: Which statement is correct?",
    "options": [
      "Incorrect interpretation of DBSCAN",
      "Common pitfall in DBSCAN",
      "Correct principle of DBSCAN",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 38,
    "section": "Unit6_Unsupervised_Learning",
    "text": "DBSCAN: Which statement is correct?",
    "options": [
      "Incorrect interpretation of DBSCAN",
      "Common pitfall in DBSCAN",
      "Correct principle of DBSCAN",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 39,
    "section": "Unit6_Unsupervised_Learning",
    "text": "DBSCAN: Which statement is correct?",
    "options": [
      "Incorrect interpretation of DBSCAN",
      "Common pitfall in DBSCAN",
      "Correct principle of DBSCAN",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 40,
    "section": "Unit6_Unsupervised_Learning",
    "text": "DBSCAN: Which statement is correct?",
    "options": [
      "Incorrect interpretation of DBSCAN",
      "Common pitfall in DBSCAN",
      "Correct principle of DBSCAN",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 41,
    "section": "Unit6_Unsupervised_Learning",
    "text": "Distance metrics: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Distance metrics",
      "Common pitfall in Distance metrics",
      "Correct principle of Distance metrics",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 42,
    "section": "Unit6_Unsupervised_Learning",
    "text": "Distance metrics: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Distance metrics",
      "Common pitfall in Distance metrics",
      "Correct principle of Distance metrics",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 43,
    "section": "Unit6_Unsupervised_Learning",
    "text": "Distance metrics: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Distance metrics",
      "Common pitfall in Distance metrics",
      "Correct principle of Distance metrics",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 44,
    "section": "Unit6_Unsupervised_Learning",
    "text": "Distance metrics: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Distance metrics",
      "Common pitfall in Distance metrics",
      "Correct principle of Distance metrics",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 45,
    "section": "Unit6_Unsupervised_Learning",
    "text": "Distance metrics: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Distance metrics",
      "Common pitfall in Distance metrics",
      "Correct principle of Distance metrics",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 46,
    "section": "Unit6_Unsupervised_Learning",
    "text": "Distance metrics: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Distance metrics",
      "Common pitfall in Distance metrics",
      "Correct principle of Distance metrics",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 47,
    "section": "Unit6_Unsupervised_Learning",
    "text": "Distance metrics: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Distance metrics",
      "Common pitfall in Distance metrics",
      "Correct principle of Distance metrics",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 48,
    "section": "Unit6_Unsupervised_Learning",
    "text": "Distance metrics: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Distance metrics",
      "Common pitfall in Distance metrics",
      "Correct principle of Distance metrics",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 49,
    "section": "Unit6_Unsupervised_Learning",
    "text": "Distance metrics: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Distance metrics",
      "Common pitfall in Distance metrics",
      "Correct principle of Distance metrics",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 50,
    "section": "Unit6_Unsupervised_Learning",
    "text": "Distance metrics: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Distance metrics",
      "Common pitfall in Distance metrics",
      "Correct principle of Distance metrics",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 51,
    "section": "Unit6_Unsupervised_Learning",
    "text": "Dimensionality reduction: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Dimensionality reduction",
      "Common pitfall in Dimensionality reduction",
      "Correct principle of Dimensionality reduction",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 52,
    "section": "Unit6_Unsupervised_Learning",
    "text": "Dimensionality reduction: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Dimensionality reduction",
      "Common pitfall in Dimensionality reduction",
      "Correct principle of Dimensionality reduction",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 53,
    "section": "Unit6_Unsupervised_Learning",
    "text": "Dimensionality reduction: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Dimensionality reduction",
      "Common pitfall in Dimensionality reduction",
      "Correct principle of Dimensionality reduction",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 54,
    "section": "Unit6_Unsupervised_Learning",
    "text": "Dimensionality reduction: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Dimensionality reduction",
      "Common pitfall in Dimensionality reduction",
      "Correct principle of Dimensionality reduction",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 55,
    "section": "Unit6_Unsupervised_Learning",
    "text": "Dimensionality reduction: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Dimensionality reduction",
      "Common pitfall in Dimensionality reduction",
      "Correct principle of Dimensionality reduction",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 56,
    "section": "Unit6_Unsupervised_Learning",
    "text": "Dimensionality reduction: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Dimensionality reduction",
      "Common pitfall in Dimensionality reduction",
      "Correct principle of Dimensionality reduction",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 57,
    "section": "Unit6_Unsupervised_Learning",
    "text": "Dimensionality reduction: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Dimensionality reduction",
      "Common pitfall in Dimensionality reduction",
      "Correct principle of Dimensionality reduction",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 58,
    "section": "Unit6_Unsupervised_Learning",
    "text": "Dimensionality reduction: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Dimensionality reduction",
      "Common pitfall in Dimensionality reduction",
      "Correct principle of Dimensionality reduction",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 59,
    "section": "Unit6_Unsupervised_Learning",
    "text": "Dimensionality reduction: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Dimensionality reduction",
      "Common pitfall in Dimensionality reduction",
      "Correct principle of Dimensionality reduction",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 60,
    "section": "Unit6_Unsupervised_Learning",
    "text": "Dimensionality reduction: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Dimensionality reduction",
      "Common pitfall in Dimensionality reduction",
      "Correct principle of Dimensionality reduction",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 61,
    "section": "Unit6_Unsupervised_Learning",
    "text": "PCA: Which statement is correct?",
    "options": [
      "Incorrect interpretation of PCA",
      "Common pitfall in PCA",
      "Correct principle of PCA",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 62,
    "section": "Unit6_Unsupervised_Learning",
    "text": "PCA: Which statement is correct?",
    "options": [
      "Incorrect interpretation of PCA",
      "Common pitfall in PCA",
      "Correct principle of PCA",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 63,
    "section": "Unit6_Unsupervised_Learning",
    "text": "PCA: Which statement is correct?",
    "options": [
      "Incorrect interpretation of PCA",
      "Common pitfall in PCA",
      "Correct principle of PCA",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 64,
    "section": "Unit6_Unsupervised_Learning",
    "text": "PCA: Which statement is correct?",
    "options": [
      "Incorrect interpretation of PCA",
      "Common pitfall in PCA",
      "Correct principle of PCA",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 65,
    "section": "Unit6_Unsupervised_Learning",
    "text": "PCA: Which statement is correct?",
    "options": [
      "Incorrect interpretation of PCA",
      "Common pitfall in PCA",
      "Correct principle of PCA",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 66,
    "section": "Unit6_Unsupervised_Learning",
    "text": "PCA: Which statement is correct?",
    "options": [
      "Incorrect interpretation of PCA",
      "Common pitfall in PCA",
      "Correct principle of PCA",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 67,
    "section": "Unit6_Unsupervised_Learning",
    "text": "PCA: Which statement is correct?",
    "options": [
      "Incorrect interpretation of PCA",
      "Common pitfall in PCA",
      "Correct principle of PCA",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 68,
    "section": "Unit6_Unsupervised_Learning",
    "text": "PCA: Which statement is correct?",
    "options": [
      "Incorrect interpretation of PCA",
      "Common pitfall in PCA",
      "Correct principle of PCA",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 69,
    "section": "Unit6_Unsupervised_Learning",
    "text": "PCA: Which statement is correct?",
    "options": [
      "Incorrect interpretation of PCA",
      "Common pitfall in PCA",
      "Correct principle of PCA",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 70,
    "section": "Unit6_Unsupervised_Learning",
    "text": "PCA: Which statement is correct?",
    "options": [
      "Incorrect interpretation of PCA",
      "Common pitfall in PCA",
      "Correct principle of PCA",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 71,
    "section": "Unit6_Unsupervised_Learning",
    "text": "Spectral clustering: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Spectral clustering",
      "Common pitfall in Spectral clustering",
      "Correct principle of Spectral clustering",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 72,
    "section": "Unit6_Unsupervised_Learning",
    "text": "Spectral clustering: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Spectral clustering",
      "Common pitfall in Spectral clustering",
      "Correct principle of Spectral clustering",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 73,
    "section": "Unit6_Unsupervised_Learning",
    "text": "Spectral clustering: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Spectral clustering",
      "Common pitfall in Spectral clustering",
      "Correct principle of Spectral clustering",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 74,
    "section": "Unit6_Unsupervised_Learning",
    "text": "Spectral clustering: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Spectral clustering",
      "Common pitfall in Spectral clustering",
      "Correct principle of Spectral clustering",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 75,
    "section": "Unit6_Unsupervised_Learning",
    "text": "Spectral clustering: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Spectral clustering",
      "Common pitfall in Spectral clustering",
      "Correct principle of Spectral clustering",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 76,
    "section": "Unit6_Unsupervised_Learning",
    "text": "Spectral clustering: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Spectral clustering",
      "Common pitfall in Spectral clustering",
      "Correct principle of Spectral clustering",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 77,
    "section": "Unit6_Unsupervised_Learning",
    "text": "Spectral clustering: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Spectral clustering",
      "Common pitfall in Spectral clustering",
      "Correct principle of Spectral clustering",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 78,
    "section": "Unit6_Unsupervised_Learning",
    "text": "Spectral clustering: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Spectral clustering",
      "Common pitfall in Spectral clustering",
      "Correct principle of Spectral clustering",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 79,
    "section": "Unit6_Unsupervised_Learning",
    "text": "Spectral clustering: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Spectral clustering",
      "Common pitfall in Spectral clustering",
      "Correct principle of Spectral clustering",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 80,
    "section": "Unit6_Unsupervised_Learning",
    "text": "Spectral clustering: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Spectral clustering",
      "Common pitfall in Spectral clustering",
      "Correct principle of Spectral clustering",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 81,
    "section": "Unit6_Unsupervised_Learning",
    "text": "Anomaly detection: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Anomaly detection",
      "Common pitfall in Anomaly detection",
      "Correct principle of Anomaly detection",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 82,
    "section": "Unit6_Unsupervised_Learning",
    "text": "Anomaly detection: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Anomaly detection",
      "Common pitfall in Anomaly detection",
      "Correct principle of Anomaly detection",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 83,
    "section": "Unit6_Unsupervised_Learning",
    "text": "Anomaly detection: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Anomaly detection",
      "Common pitfall in Anomaly detection",
      "Correct principle of Anomaly detection",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 84,
    "section": "Unit6_Unsupervised_Learning",
    "text": "Anomaly detection: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Anomaly detection",
      "Common pitfall in Anomaly detection",
      "Correct principle of Anomaly detection",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 85,
    "section": "Unit6_Unsupervised_Learning",
    "text": "Anomaly detection: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Anomaly detection",
      "Common pitfall in Anomaly detection",
      "Correct principle of Anomaly detection",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 86,
    "section": "Unit6_Unsupervised_Learning",
    "text": "Anomaly detection: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Anomaly detection",
      "Common pitfall in Anomaly detection",
      "Correct principle of Anomaly detection",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 87,
    "section": "Unit6_Unsupervised_Learning",
    "text": "Anomaly detection: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Anomaly detection",
      "Common pitfall in Anomaly detection",
      "Correct principle of Anomaly detection",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 88,
    "section": "Unit6_Unsupervised_Learning",
    "text": "Anomaly detection: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Anomaly detection",
      "Common pitfall in Anomaly detection",
      "Correct principle of Anomaly detection",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 89,
    "section": "Unit6_Unsupervised_Learning",
    "text": "Anomaly detection: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Anomaly detection",
      "Common pitfall in Anomaly detection",
      "Correct principle of Anomaly detection",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 90,
    "section": "Unit6_Unsupervised_Learning",
    "text": "Anomaly detection: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Anomaly detection",
      "Common pitfall in Anomaly detection",
      "Correct principle of Anomaly detection",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 91,
    "section": "Unit6_Unsupervised_Learning",
    "text": "Evaluation: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Evaluation",
      "Common pitfall in Evaluation",
      "Correct principle of Evaluation",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 92,
    "section": "Unit6_Unsupervised_Learning",
    "text": "Evaluation: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Evaluation",
      "Common pitfall in Evaluation",
      "Correct principle of Evaluation",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 93,
    "section": "Unit6_Unsupervised_Learning",
    "text": "Evaluation: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Evaluation",
      "Common pitfall in Evaluation",
      "Correct principle of Evaluation",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 94,
    "section": "Unit6_Unsupervised_Learning",
    "text": "Evaluation: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Evaluation",
      "Common pitfall in Evaluation",
      "Correct principle of Evaluation",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 95,
    "section": "Unit6_Unsupervised_Learning",
    "text": "Evaluation: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Evaluation",
      "Common pitfall in Evaluation",
      "Correct principle of Evaluation",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 96,
    "section": "Unit6_Unsupervised_Learning",
    "text": "Evaluation: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Evaluation",
      "Common pitfall in Evaluation",
      "Correct principle of Evaluation",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 97,
    "section": "Unit6_Unsupervised_Learning",
    "text": "Evaluation: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Evaluation",
      "Common pitfall in Evaluation",
      "Correct principle of Evaluation",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 98,
    "section": "Unit6_Unsupervised_Learning",
    "text": "Evaluation: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Evaluation",
      "Common pitfall in Evaluation",
      "Correct principle of Evaluation",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 99,
    "section": "Unit6_Unsupervised_Learning",
    "text": "Evaluation: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Evaluation",
      "Common pitfall in Evaluation",
      "Correct principle of Evaluation",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 100,
    "section": "Unit6_Unsupervised_Learning",
    "text": "Evaluation: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Evaluation",
      "Common pitfall in Evaluation",
      "Correct principle of Evaluation",
      "Unrelated concept"
    ],
    "answer": 2
  }
];