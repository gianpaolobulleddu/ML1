const QUESTIONS = [
  {
    "id": 1,
    "section": "Unit3_Data_Preprocessing",
    "text": "Missing values: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Missing values",
      "Common pitfall in Missing values",
      "Correct principle of Missing values",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 2,
    "section": "Unit3_Data_Preprocessing",
    "text": "Missing values: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Missing values",
      "Common pitfall in Missing values",
      "Correct principle of Missing values",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 3,
    "section": "Unit3_Data_Preprocessing",
    "text": "Missing values: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Missing values",
      "Common pitfall in Missing values",
      "Correct principle of Missing values",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 4,
    "section": "Unit3_Data_Preprocessing",
    "text": "Missing values: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Missing values",
      "Common pitfall in Missing values",
      "Correct principle of Missing values",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 5,
    "section": "Unit3_Data_Preprocessing",
    "text": "Missing values: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Missing values",
      "Common pitfall in Missing values",
      "Correct principle of Missing values",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 6,
    "section": "Unit3_Data_Preprocessing",
    "text": "Missing values: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Missing values",
      "Common pitfall in Missing values",
      "Correct principle of Missing values",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 7,
    "section": "Unit3_Data_Preprocessing",
    "text": "Missing values: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Missing values",
      "Common pitfall in Missing values",
      "Correct principle of Missing values",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 8,
    "section": "Unit3_Data_Preprocessing",
    "text": "Missing values: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Missing values",
      "Common pitfall in Missing values",
      "Correct principle of Missing values",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 9,
    "section": "Unit3_Data_Preprocessing",
    "text": "Missing values: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Missing values",
      "Common pitfall in Missing values",
      "Correct principle of Missing values",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 10,
    "section": "Unit3_Data_Preprocessing",
    "text": "Missing values: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Missing values",
      "Common pitfall in Missing values",
      "Correct principle of Missing values",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 11,
    "section": "Unit3_Data_Preprocessing",
    "text": "Normalization: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Normalization",
      "Common pitfall in Normalization",
      "Correct principle of Normalization",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 12,
    "section": "Unit3_Data_Preprocessing",
    "text": "Normalization: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Normalization",
      "Common pitfall in Normalization",
      "Correct principle of Normalization",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 13,
    "section": "Unit3_Data_Preprocessing",
    "text": "Normalization: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Normalization",
      "Common pitfall in Normalization",
      "Correct principle of Normalization",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 14,
    "section": "Unit3_Data_Preprocessing",
    "text": "Normalization: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Normalization",
      "Common pitfall in Normalization",
      "Correct principle of Normalization",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 15,
    "section": "Unit3_Data_Preprocessing",
    "text": "Normalization: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Normalization",
      "Common pitfall in Normalization",
      "Correct principle of Normalization",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 16,
    "section": "Unit3_Data_Preprocessing",
    "text": "Normalization: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Normalization",
      "Common pitfall in Normalization",
      "Correct principle of Normalization",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 17,
    "section": "Unit3_Data_Preprocessing",
    "text": "Normalization: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Normalization",
      "Common pitfall in Normalization",
      "Correct principle of Normalization",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 18,
    "section": "Unit3_Data_Preprocessing",
    "text": "Normalization: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Normalization",
      "Common pitfall in Normalization",
      "Correct principle of Normalization",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 19,
    "section": "Unit3_Data_Preprocessing",
    "text": "Normalization: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Normalization",
      "Common pitfall in Normalization",
      "Correct principle of Normalization",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 20,
    "section": "Unit3_Data_Preprocessing",
    "text": "Normalization: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Normalization",
      "Common pitfall in Normalization",
      "Correct principle of Normalization",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 21,
    "section": "Unit3_Data_Preprocessing",
    "text": "Standardization: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Standardization",
      "Common pitfall in Standardization",
      "Correct principle of Standardization",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 22,
    "section": "Unit3_Data_Preprocessing",
    "text": "Standardization: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Standardization",
      "Common pitfall in Standardization",
      "Correct principle of Standardization",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 23,
    "section": "Unit3_Data_Preprocessing",
    "text": "Standardization: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Standardization",
      "Common pitfall in Standardization",
      "Correct principle of Standardization",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 24,
    "section": "Unit3_Data_Preprocessing",
    "text": "Standardization: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Standardization",
      "Common pitfall in Standardization",
      "Correct principle of Standardization",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 25,
    "section": "Unit3_Data_Preprocessing",
    "text": "Standardization: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Standardization",
      "Common pitfall in Standardization",
      "Correct principle of Standardization",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 26,
    "section": "Unit3_Data_Preprocessing",
    "text": "Standardization: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Standardization",
      "Common pitfall in Standardization",
      "Correct principle of Standardization",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 27,
    "section": "Unit3_Data_Preprocessing",
    "text": "Standardization: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Standardization",
      "Common pitfall in Standardization",
      "Correct principle of Standardization",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 28,
    "section": "Unit3_Data_Preprocessing",
    "text": "Standardization: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Standardization",
      "Common pitfall in Standardization",
      "Correct principle of Standardization",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 29,
    "section": "Unit3_Data_Preprocessing",
    "text": "Standardization: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Standardization",
      "Common pitfall in Standardization",
      "Correct principle of Standardization",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 30,
    "section": "Unit3_Data_Preprocessing",
    "text": "Standardization: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Standardization",
      "Common pitfall in Standardization",
      "Correct principle of Standardization",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 31,
    "section": "Unit3_Data_Preprocessing",
    "text": "Encoding: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Encoding",
      "Common pitfall in Encoding",
      "Correct principle of Encoding",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 32,
    "section": "Unit3_Data_Preprocessing",
    "text": "Encoding: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Encoding",
      "Common pitfall in Encoding",
      "Correct principle of Encoding",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 33,
    "section": "Unit3_Data_Preprocessing",
    "text": "Encoding: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Encoding",
      "Common pitfall in Encoding",
      "Correct principle of Encoding",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 34,
    "section": "Unit3_Data_Preprocessing",
    "text": "Encoding: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Encoding",
      "Common pitfall in Encoding",
      "Correct principle of Encoding",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 35,
    "section": "Unit3_Data_Preprocessing",
    "text": "Encoding: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Encoding",
      "Common pitfall in Encoding",
      "Correct principle of Encoding",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 36,
    "section": "Unit3_Data_Preprocessing",
    "text": "Encoding: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Encoding",
      "Common pitfall in Encoding",
      "Correct principle of Encoding",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 37,
    "section": "Unit3_Data_Preprocessing",
    "text": "Encoding: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Encoding",
      "Common pitfall in Encoding",
      "Correct principle of Encoding",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 38,
    "section": "Unit3_Data_Preprocessing",
    "text": "Encoding: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Encoding",
      "Common pitfall in Encoding",
      "Correct principle of Encoding",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 39,
    "section": "Unit3_Data_Preprocessing",
    "text": "Encoding: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Encoding",
      "Common pitfall in Encoding",
      "Correct principle of Encoding",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 40,
    "section": "Unit3_Data_Preprocessing",
    "text": "Encoding: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Encoding",
      "Common pitfall in Encoding",
      "Correct principle of Encoding",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 41,
    "section": "Unit3_Data_Preprocessing",
    "text": "Outliers: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Outliers",
      "Common pitfall in Outliers",
      "Correct principle of Outliers",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 42,
    "section": "Unit3_Data_Preprocessing",
    "text": "Outliers: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Outliers",
      "Common pitfall in Outliers",
      "Correct principle of Outliers",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 43,
    "section": "Unit3_Data_Preprocessing",
    "text": "Outliers: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Outliers",
      "Common pitfall in Outliers",
      "Correct principle of Outliers",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 44,
    "section": "Unit3_Data_Preprocessing",
    "text": "Outliers: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Outliers",
      "Common pitfall in Outliers",
      "Correct principle of Outliers",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 45,
    "section": "Unit3_Data_Preprocessing",
    "text": "Outliers: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Outliers",
      "Common pitfall in Outliers",
      "Correct principle of Outliers",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 46,
    "section": "Unit3_Data_Preprocessing",
    "text": "Outliers: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Outliers",
      "Common pitfall in Outliers",
      "Correct principle of Outliers",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 47,
    "section": "Unit3_Data_Preprocessing",
    "text": "Outliers: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Outliers",
      "Common pitfall in Outliers",
      "Correct principle of Outliers",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 48,
    "section": "Unit3_Data_Preprocessing",
    "text": "Outliers: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Outliers",
      "Common pitfall in Outliers",
      "Correct principle of Outliers",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 49,
    "section": "Unit3_Data_Preprocessing",
    "text": "Outliers: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Outliers",
      "Common pitfall in Outliers",
      "Correct principle of Outliers",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 50,
    "section": "Unit3_Data_Preprocessing",
    "text": "Outliers: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Outliers",
      "Common pitfall in Outliers",
      "Correct principle of Outliers",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 51,
    "section": "Unit3_Data_Preprocessing",
    "text": "Scaling: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Scaling",
      "Common pitfall in Scaling",
      "Correct principle of Scaling",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 52,
    "section": "Unit3_Data_Preprocessing",
    "text": "Scaling: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Scaling",
      "Common pitfall in Scaling",
      "Correct principle of Scaling",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 53,
    "section": "Unit3_Data_Preprocessing",
    "text": "Scaling: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Scaling",
      "Common pitfall in Scaling",
      "Correct principle of Scaling",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 54,
    "section": "Unit3_Data_Preprocessing",
    "text": "Scaling: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Scaling",
      "Common pitfall in Scaling",
      "Correct principle of Scaling",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 55,
    "section": "Unit3_Data_Preprocessing",
    "text": "Scaling: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Scaling",
      "Common pitfall in Scaling",
      "Correct principle of Scaling",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 56,
    "section": "Unit3_Data_Preprocessing",
    "text": "Scaling: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Scaling",
      "Common pitfall in Scaling",
      "Correct principle of Scaling",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 57,
    "section": "Unit3_Data_Preprocessing",
    "text": "Scaling: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Scaling",
      "Common pitfall in Scaling",
      "Correct principle of Scaling",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 58,
    "section": "Unit3_Data_Preprocessing",
    "text": "Scaling: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Scaling",
      "Common pitfall in Scaling",
      "Correct principle of Scaling",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 59,
    "section": "Unit3_Data_Preprocessing",
    "text": "Scaling: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Scaling",
      "Common pitfall in Scaling",
      "Correct principle of Scaling",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 60,
    "section": "Unit3_Data_Preprocessing",
    "text": "Scaling: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Scaling",
      "Common pitfall in Scaling",
      "Correct principle of Scaling",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 61,
    "section": "Unit3_Data_Preprocessing",
    "text": "Discretization: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Discretization",
      "Common pitfall in Discretization",
      "Correct principle of Discretization",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 62,
    "section": "Unit3_Data_Preprocessing",
    "text": "Discretization: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Discretization",
      "Common pitfall in Discretization",
      "Correct principle of Discretization",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 63,
    "section": "Unit3_Data_Preprocessing",
    "text": "Discretization: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Discretization",
      "Common pitfall in Discretization",
      "Correct principle of Discretization",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 64,
    "section": "Unit3_Data_Preprocessing",
    "text": "Discretization: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Discretization",
      "Common pitfall in Discretization",
      "Correct principle of Discretization",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 65,
    "section": "Unit3_Data_Preprocessing",
    "text": "Discretization: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Discretization",
      "Common pitfall in Discretization",
      "Correct principle of Discretization",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 66,
    "section": "Unit3_Data_Preprocessing",
    "text": "Discretization: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Discretization",
      "Common pitfall in Discretization",
      "Correct principle of Discretization",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 67,
    "section": "Unit3_Data_Preprocessing",
    "text": "Discretization: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Discretization",
      "Common pitfall in Discretization",
      "Correct principle of Discretization",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 68,
    "section": "Unit3_Data_Preprocessing",
    "text": "Discretization: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Discretization",
      "Common pitfall in Discretization",
      "Correct principle of Discretization",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 69,
    "section": "Unit3_Data_Preprocessing",
    "text": "Discretization: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Discretization",
      "Common pitfall in Discretization",
      "Correct principle of Discretization",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 70,
    "section": "Unit3_Data_Preprocessing",
    "text": "Discretization: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Discretization",
      "Common pitfall in Discretization",
      "Correct principle of Discretization",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 71,
    "section": "Unit3_Data_Preprocessing",
    "text": "Feature selection: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Feature selection",
      "Common pitfall in Feature selection",
      "Correct principle of Feature selection",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 72,
    "section": "Unit3_Data_Preprocessing",
    "text": "Feature selection: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Feature selection",
      "Common pitfall in Feature selection",
      "Correct principle of Feature selection",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 73,
    "section": "Unit3_Data_Preprocessing",
    "text": "Feature selection: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Feature selection",
      "Common pitfall in Feature selection",
      "Correct principle of Feature selection",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 74,
    "section": "Unit3_Data_Preprocessing",
    "text": "Feature selection: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Feature selection",
      "Common pitfall in Feature selection",
      "Correct principle of Feature selection",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 75,
    "section": "Unit3_Data_Preprocessing",
    "text": "Feature selection: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Feature selection",
      "Common pitfall in Feature selection",
      "Correct principle of Feature selection",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 76,
    "section": "Unit3_Data_Preprocessing",
    "text": "Feature selection: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Feature selection",
      "Common pitfall in Feature selection",
      "Correct principle of Feature selection",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 77,
    "section": "Unit3_Data_Preprocessing",
    "text": "Feature selection: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Feature selection",
      "Common pitfall in Feature selection",
      "Correct principle of Feature selection",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 78,
    "section": "Unit3_Data_Preprocessing",
    "text": "Feature selection: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Feature selection",
      "Common pitfall in Feature selection",
      "Correct principle of Feature selection",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 79,
    "section": "Unit3_Data_Preprocessing",
    "text": "Feature selection: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Feature selection",
      "Common pitfall in Feature selection",
      "Correct principle of Feature selection",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 80,
    "section": "Unit3_Data_Preprocessing",
    "text": "Feature selection: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Feature selection",
      "Common pitfall in Feature selection",
      "Correct principle of Feature selection",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 81,
    "section": "Unit3_Data_Preprocessing",
    "text": "Data leakage: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Data leakage",
      "Common pitfall in Data leakage",
      "Correct principle of Data leakage",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 82,
    "section": "Unit3_Data_Preprocessing",
    "text": "Data leakage: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Data leakage",
      "Common pitfall in Data leakage",
      "Correct principle of Data leakage",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 83,
    "section": "Unit3_Data_Preprocessing",
    "text": "Data leakage: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Data leakage",
      "Common pitfall in Data leakage",
      "Correct principle of Data leakage",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 84,
    "section": "Unit3_Data_Preprocessing",
    "text": "Data leakage: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Data leakage",
      "Common pitfall in Data leakage",
      "Correct principle of Data leakage",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 85,
    "section": "Unit3_Data_Preprocessing",
    "text": "Data leakage: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Data leakage",
      "Common pitfall in Data leakage",
      "Correct principle of Data leakage",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 86,
    "section": "Unit3_Data_Preprocessing",
    "text": "Data leakage: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Data leakage",
      "Common pitfall in Data leakage",
      "Correct principle of Data leakage",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 87,
    "section": "Unit3_Data_Preprocessing",
    "text": "Data leakage: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Data leakage",
      "Common pitfall in Data leakage",
      "Correct principle of Data leakage",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 88,
    "section": "Unit3_Data_Preprocessing",
    "text": "Data leakage: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Data leakage",
      "Common pitfall in Data leakage",
      "Correct principle of Data leakage",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 89,
    "section": "Unit3_Data_Preprocessing",
    "text": "Data leakage: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Data leakage",
      "Common pitfall in Data leakage",
      "Correct principle of Data leakage",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 90,
    "section": "Unit3_Data_Preprocessing",
    "text": "Data leakage: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Data leakage",
      "Common pitfall in Data leakage",
      "Correct principle of Data leakage",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 91,
    "section": "Unit3_Data_Preprocessing",
    "text": "Imputation: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Imputation",
      "Common pitfall in Imputation",
      "Correct principle of Imputation",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 92,
    "section": "Unit3_Data_Preprocessing",
    "text": "Imputation: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Imputation",
      "Common pitfall in Imputation",
      "Correct principle of Imputation",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 93,
    "section": "Unit3_Data_Preprocessing",
    "text": "Imputation: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Imputation",
      "Common pitfall in Imputation",
      "Correct principle of Imputation",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 94,
    "section": "Unit3_Data_Preprocessing",
    "text": "Imputation: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Imputation",
      "Common pitfall in Imputation",
      "Correct principle of Imputation",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 95,
    "section": "Unit3_Data_Preprocessing",
    "text": "Imputation: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Imputation",
      "Common pitfall in Imputation",
      "Correct principle of Imputation",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 96,
    "section": "Unit3_Data_Preprocessing",
    "text": "Imputation: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Imputation",
      "Common pitfall in Imputation",
      "Correct principle of Imputation",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 97,
    "section": "Unit3_Data_Preprocessing",
    "text": "Imputation: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Imputation",
      "Common pitfall in Imputation",
      "Correct principle of Imputation",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 98,
    "section": "Unit3_Data_Preprocessing",
    "text": "Imputation: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Imputation",
      "Common pitfall in Imputation",
      "Correct principle of Imputation",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 99,
    "section": "Unit3_Data_Preprocessing",
    "text": "Imputation: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Imputation",
      "Common pitfall in Imputation",
      "Correct principle of Imputation",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 100,
    "section": "Unit3_Data_Preprocessing",
    "text": "Imputation: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Imputation",
      "Common pitfall in Imputation",
      "Correct principle of Imputation",
      "Unrelated concept"
    ],
    "answer": 2
  }
];