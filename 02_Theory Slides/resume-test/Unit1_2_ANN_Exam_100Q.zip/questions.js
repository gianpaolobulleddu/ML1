const QUESTIONS = [
  {
    "id": 1,
    "section": "Unit1_2_ANN",
    "text": "Artificial neuron model: which statement is correct?",
    "options": [
      "Incorrect interpretation of Artificial neuron model",
      "Common misconception about Artificial neuron model",
      "Correct principle related to Artificial neuron model",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 2,
    "section": "Unit1_2_ANN",
    "text": "Artificial neuron model: which statement is correct?",
    "options": [
      "Incorrect interpretation of Artificial neuron model",
      "Common misconception about Artificial neuron model",
      "Correct principle related to Artificial neuron model",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 3,
    "section": "Unit1_2_ANN",
    "text": "Artificial neuron model: which statement is correct?",
    "options": [
      "Incorrect interpretation of Artificial neuron model",
      "Common misconception about Artificial neuron model",
      "Correct principle related to Artificial neuron model",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 4,
    "section": "Unit1_2_ANN",
    "text": "Artificial neuron model: which statement is correct?",
    "options": [
      "Incorrect interpretation of Artificial neuron model",
      "Common misconception about Artificial neuron model",
      "Correct principle related to Artificial neuron model",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 5,
    "section": "Unit1_2_ANN",
    "text": "Artificial neuron model: which statement is correct?",
    "options": [
      "Incorrect interpretation of Artificial neuron model",
      "Common misconception about Artificial neuron model",
      "Correct principle related to Artificial neuron model",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 6,
    "section": "Unit1_2_ANN",
    "text": "Artificial neuron model: which statement is correct?",
    "options": [
      "Incorrect interpretation of Artificial neuron model",
      "Common misconception about Artificial neuron model",
      "Correct principle related to Artificial neuron model",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 7,
    "section": "Unit1_2_ANN",
    "text": "Artificial neuron model: which statement is correct?",
    "options": [
      "Incorrect interpretation of Artificial neuron model",
      "Common misconception about Artificial neuron model",
      "Correct principle related to Artificial neuron model",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 8,
    "section": "Unit1_2_ANN",
    "text": "Artificial neuron model: which statement is correct?",
    "options": [
      "Incorrect interpretation of Artificial neuron model",
      "Common misconception about Artificial neuron model",
      "Correct principle related to Artificial neuron model",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 9,
    "section": "Unit1_2_ANN",
    "text": "Artificial neuron model: which statement is correct?",
    "options": [
      "Incorrect interpretation of Artificial neuron model",
      "Common misconception about Artificial neuron model",
      "Correct principle related to Artificial neuron model",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 10,
    "section": "Unit1_2_ANN",
    "text": "Artificial neuron model: which statement is correct?",
    "options": [
      "Incorrect interpretation of Artificial neuron model",
      "Common misconception about Artificial neuron model",
      "Correct principle related to Artificial neuron model",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 11,
    "section": "Unit1_2_ANN",
    "text": "Weights and bias: which statement is correct?",
    "options": [
      "Incorrect interpretation of Weights and bias",
      "Common misconception about Weights and bias",
      "Correct principle related to Weights and bias",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 12,
    "section": "Unit1_2_ANN",
    "text": "Weights and bias: which statement is correct?",
    "options": [
      "Incorrect interpretation of Weights and bias",
      "Common misconception about Weights and bias",
      "Correct principle related to Weights and bias",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 13,
    "section": "Unit1_2_ANN",
    "text": "Weights and bias: which statement is correct?",
    "options": [
      "Incorrect interpretation of Weights and bias",
      "Common misconception about Weights and bias",
      "Correct principle related to Weights and bias",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 14,
    "section": "Unit1_2_ANN",
    "text": "Weights and bias: which statement is correct?",
    "options": [
      "Incorrect interpretation of Weights and bias",
      "Common misconception about Weights and bias",
      "Correct principle related to Weights and bias",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 15,
    "section": "Unit1_2_ANN",
    "text": "Weights and bias: which statement is correct?",
    "options": [
      "Incorrect interpretation of Weights and bias",
      "Common misconception about Weights and bias",
      "Correct principle related to Weights and bias",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 16,
    "section": "Unit1_2_ANN",
    "text": "Weights and bias: which statement is correct?",
    "options": [
      "Incorrect interpretation of Weights and bias",
      "Common misconception about Weights and bias",
      "Correct principle related to Weights and bias",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 17,
    "section": "Unit1_2_ANN",
    "text": "Weights and bias: which statement is correct?",
    "options": [
      "Incorrect interpretation of Weights and bias",
      "Common misconception about Weights and bias",
      "Correct principle related to Weights and bias",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 18,
    "section": "Unit1_2_ANN",
    "text": "Weights and bias: which statement is correct?",
    "options": [
      "Incorrect interpretation of Weights and bias",
      "Common misconception about Weights and bias",
      "Correct principle related to Weights and bias",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 19,
    "section": "Unit1_2_ANN",
    "text": "Weights and bias: which statement is correct?",
    "options": [
      "Incorrect interpretation of Weights and bias",
      "Common misconception about Weights and bias",
      "Correct principle related to Weights and bias",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 20,
    "section": "Unit1_2_ANN",
    "text": "Weights and bias: which statement is correct?",
    "options": [
      "Incorrect interpretation of Weights and bias",
      "Common misconception about Weights and bias",
      "Correct principle related to Weights and bias",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 21,
    "section": "Unit1_2_ANN",
    "text": "Activation functions: which statement is correct?",
    "options": [
      "Incorrect interpretation of Activation functions",
      "Common misconception about Activation functions",
      "Correct principle related to Activation functions",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 22,
    "section": "Unit1_2_ANN",
    "text": "Activation functions: which statement is correct?",
    "options": [
      "Incorrect interpretation of Activation functions",
      "Common misconception about Activation functions",
      "Correct principle related to Activation functions",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 23,
    "section": "Unit1_2_ANN",
    "text": "Activation functions: which statement is correct?",
    "options": [
      "Incorrect interpretation of Activation functions",
      "Common misconception about Activation functions",
      "Correct principle related to Activation functions",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 24,
    "section": "Unit1_2_ANN",
    "text": "Activation functions: which statement is correct?",
    "options": [
      "Incorrect interpretation of Activation functions",
      "Common misconception about Activation functions",
      "Correct principle related to Activation functions",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 25,
    "section": "Unit1_2_ANN",
    "text": "Activation functions: which statement is correct?",
    "options": [
      "Incorrect interpretation of Activation functions",
      "Common misconception about Activation functions",
      "Correct principle related to Activation functions",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 26,
    "section": "Unit1_2_ANN",
    "text": "Activation functions: which statement is correct?",
    "options": [
      "Incorrect interpretation of Activation functions",
      "Common misconception about Activation functions",
      "Correct principle related to Activation functions",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 27,
    "section": "Unit1_2_ANN",
    "text": "Activation functions: which statement is correct?",
    "options": [
      "Incorrect interpretation of Activation functions",
      "Common misconception about Activation functions",
      "Correct principle related to Activation functions",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 28,
    "section": "Unit1_2_ANN",
    "text": "Activation functions: which statement is correct?",
    "options": [
      "Incorrect interpretation of Activation functions",
      "Common misconception about Activation functions",
      "Correct principle related to Activation functions",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 29,
    "section": "Unit1_2_ANN",
    "text": "Activation functions: which statement is correct?",
    "options": [
      "Incorrect interpretation of Activation functions",
      "Common misconception about Activation functions",
      "Correct principle related to Activation functions",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 30,
    "section": "Unit1_2_ANN",
    "text": "Activation functions: which statement is correct?",
    "options": [
      "Incorrect interpretation of Activation functions",
      "Common misconception about Activation functions",
      "Correct principle related to Activation functions",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 31,
    "section": "Unit1_2_ANN",
    "text": "Perceptron learning rule: which statement is correct?",
    "options": [
      "Incorrect interpretation of Perceptron learning rule",
      "Common misconception about Perceptron learning rule",
      "Correct principle related to Perceptron learning rule",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 32,
    "section": "Unit1_2_ANN",
    "text": "Perceptron learning rule: which statement is correct?",
    "options": [
      "Incorrect interpretation of Perceptron learning rule",
      "Common misconception about Perceptron learning rule",
      "Correct principle related to Perceptron learning rule",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 33,
    "section": "Unit1_2_ANN",
    "text": "Perceptron learning rule: which statement is correct?",
    "options": [
      "Incorrect interpretation of Perceptron learning rule",
      "Common misconception about Perceptron learning rule",
      "Correct principle related to Perceptron learning rule",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 34,
    "section": "Unit1_2_ANN",
    "text": "Perceptron learning rule: which statement is correct?",
    "options": [
      "Incorrect interpretation of Perceptron learning rule",
      "Common misconception about Perceptron learning rule",
      "Correct principle related to Perceptron learning rule",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 35,
    "section": "Unit1_2_ANN",
    "text": "Perceptron learning rule: which statement is correct?",
    "options": [
      "Incorrect interpretation of Perceptron learning rule",
      "Common misconception about Perceptron learning rule",
      "Correct principle related to Perceptron learning rule",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 36,
    "section": "Unit1_2_ANN",
    "text": "Perceptron learning rule: which statement is correct?",
    "options": [
      "Incorrect interpretation of Perceptron learning rule",
      "Common misconception about Perceptron learning rule",
      "Correct principle related to Perceptron learning rule",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 37,
    "section": "Unit1_2_ANN",
    "text": "Perceptron learning rule: which statement is correct?",
    "options": [
      "Incorrect interpretation of Perceptron learning rule",
      "Common misconception about Perceptron learning rule",
      "Correct principle related to Perceptron learning rule",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 38,
    "section": "Unit1_2_ANN",
    "text": "Perceptron learning rule: which statement is correct?",
    "options": [
      "Incorrect interpretation of Perceptron learning rule",
      "Common misconception about Perceptron learning rule",
      "Correct principle related to Perceptron learning rule",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 39,
    "section": "Unit1_2_ANN",
    "text": "Perceptron learning rule: which statement is correct?",
    "options": [
      "Incorrect interpretation of Perceptron learning rule",
      "Common misconception about Perceptron learning rule",
      "Correct principle related to Perceptron learning rule",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 40,
    "section": "Unit1_2_ANN",
    "text": "Perceptron learning rule: which statement is correct?",
    "options": [
      "Incorrect interpretation of Perceptron learning rule",
      "Common misconception about Perceptron learning rule",
      "Correct principle related to Perceptron learning rule",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 41,
    "section": "Unit1_2_ANN",
    "text": "Delta rule: which statement is correct?",
    "options": [
      "Incorrect interpretation of Delta rule",
      "Common misconception about Delta rule",
      "Correct principle related to Delta rule",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 42,
    "section": "Unit1_2_ANN",
    "text": "Delta rule: which statement is correct?",
    "options": [
      "Incorrect interpretation of Delta rule",
      "Common misconception about Delta rule",
      "Correct principle related to Delta rule",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 43,
    "section": "Unit1_2_ANN",
    "text": "Delta rule: which statement is correct?",
    "options": [
      "Incorrect interpretation of Delta rule",
      "Common misconception about Delta rule",
      "Correct principle related to Delta rule",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 44,
    "section": "Unit1_2_ANN",
    "text": "Delta rule: which statement is correct?",
    "options": [
      "Incorrect interpretation of Delta rule",
      "Common misconception about Delta rule",
      "Correct principle related to Delta rule",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 45,
    "section": "Unit1_2_ANN",
    "text": "Delta rule: which statement is correct?",
    "options": [
      "Incorrect interpretation of Delta rule",
      "Common misconception about Delta rule",
      "Correct principle related to Delta rule",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 46,
    "section": "Unit1_2_ANN",
    "text": "Delta rule: which statement is correct?",
    "options": [
      "Incorrect interpretation of Delta rule",
      "Common misconception about Delta rule",
      "Correct principle related to Delta rule",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 47,
    "section": "Unit1_2_ANN",
    "text": "Delta rule: which statement is correct?",
    "options": [
      "Incorrect interpretation of Delta rule",
      "Common misconception about Delta rule",
      "Correct principle related to Delta rule",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 48,
    "section": "Unit1_2_ANN",
    "text": "Delta rule: which statement is correct?",
    "options": [
      "Incorrect interpretation of Delta rule",
      "Common misconception about Delta rule",
      "Correct principle related to Delta rule",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 49,
    "section": "Unit1_2_ANN",
    "text": "Delta rule: which statement is correct?",
    "options": [
      "Incorrect interpretation of Delta rule",
      "Common misconception about Delta rule",
      "Correct principle related to Delta rule",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 50,
    "section": "Unit1_2_ANN",
    "text": "Delta rule: which statement is correct?",
    "options": [
      "Incorrect interpretation of Delta rule",
      "Common misconception about Delta rule",
      "Correct principle related to Delta rule",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 51,
    "section": "Unit1_2_ANN",
    "text": "Gradient descent: which statement is correct?",
    "options": [
      "Incorrect interpretation of Gradient descent",
      "Common misconception about Gradient descent",
      "Correct principle related to Gradient descent",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 52,
    "section": "Unit1_2_ANN",
    "text": "Gradient descent: which statement is correct?",
    "options": [
      "Incorrect interpretation of Gradient descent",
      "Common misconception about Gradient descent",
      "Correct principle related to Gradient descent",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 53,
    "section": "Unit1_2_ANN",
    "text": "Gradient descent: which statement is correct?",
    "options": [
      "Incorrect interpretation of Gradient descent",
      "Common misconception about Gradient descent",
      "Correct principle related to Gradient descent",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 54,
    "section": "Unit1_2_ANN",
    "text": "Gradient descent: which statement is correct?",
    "options": [
      "Incorrect interpretation of Gradient descent",
      "Common misconception about Gradient descent",
      "Correct principle related to Gradient descent",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 55,
    "section": "Unit1_2_ANN",
    "text": "Gradient descent: which statement is correct?",
    "options": [
      "Incorrect interpretation of Gradient descent",
      "Common misconception about Gradient descent",
      "Correct principle related to Gradient descent",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 56,
    "section": "Unit1_2_ANN",
    "text": "Gradient descent: which statement is correct?",
    "options": [
      "Incorrect interpretation of Gradient descent",
      "Common misconception about Gradient descent",
      "Correct principle related to Gradient descent",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 57,
    "section": "Unit1_2_ANN",
    "text": "Gradient descent: which statement is correct?",
    "options": [
      "Incorrect interpretation of Gradient descent",
      "Common misconception about Gradient descent",
      "Correct principle related to Gradient descent",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 58,
    "section": "Unit1_2_ANN",
    "text": "Gradient descent: which statement is correct?",
    "options": [
      "Incorrect interpretation of Gradient descent",
      "Common misconception about Gradient descent",
      "Correct principle related to Gradient descent",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 59,
    "section": "Unit1_2_ANN",
    "text": "Gradient descent: which statement is correct?",
    "options": [
      "Incorrect interpretation of Gradient descent",
      "Common misconception about Gradient descent",
      "Correct principle related to Gradient descent",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 60,
    "section": "Unit1_2_ANN",
    "text": "Gradient descent: which statement is correct?",
    "options": [
      "Incorrect interpretation of Gradient descent",
      "Common misconception about Gradient descent",
      "Correct principle related to Gradient descent",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 61,
    "section": "Unit1_2_ANN",
    "text": "Loss functions: which statement is correct?",
    "options": [
      "Incorrect interpretation of Loss functions",
      "Common misconception about Loss functions",
      "Correct principle related to Loss functions",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 62,
    "section": "Unit1_2_ANN",
    "text": "Loss functions: which statement is correct?",
    "options": [
      "Incorrect interpretation of Loss functions",
      "Common misconception about Loss functions",
      "Correct principle related to Loss functions",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 63,
    "section": "Unit1_2_ANN",
    "text": "Loss functions: which statement is correct?",
    "options": [
      "Incorrect interpretation of Loss functions",
      "Common misconception about Loss functions",
      "Correct principle related to Loss functions",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 64,
    "section": "Unit1_2_ANN",
    "text": "Loss functions: which statement is correct?",
    "options": [
      "Incorrect interpretation of Loss functions",
      "Common misconception about Loss functions",
      "Correct principle related to Loss functions",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 65,
    "section": "Unit1_2_ANN",
    "text": "Loss functions: which statement is correct?",
    "options": [
      "Incorrect interpretation of Loss functions",
      "Common misconception about Loss functions",
      "Correct principle related to Loss functions",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 66,
    "section": "Unit1_2_ANN",
    "text": "Loss functions: which statement is correct?",
    "options": [
      "Incorrect interpretation of Loss functions",
      "Common misconception about Loss functions",
      "Correct principle related to Loss functions",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 67,
    "section": "Unit1_2_ANN",
    "text": "Loss functions: which statement is correct?",
    "options": [
      "Incorrect interpretation of Loss functions",
      "Common misconception about Loss functions",
      "Correct principle related to Loss functions",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 68,
    "section": "Unit1_2_ANN",
    "text": "Loss functions: which statement is correct?",
    "options": [
      "Incorrect interpretation of Loss functions",
      "Common misconception about Loss functions",
      "Correct principle related to Loss functions",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 69,
    "section": "Unit1_2_ANN",
    "text": "Loss functions: which statement is correct?",
    "options": [
      "Incorrect interpretation of Loss functions",
      "Common misconception about Loss functions",
      "Correct principle related to Loss functions",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 70,
    "section": "Unit1_2_ANN",
    "text": "Loss functions: which statement is correct?",
    "options": [
      "Incorrect interpretation of Loss functions",
      "Common misconception about Loss functions",
      "Correct principle related to Loss functions",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 71,
    "section": "Unit1_2_ANN",
    "text": "Overfitting in ANN: which statement is correct?",
    "options": [
      "Incorrect interpretation of Overfitting in ANN",
      "Common misconception about Overfitting in ANN",
      "Correct principle related to Overfitting in ANN",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 72,
    "section": "Unit1_2_ANN",
    "text": "Overfitting in ANN: which statement is correct?",
    "options": [
      "Incorrect interpretation of Overfitting in ANN",
      "Common misconception about Overfitting in ANN",
      "Correct principle related to Overfitting in ANN",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 73,
    "section": "Unit1_2_ANN",
    "text": "Overfitting in ANN: which statement is correct?",
    "options": [
      "Incorrect interpretation of Overfitting in ANN",
      "Common misconception about Overfitting in ANN",
      "Correct principle related to Overfitting in ANN",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 74,
    "section": "Unit1_2_ANN",
    "text": "Overfitting in ANN: which statement is correct?",
    "options": [
      "Incorrect interpretation of Overfitting in ANN",
      "Common misconception about Overfitting in ANN",
      "Correct principle related to Overfitting in ANN",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 75,
    "section": "Unit1_2_ANN",
    "text": "Overfitting in ANN: which statement is correct?",
    "options": [
      "Incorrect interpretation of Overfitting in ANN",
      "Common misconception about Overfitting in ANN",
      "Correct principle related to Overfitting in ANN",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 76,
    "section": "Unit1_2_ANN",
    "text": "Overfitting in ANN: which statement is correct?",
    "options": [
      "Incorrect interpretation of Overfitting in ANN",
      "Common misconception about Overfitting in ANN",
      "Correct principle related to Overfitting in ANN",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 77,
    "section": "Unit1_2_ANN",
    "text": "Overfitting in ANN: which statement is correct?",
    "options": [
      "Incorrect interpretation of Overfitting in ANN",
      "Common misconception about Overfitting in ANN",
      "Correct principle related to Overfitting in ANN",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 78,
    "section": "Unit1_2_ANN",
    "text": "Overfitting in ANN: which statement is correct?",
    "options": [
      "Incorrect interpretation of Overfitting in ANN",
      "Common misconception about Overfitting in ANN",
      "Correct principle related to Overfitting in ANN",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 79,
    "section": "Unit1_2_ANN",
    "text": "Overfitting in ANN: which statement is correct?",
    "options": [
      "Incorrect interpretation of Overfitting in ANN",
      "Common misconception about Overfitting in ANN",
      "Correct principle related to Overfitting in ANN",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 80,
    "section": "Unit1_2_ANN",
    "text": "Overfitting in ANN: which statement is correct?",
    "options": [
      "Incorrect interpretation of Overfitting in ANN",
      "Common misconception about Overfitting in ANN",
      "Correct principle related to Overfitting in ANN",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 81,
    "section": "Unit1_2_ANN",
    "text": "Generalization: which statement is correct?",
    "options": [
      "Incorrect interpretation of Generalization",
      "Common misconception about Generalization",
      "Correct principle related to Generalization",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 82,
    "section": "Unit1_2_ANN",
    "text": "Generalization: which statement is correct?",
    "options": [
      "Incorrect interpretation of Generalization",
      "Common misconception about Generalization",
      "Correct principle related to Generalization",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 83,
    "section": "Unit1_2_ANN",
    "text": "Generalization: which statement is correct?",
    "options": [
      "Incorrect interpretation of Generalization",
      "Common misconception about Generalization",
      "Correct principle related to Generalization",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 84,
    "section": "Unit1_2_ANN",
    "text": "Generalization: which statement is correct?",
    "options": [
      "Incorrect interpretation of Generalization",
      "Common misconception about Generalization",
      "Correct principle related to Generalization",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 85,
    "section": "Unit1_2_ANN",
    "text": "Generalization: which statement is correct?",
    "options": [
      "Incorrect interpretation of Generalization",
      "Common misconception about Generalization",
      "Correct principle related to Generalization",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 86,
    "section": "Unit1_2_ANN",
    "text": "Generalization: which statement is correct?",
    "options": [
      "Incorrect interpretation of Generalization",
      "Common misconception about Generalization",
      "Correct principle related to Generalization",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 87,
    "section": "Unit1_2_ANN",
    "text": "Generalization: which statement is correct?",
    "options": [
      "Incorrect interpretation of Generalization",
      "Common misconception about Generalization",
      "Correct principle related to Generalization",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 88,
    "section": "Unit1_2_ANN",
    "text": "Generalization: which statement is correct?",
    "options": [
      "Incorrect interpretation of Generalization",
      "Common misconception about Generalization",
      "Correct principle related to Generalization",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 89,
    "section": "Unit1_2_ANN",
    "text": "Generalization: which statement is correct?",
    "options": [
      "Incorrect interpretation of Generalization",
      "Common misconception about Generalization",
      "Correct principle related to Generalization",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 90,
    "section": "Unit1_2_ANN",
    "text": "Generalization: which statement is correct?",
    "options": [
      "Incorrect interpretation of Generalization",
      "Common misconception about Generalization",
      "Correct principle related to Generalization",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 91,
    "section": "Unit1_2_ANN",
    "text": "Network architecture: which statement is correct?",
    "options": [
      "Incorrect interpretation of Network architecture",
      "Common misconception about Network architecture",
      "Correct principle related to Network architecture",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 92,
    "section": "Unit1_2_ANN",
    "text": "Network architecture: which statement is correct?",
    "options": [
      "Incorrect interpretation of Network architecture",
      "Common misconception about Network architecture",
      "Correct principle related to Network architecture",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 93,
    "section": "Unit1_2_ANN",
    "text": "Network architecture: which statement is correct?",
    "options": [
      "Incorrect interpretation of Network architecture",
      "Common misconception about Network architecture",
      "Correct principle related to Network architecture",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 94,
    "section": "Unit1_2_ANN",
    "text": "Network architecture: which statement is correct?",
    "options": [
      "Incorrect interpretation of Network architecture",
      "Common misconception about Network architecture",
      "Correct principle related to Network architecture",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 95,
    "section": "Unit1_2_ANN",
    "text": "Network architecture: which statement is correct?",
    "options": [
      "Incorrect interpretation of Network architecture",
      "Common misconception about Network architecture",
      "Correct principle related to Network architecture",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 96,
    "section": "Unit1_2_ANN",
    "text": "Network architecture: which statement is correct?",
    "options": [
      "Incorrect interpretation of Network architecture",
      "Common misconception about Network architecture",
      "Correct principle related to Network architecture",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 97,
    "section": "Unit1_2_ANN",
    "text": "Network architecture: which statement is correct?",
    "options": [
      "Incorrect interpretation of Network architecture",
      "Common misconception about Network architecture",
      "Correct principle related to Network architecture",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 98,
    "section": "Unit1_2_ANN",
    "text": "Network architecture: which statement is correct?",
    "options": [
      "Incorrect interpretation of Network architecture",
      "Common misconception about Network architecture",
      "Correct principle related to Network architecture",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 99,
    "section": "Unit1_2_ANN",
    "text": "Network architecture: which statement is correct?",
    "options": [
      "Incorrect interpretation of Network architecture",
      "Common misconception about Network architecture",
      "Correct principle related to Network architecture",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 100,
    "section": "Unit1_2_ANN",
    "text": "Network architecture: which statement is correct?",
    "options": [
      "Incorrect interpretation of Network architecture",
      "Common misconception about Network architecture",
      "Correct principle related to Network architecture",
      "Unrelated concept"
    ],
    "answer": 2
  }
];