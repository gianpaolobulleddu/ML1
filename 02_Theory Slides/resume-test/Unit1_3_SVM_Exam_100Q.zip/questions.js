const QUESTIONS = [
  {
    "id": 1,
    "section": "Unit1_3_SVM",
    "text": "Maximum margin hyperplane: which statement is correct?",
    "options": [
      "Incorrect interpretation of Maximum margin hyperplane",
      "Common misconception about Maximum margin hyperplane",
      "Correct principle related to Maximum margin hyperplane",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 2,
    "section": "Unit1_3_SVM",
    "text": "Maximum margin hyperplane: which statement is correct?",
    "options": [
      "Incorrect interpretation of Maximum margin hyperplane",
      "Common misconception about Maximum margin hyperplane",
      "Correct principle related to Maximum margin hyperplane",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 3,
    "section": "Unit1_3_SVM",
    "text": "Maximum margin hyperplane: which statement is correct?",
    "options": [
      "Incorrect interpretation of Maximum margin hyperplane",
      "Common misconception about Maximum margin hyperplane",
      "Correct principle related to Maximum margin hyperplane",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 4,
    "section": "Unit1_3_SVM",
    "text": "Maximum margin hyperplane: which statement is correct?",
    "options": [
      "Incorrect interpretation of Maximum margin hyperplane",
      "Common misconception about Maximum margin hyperplane",
      "Correct principle related to Maximum margin hyperplane",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 5,
    "section": "Unit1_3_SVM",
    "text": "Maximum margin hyperplane: which statement is correct?",
    "options": [
      "Incorrect interpretation of Maximum margin hyperplane",
      "Common misconception about Maximum margin hyperplane",
      "Correct principle related to Maximum margin hyperplane",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 6,
    "section": "Unit1_3_SVM",
    "text": "Maximum margin hyperplane: which statement is correct?",
    "options": [
      "Incorrect interpretation of Maximum margin hyperplane",
      "Common misconception about Maximum margin hyperplane",
      "Correct principle related to Maximum margin hyperplane",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 7,
    "section": "Unit1_3_SVM",
    "text": "Maximum margin hyperplane: which statement is correct?",
    "options": [
      "Incorrect interpretation of Maximum margin hyperplane",
      "Common misconception about Maximum margin hyperplane",
      "Correct principle related to Maximum margin hyperplane",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 8,
    "section": "Unit1_3_SVM",
    "text": "Maximum margin hyperplane: which statement is correct?",
    "options": [
      "Incorrect interpretation of Maximum margin hyperplane",
      "Common misconception about Maximum margin hyperplane",
      "Correct principle related to Maximum margin hyperplane",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 9,
    "section": "Unit1_3_SVM",
    "text": "Maximum margin hyperplane: which statement is correct?",
    "options": [
      "Incorrect interpretation of Maximum margin hyperplane",
      "Common misconception about Maximum margin hyperplane",
      "Correct principle related to Maximum margin hyperplane",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 10,
    "section": "Unit1_3_SVM",
    "text": "Maximum margin hyperplane: which statement is correct?",
    "options": [
      "Incorrect interpretation of Maximum margin hyperplane",
      "Common misconception about Maximum margin hyperplane",
      "Correct principle related to Maximum margin hyperplane",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 11,
    "section": "Unit1_3_SVM",
    "text": "Support vectors: which statement is correct?",
    "options": [
      "Incorrect interpretation of Support vectors",
      "Common misconception about Support vectors",
      "Correct principle related to Support vectors",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 12,
    "section": "Unit1_3_SVM",
    "text": "Support vectors: which statement is correct?",
    "options": [
      "Incorrect interpretation of Support vectors",
      "Common misconception about Support vectors",
      "Correct principle related to Support vectors",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 13,
    "section": "Unit1_3_SVM",
    "text": "Support vectors: which statement is correct?",
    "options": [
      "Incorrect interpretation of Support vectors",
      "Common misconception about Support vectors",
      "Correct principle related to Support vectors",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 14,
    "section": "Unit1_3_SVM",
    "text": "Support vectors: which statement is correct?",
    "options": [
      "Incorrect interpretation of Support vectors",
      "Common misconception about Support vectors",
      "Correct principle related to Support vectors",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 15,
    "section": "Unit1_3_SVM",
    "text": "Support vectors: which statement is correct?",
    "options": [
      "Incorrect interpretation of Support vectors",
      "Common misconception about Support vectors",
      "Correct principle related to Support vectors",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 16,
    "section": "Unit1_3_SVM",
    "text": "Support vectors: which statement is correct?",
    "options": [
      "Incorrect interpretation of Support vectors",
      "Common misconception about Support vectors",
      "Correct principle related to Support vectors",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 17,
    "section": "Unit1_3_SVM",
    "text": "Support vectors: which statement is correct?",
    "options": [
      "Incorrect interpretation of Support vectors",
      "Common misconception about Support vectors",
      "Correct principle related to Support vectors",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 18,
    "section": "Unit1_3_SVM",
    "text": "Support vectors: which statement is correct?",
    "options": [
      "Incorrect interpretation of Support vectors",
      "Common misconception about Support vectors",
      "Correct principle related to Support vectors",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 19,
    "section": "Unit1_3_SVM",
    "text": "Support vectors: which statement is correct?",
    "options": [
      "Incorrect interpretation of Support vectors",
      "Common misconception about Support vectors",
      "Correct principle related to Support vectors",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 20,
    "section": "Unit1_3_SVM",
    "text": "Support vectors: which statement is correct?",
    "options": [
      "Incorrect interpretation of Support vectors",
      "Common misconception about Support vectors",
      "Correct principle related to Support vectors",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 21,
    "section": "Unit1_3_SVM",
    "text": "Linearly separable data: which statement is correct?",
    "options": [
      "Incorrect interpretation of Linearly separable data",
      "Common misconception about Linearly separable data",
      "Correct principle related to Linearly separable data",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 22,
    "section": "Unit1_3_SVM",
    "text": "Linearly separable data: which statement is correct?",
    "options": [
      "Incorrect interpretation of Linearly separable data",
      "Common misconception about Linearly separable data",
      "Correct principle related to Linearly separable data",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 23,
    "section": "Unit1_3_SVM",
    "text": "Linearly separable data: which statement is correct?",
    "options": [
      "Incorrect interpretation of Linearly separable data",
      "Common misconception about Linearly separable data",
      "Correct principle related to Linearly separable data",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 24,
    "section": "Unit1_3_SVM",
    "text": "Linearly separable data: which statement is correct?",
    "options": [
      "Incorrect interpretation of Linearly separable data",
      "Common misconception about Linearly separable data",
      "Correct principle related to Linearly separable data",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 25,
    "section": "Unit1_3_SVM",
    "text": "Linearly separable data: which statement is correct?",
    "options": [
      "Incorrect interpretation of Linearly separable data",
      "Common misconception about Linearly separable data",
      "Correct principle related to Linearly separable data",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 26,
    "section": "Unit1_3_SVM",
    "text": "Linearly separable data: which statement is correct?",
    "options": [
      "Incorrect interpretation of Linearly separable data",
      "Common misconception about Linearly separable data",
      "Correct principle related to Linearly separable data",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 27,
    "section": "Unit1_3_SVM",
    "text": "Linearly separable data: which statement is correct?",
    "options": [
      "Incorrect interpretation of Linearly separable data",
      "Common misconception about Linearly separable data",
      "Correct principle related to Linearly separable data",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 28,
    "section": "Unit1_3_SVM",
    "text": "Linearly separable data: which statement is correct?",
    "options": [
      "Incorrect interpretation of Linearly separable data",
      "Common misconception about Linearly separable data",
      "Correct principle related to Linearly separable data",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 29,
    "section": "Unit1_3_SVM",
    "text": "Linearly separable data: which statement is correct?",
    "options": [
      "Incorrect interpretation of Linearly separable data",
      "Common misconception about Linearly separable data",
      "Correct principle related to Linearly separable data",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 30,
    "section": "Unit1_3_SVM",
    "text": "Linearly separable data: which statement is correct?",
    "options": [
      "Incorrect interpretation of Linearly separable data",
      "Common misconception about Linearly separable data",
      "Correct principle related to Linearly separable data",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 31,
    "section": "Unit1_3_SVM",
    "text": "Soft margin: which statement is correct?",
    "options": [
      "Incorrect interpretation of Soft margin",
      "Common misconception about Soft margin",
      "Correct principle related to Soft margin",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 32,
    "section": "Unit1_3_SVM",
    "text": "Soft margin: which statement is correct?",
    "options": [
      "Incorrect interpretation of Soft margin",
      "Common misconception about Soft margin",
      "Correct principle related to Soft margin",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 33,
    "section": "Unit1_3_SVM",
    "text": "Soft margin: which statement is correct?",
    "options": [
      "Incorrect interpretation of Soft margin",
      "Common misconception about Soft margin",
      "Correct principle related to Soft margin",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 34,
    "section": "Unit1_3_SVM",
    "text": "Soft margin: which statement is correct?",
    "options": [
      "Incorrect interpretation of Soft margin",
      "Common misconception about Soft margin",
      "Correct principle related to Soft margin",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 35,
    "section": "Unit1_3_SVM",
    "text": "Soft margin: which statement is correct?",
    "options": [
      "Incorrect interpretation of Soft margin",
      "Common misconception about Soft margin",
      "Correct principle related to Soft margin",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 36,
    "section": "Unit1_3_SVM",
    "text": "Soft margin: which statement is correct?",
    "options": [
      "Incorrect interpretation of Soft margin",
      "Common misconception about Soft margin",
      "Correct principle related to Soft margin",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 37,
    "section": "Unit1_3_SVM",
    "text": "Soft margin: which statement is correct?",
    "options": [
      "Incorrect interpretation of Soft margin",
      "Common misconception about Soft margin",
      "Correct principle related to Soft margin",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 38,
    "section": "Unit1_3_SVM",
    "text": "Soft margin: which statement is correct?",
    "options": [
      "Incorrect interpretation of Soft margin",
      "Common misconception about Soft margin",
      "Correct principle related to Soft margin",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 39,
    "section": "Unit1_3_SVM",
    "text": "Soft margin: which statement is correct?",
    "options": [
      "Incorrect interpretation of Soft margin",
      "Common misconception about Soft margin",
      "Correct principle related to Soft margin",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 40,
    "section": "Unit1_3_SVM",
    "text": "Soft margin: which statement is correct?",
    "options": [
      "Incorrect interpretation of Soft margin",
      "Common misconception about Soft margin",
      "Correct principle related to Soft margin",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 41,
    "section": "Unit1_3_SVM",
    "text": "Slack variables: which statement is correct?",
    "options": [
      "Incorrect interpretation of Slack variables",
      "Common misconception about Slack variables",
      "Correct principle related to Slack variables",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 42,
    "section": "Unit1_3_SVM",
    "text": "Slack variables: which statement is correct?",
    "options": [
      "Incorrect interpretation of Slack variables",
      "Common misconception about Slack variables",
      "Correct principle related to Slack variables",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 43,
    "section": "Unit1_3_SVM",
    "text": "Slack variables: which statement is correct?",
    "options": [
      "Incorrect interpretation of Slack variables",
      "Common misconception about Slack variables",
      "Correct principle related to Slack variables",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 44,
    "section": "Unit1_3_SVM",
    "text": "Slack variables: which statement is correct?",
    "options": [
      "Incorrect interpretation of Slack variables",
      "Common misconception about Slack variables",
      "Correct principle related to Slack variables",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 45,
    "section": "Unit1_3_SVM",
    "text": "Slack variables: which statement is correct?",
    "options": [
      "Incorrect interpretation of Slack variables",
      "Common misconception about Slack variables",
      "Correct principle related to Slack variables",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 46,
    "section": "Unit1_3_SVM",
    "text": "Slack variables: which statement is correct?",
    "options": [
      "Incorrect interpretation of Slack variables",
      "Common misconception about Slack variables",
      "Correct principle related to Slack variables",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 47,
    "section": "Unit1_3_SVM",
    "text": "Slack variables: which statement is correct?",
    "options": [
      "Incorrect interpretation of Slack variables",
      "Common misconception about Slack variables",
      "Correct principle related to Slack variables",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 48,
    "section": "Unit1_3_SVM",
    "text": "Slack variables: which statement is correct?",
    "options": [
      "Incorrect interpretation of Slack variables",
      "Common misconception about Slack variables",
      "Correct principle related to Slack variables",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 49,
    "section": "Unit1_3_SVM",
    "text": "Slack variables: which statement is correct?",
    "options": [
      "Incorrect interpretation of Slack variables",
      "Common misconception about Slack variables",
      "Correct principle related to Slack variables",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 50,
    "section": "Unit1_3_SVM",
    "text": "Slack variables: which statement is correct?",
    "options": [
      "Incorrect interpretation of Slack variables",
      "Common misconception about Slack variables",
      "Correct principle related to Slack variables",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 51,
    "section": "Unit1_3_SVM",
    "text": "Kernel intuition: which statement is correct?",
    "options": [
      "Incorrect interpretation of Kernel intuition",
      "Common misconception about Kernel intuition",
      "Correct principle related to Kernel intuition",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 52,
    "section": "Unit1_3_SVM",
    "text": "Kernel intuition: which statement is correct?",
    "options": [
      "Incorrect interpretation of Kernel intuition",
      "Common misconception about Kernel intuition",
      "Correct principle related to Kernel intuition",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 53,
    "section": "Unit1_3_SVM",
    "text": "Kernel intuition: which statement is correct?",
    "options": [
      "Incorrect interpretation of Kernel intuition",
      "Common misconception about Kernel intuition",
      "Correct principle related to Kernel intuition",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 54,
    "section": "Unit1_3_SVM",
    "text": "Kernel intuition: which statement is correct?",
    "options": [
      "Incorrect interpretation of Kernel intuition",
      "Common misconception about Kernel intuition",
      "Correct principle related to Kernel intuition",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 55,
    "section": "Unit1_3_SVM",
    "text": "Kernel intuition: which statement is correct?",
    "options": [
      "Incorrect interpretation of Kernel intuition",
      "Common misconception about Kernel intuition",
      "Correct principle related to Kernel intuition",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 56,
    "section": "Unit1_3_SVM",
    "text": "Kernel intuition: which statement is correct?",
    "options": [
      "Incorrect interpretation of Kernel intuition",
      "Common misconception about Kernel intuition",
      "Correct principle related to Kernel intuition",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 57,
    "section": "Unit1_3_SVM",
    "text": "Kernel intuition: which statement is correct?",
    "options": [
      "Incorrect interpretation of Kernel intuition",
      "Common misconception about Kernel intuition",
      "Correct principle related to Kernel intuition",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 58,
    "section": "Unit1_3_SVM",
    "text": "Kernel intuition: which statement is correct?",
    "options": [
      "Incorrect interpretation of Kernel intuition",
      "Common misconception about Kernel intuition",
      "Correct principle related to Kernel intuition",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 59,
    "section": "Unit1_3_SVM",
    "text": "Kernel intuition: which statement is correct?",
    "options": [
      "Incorrect interpretation of Kernel intuition",
      "Common misconception about Kernel intuition",
      "Correct principle related to Kernel intuition",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 60,
    "section": "Unit1_3_SVM",
    "text": "Kernel intuition: which statement is correct?",
    "options": [
      "Incorrect interpretation of Kernel intuition",
      "Common misconception about Kernel intuition",
      "Correct principle related to Kernel intuition",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 61,
    "section": "Unit1_3_SVM",
    "text": "Geometric interpretation: which statement is correct?",
    "options": [
      "Incorrect interpretation of Geometric interpretation",
      "Common misconception about Geometric interpretation",
      "Correct principle related to Geometric interpretation",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 62,
    "section": "Unit1_3_SVM",
    "text": "Geometric interpretation: which statement is correct?",
    "options": [
      "Incorrect interpretation of Geometric interpretation",
      "Common misconception about Geometric interpretation",
      "Correct principle related to Geometric interpretation",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 63,
    "section": "Unit1_3_SVM",
    "text": "Geometric interpretation: which statement is correct?",
    "options": [
      "Incorrect interpretation of Geometric interpretation",
      "Common misconception about Geometric interpretation",
      "Correct principle related to Geometric interpretation",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 64,
    "section": "Unit1_3_SVM",
    "text": "Geometric interpretation: which statement is correct?",
    "options": [
      "Incorrect interpretation of Geometric interpretation",
      "Common misconception about Geometric interpretation",
      "Correct principle related to Geometric interpretation",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 65,
    "section": "Unit1_3_SVM",
    "text": "Geometric interpretation: which statement is correct?",
    "options": [
      "Incorrect interpretation of Geometric interpretation",
      "Common misconception about Geometric interpretation",
      "Correct principle related to Geometric interpretation",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 66,
    "section": "Unit1_3_SVM",
    "text": "Geometric interpretation: which statement is correct?",
    "options": [
      "Incorrect interpretation of Geometric interpretation",
      "Common misconception about Geometric interpretation",
      "Correct principle related to Geometric interpretation",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 67,
    "section": "Unit1_3_SVM",
    "text": "Geometric interpretation: which statement is correct?",
    "options": [
      "Incorrect interpretation of Geometric interpretation",
      "Common misconception about Geometric interpretation",
      "Correct principle related to Geometric interpretation",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 68,
    "section": "Unit1_3_SVM",
    "text": "Geometric interpretation: which statement is correct?",
    "options": [
      "Incorrect interpretation of Geometric interpretation",
      "Common misconception about Geometric interpretation",
      "Correct principle related to Geometric interpretation",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 69,
    "section": "Unit1_3_SVM",
    "text": "Geometric interpretation: which statement is correct?",
    "options": [
      "Incorrect interpretation of Geometric interpretation",
      "Common misconception about Geometric interpretation",
      "Correct principle related to Geometric interpretation",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 70,
    "section": "Unit1_3_SVM",
    "text": "Geometric interpretation: which statement is correct?",
    "options": [
      "Incorrect interpretation of Geometric interpretation",
      "Common misconception about Geometric interpretation",
      "Correct principle related to Geometric interpretation",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 71,
    "section": "Unit1_3_SVM",
    "text": "Generalization principle: which statement is correct?",
    "options": [
      "Incorrect interpretation of Generalization principle",
      "Common misconception about Generalization principle",
      "Correct principle related to Generalization principle",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 72,
    "section": "Unit1_3_SVM",
    "text": "Generalization principle: which statement is correct?",
    "options": [
      "Incorrect interpretation of Generalization principle",
      "Common misconception about Generalization principle",
      "Correct principle related to Generalization principle",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 73,
    "section": "Unit1_3_SVM",
    "text": "Generalization principle: which statement is correct?",
    "options": [
      "Incorrect interpretation of Generalization principle",
      "Common misconception about Generalization principle",
      "Correct principle related to Generalization principle",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 74,
    "section": "Unit1_3_SVM",
    "text": "Generalization principle: which statement is correct?",
    "options": [
      "Incorrect interpretation of Generalization principle",
      "Common misconception about Generalization principle",
      "Correct principle related to Generalization principle",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 75,
    "section": "Unit1_3_SVM",
    "text": "Generalization principle: which statement is correct?",
    "options": [
      "Incorrect interpretation of Generalization principle",
      "Common misconception about Generalization principle",
      "Correct principle related to Generalization principle",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 76,
    "section": "Unit1_3_SVM",
    "text": "Generalization principle: which statement is correct?",
    "options": [
      "Incorrect interpretation of Generalization principle",
      "Common misconception about Generalization principle",
      "Correct principle related to Generalization principle",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 77,
    "section": "Unit1_3_SVM",
    "text": "Generalization principle: which statement is correct?",
    "options": [
      "Incorrect interpretation of Generalization principle",
      "Common misconception about Generalization principle",
      "Correct principle related to Generalization principle",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 78,
    "section": "Unit1_3_SVM",
    "text": "Generalization principle: which statement is correct?",
    "options": [
      "Incorrect interpretation of Generalization principle",
      "Common misconception about Generalization principle",
      "Correct principle related to Generalization principle",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 79,
    "section": "Unit1_3_SVM",
    "text": "Generalization principle: which statement is correct?",
    "options": [
      "Incorrect interpretation of Generalization principle",
      "Common misconception about Generalization principle",
      "Correct principle related to Generalization principle",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 80,
    "section": "Unit1_3_SVM",
    "text": "Generalization principle: which statement is correct?",
    "options": [
      "Incorrect interpretation of Generalization principle",
      "Common misconception about Generalization principle",
      "Correct principle related to Generalization principle",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 81,
    "section": "Unit1_3_SVM",
    "text": "Regularization in SVM: which statement is correct?",
    "options": [
      "Incorrect interpretation of Regularization in SVM",
      "Common misconception about Regularization in SVM",
      "Correct principle related to Regularization in SVM",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 82,
    "section": "Unit1_3_SVM",
    "text": "Regularization in SVM: which statement is correct?",
    "options": [
      "Incorrect interpretation of Regularization in SVM",
      "Common misconception about Regularization in SVM",
      "Correct principle related to Regularization in SVM",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 83,
    "section": "Unit1_3_SVM",
    "text": "Regularization in SVM: which statement is correct?",
    "options": [
      "Incorrect interpretation of Regularization in SVM",
      "Common misconception about Regularization in SVM",
      "Correct principle related to Regularization in SVM",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 84,
    "section": "Unit1_3_SVM",
    "text": "Regularization in SVM: which statement is correct?",
    "options": [
      "Incorrect interpretation of Regularization in SVM",
      "Common misconception about Regularization in SVM",
      "Correct principle related to Regularization in SVM",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 85,
    "section": "Unit1_3_SVM",
    "text": "Regularization in SVM: which statement is correct?",
    "options": [
      "Incorrect interpretation of Regularization in SVM",
      "Common misconception about Regularization in SVM",
      "Correct principle related to Regularization in SVM",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 86,
    "section": "Unit1_3_SVM",
    "text": "Regularization in SVM: which statement is correct?",
    "options": [
      "Incorrect interpretation of Regularization in SVM",
      "Common misconception about Regularization in SVM",
      "Correct principle related to Regularization in SVM",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 87,
    "section": "Unit1_3_SVM",
    "text": "Regularization in SVM: which statement is correct?",
    "options": [
      "Incorrect interpretation of Regularization in SVM",
      "Common misconception about Regularization in SVM",
      "Correct principle related to Regularization in SVM",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 88,
    "section": "Unit1_3_SVM",
    "text": "Regularization in SVM: which statement is correct?",
    "options": [
      "Incorrect interpretation of Regularization in SVM",
      "Common misconception about Regularization in SVM",
      "Correct principle related to Regularization in SVM",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 89,
    "section": "Unit1_3_SVM",
    "text": "Regularization in SVM: which statement is correct?",
    "options": [
      "Incorrect interpretation of Regularization in SVM",
      "Common misconception about Regularization in SVM",
      "Correct principle related to Regularization in SVM",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 90,
    "section": "Unit1_3_SVM",
    "text": "Regularization in SVM: which statement is correct?",
    "options": [
      "Incorrect interpretation of Regularization in SVM",
      "Common misconception about Regularization in SVM",
      "Correct principle related to Regularization in SVM",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 91,
    "section": "Unit1_3_SVM",
    "text": "Decision boundary: which statement is correct?",
    "options": [
      "Incorrect interpretation of Decision boundary",
      "Common misconception about Decision boundary",
      "Correct principle related to Decision boundary",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 92,
    "section": "Unit1_3_SVM",
    "text": "Decision boundary: which statement is correct?",
    "options": [
      "Incorrect interpretation of Decision boundary",
      "Common misconception about Decision boundary",
      "Correct principle related to Decision boundary",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 93,
    "section": "Unit1_3_SVM",
    "text": "Decision boundary: which statement is correct?",
    "options": [
      "Incorrect interpretation of Decision boundary",
      "Common misconception about Decision boundary",
      "Correct principle related to Decision boundary",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 94,
    "section": "Unit1_3_SVM",
    "text": "Decision boundary: which statement is correct?",
    "options": [
      "Incorrect interpretation of Decision boundary",
      "Common misconception about Decision boundary",
      "Correct principle related to Decision boundary",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 95,
    "section": "Unit1_3_SVM",
    "text": "Decision boundary: which statement is correct?",
    "options": [
      "Incorrect interpretation of Decision boundary",
      "Common misconception about Decision boundary",
      "Correct principle related to Decision boundary",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 96,
    "section": "Unit1_3_SVM",
    "text": "Decision boundary: which statement is correct?",
    "options": [
      "Incorrect interpretation of Decision boundary",
      "Common misconception about Decision boundary",
      "Correct principle related to Decision boundary",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 97,
    "section": "Unit1_3_SVM",
    "text": "Decision boundary: which statement is correct?",
    "options": [
      "Incorrect interpretation of Decision boundary",
      "Common misconception about Decision boundary",
      "Correct principle related to Decision boundary",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 98,
    "section": "Unit1_3_SVM",
    "text": "Decision boundary: which statement is correct?",
    "options": [
      "Incorrect interpretation of Decision boundary",
      "Common misconception about Decision boundary",
      "Correct principle related to Decision boundary",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 99,
    "section": "Unit1_3_SVM",
    "text": "Decision boundary: which statement is correct?",
    "options": [
      "Incorrect interpretation of Decision boundary",
      "Common misconception about Decision boundary",
      "Correct principle related to Decision boundary",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 100,
    "section": "Unit1_3_SVM",
    "text": "Decision boundary: which statement is correct?",
    "options": [
      "Incorrect interpretation of Decision boundary",
      "Common misconception about Decision boundary",
      "Correct principle related to Decision boundary",
      "Unrelated concept"
    ],
    "answer": 2
  }
];