const QUESTIONS = [
  {
    "id": 1,
    "section": "Unit5_Complexity_Regularization",
    "text": "Bias-variance: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Bias-variance",
      "Common pitfall in Bias-variance",
      "Correct principle of Bias-variance",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 2,
    "section": "Unit5_Complexity_Regularization",
    "text": "Bias-variance: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Bias-variance",
      "Common pitfall in Bias-variance",
      "Correct principle of Bias-variance",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 3,
    "section": "Unit5_Complexity_Regularization",
    "text": "Bias-variance: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Bias-variance",
      "Common pitfall in Bias-variance",
      "Correct principle of Bias-variance",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 4,
    "section": "Unit5_Complexity_Regularization",
    "text": "Bias-variance: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Bias-variance",
      "Common pitfall in Bias-variance",
      "Correct principle of Bias-variance",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 5,
    "section": "Unit5_Complexity_Regularization",
    "text": "Bias-variance: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Bias-variance",
      "Common pitfall in Bias-variance",
      "Correct principle of Bias-variance",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 6,
    "section": "Unit5_Complexity_Regularization",
    "text": "Bias-variance: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Bias-variance",
      "Common pitfall in Bias-variance",
      "Correct principle of Bias-variance",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 7,
    "section": "Unit5_Complexity_Regularization",
    "text": "Bias-variance: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Bias-variance",
      "Common pitfall in Bias-variance",
      "Correct principle of Bias-variance",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 8,
    "section": "Unit5_Complexity_Regularization",
    "text": "Bias-variance: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Bias-variance",
      "Common pitfall in Bias-variance",
      "Correct principle of Bias-variance",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 9,
    "section": "Unit5_Complexity_Regularization",
    "text": "Bias-variance: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Bias-variance",
      "Common pitfall in Bias-variance",
      "Correct principle of Bias-variance",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 10,
    "section": "Unit5_Complexity_Regularization",
    "text": "Bias-variance: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Bias-variance",
      "Common pitfall in Bias-variance",
      "Correct principle of Bias-variance",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 11,
    "section": "Unit5_Complexity_Regularization",
    "text": "Overfitting: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Overfitting",
      "Common pitfall in Overfitting",
      "Correct principle of Overfitting",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 12,
    "section": "Unit5_Complexity_Regularization",
    "text": "Overfitting: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Overfitting",
      "Common pitfall in Overfitting",
      "Correct principle of Overfitting",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 13,
    "section": "Unit5_Complexity_Regularization",
    "text": "Overfitting: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Overfitting",
      "Common pitfall in Overfitting",
      "Correct principle of Overfitting",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 14,
    "section": "Unit5_Complexity_Regularization",
    "text": "Overfitting: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Overfitting",
      "Common pitfall in Overfitting",
      "Correct principle of Overfitting",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 15,
    "section": "Unit5_Complexity_Regularization",
    "text": "Overfitting: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Overfitting",
      "Common pitfall in Overfitting",
      "Correct principle of Overfitting",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 16,
    "section": "Unit5_Complexity_Regularization",
    "text": "Overfitting: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Overfitting",
      "Common pitfall in Overfitting",
      "Correct principle of Overfitting",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 17,
    "section": "Unit5_Complexity_Regularization",
    "text": "Overfitting: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Overfitting",
      "Common pitfall in Overfitting",
      "Correct principle of Overfitting",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 18,
    "section": "Unit5_Complexity_Regularization",
    "text": "Overfitting: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Overfitting",
      "Common pitfall in Overfitting",
      "Correct principle of Overfitting",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 19,
    "section": "Unit5_Complexity_Regularization",
    "text": "Overfitting: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Overfitting",
      "Common pitfall in Overfitting",
      "Correct principle of Overfitting",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 20,
    "section": "Unit5_Complexity_Regularization",
    "text": "Overfitting: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Overfitting",
      "Common pitfall in Overfitting",
      "Correct principle of Overfitting",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 21,
    "section": "Unit5_Complexity_Regularization",
    "text": "Underfitting: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Underfitting",
      "Common pitfall in Underfitting",
      "Correct principle of Underfitting",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 22,
    "section": "Unit5_Complexity_Regularization",
    "text": "Underfitting: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Underfitting",
      "Common pitfall in Underfitting",
      "Correct principle of Underfitting",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 23,
    "section": "Unit5_Complexity_Regularization",
    "text": "Underfitting: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Underfitting",
      "Common pitfall in Underfitting",
      "Correct principle of Underfitting",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 24,
    "section": "Unit5_Complexity_Regularization",
    "text": "Underfitting: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Underfitting",
      "Common pitfall in Underfitting",
      "Correct principle of Underfitting",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 25,
    "section": "Unit5_Complexity_Regularization",
    "text": "Underfitting: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Underfitting",
      "Common pitfall in Underfitting",
      "Correct principle of Underfitting",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 26,
    "section": "Unit5_Complexity_Regularization",
    "text": "Underfitting: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Underfitting",
      "Common pitfall in Underfitting",
      "Correct principle of Underfitting",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 27,
    "section": "Unit5_Complexity_Regularization",
    "text": "Underfitting: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Underfitting",
      "Common pitfall in Underfitting",
      "Correct principle of Underfitting",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 28,
    "section": "Unit5_Complexity_Regularization",
    "text": "Underfitting: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Underfitting",
      "Common pitfall in Underfitting",
      "Correct principle of Underfitting",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 29,
    "section": "Unit5_Complexity_Regularization",
    "text": "Underfitting: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Underfitting",
      "Common pitfall in Underfitting",
      "Correct principle of Underfitting",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 30,
    "section": "Unit5_Complexity_Regularization",
    "text": "Underfitting: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Underfitting",
      "Common pitfall in Underfitting",
      "Correct principle of Underfitting",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 31,
    "section": "Unit5_Complexity_Regularization",
    "text": "L1 regularization: Which statement is correct?",
    "options": [
      "Incorrect interpretation of L1 regularization",
      "Common pitfall in L1 regularization",
      "Correct principle of L1 regularization",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 32,
    "section": "Unit5_Complexity_Regularization",
    "text": "L1 regularization: Which statement is correct?",
    "options": [
      "Incorrect interpretation of L1 regularization",
      "Common pitfall in L1 regularization",
      "Correct principle of L1 regularization",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 33,
    "section": "Unit5_Complexity_Regularization",
    "text": "L1 regularization: Which statement is correct?",
    "options": [
      "Incorrect interpretation of L1 regularization",
      "Common pitfall in L1 regularization",
      "Correct principle of L1 regularization",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 34,
    "section": "Unit5_Complexity_Regularization",
    "text": "L1 regularization: Which statement is correct?",
    "options": [
      "Incorrect interpretation of L1 regularization",
      "Common pitfall in L1 regularization",
      "Correct principle of L1 regularization",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 35,
    "section": "Unit5_Complexity_Regularization",
    "text": "L1 regularization: Which statement is correct?",
    "options": [
      "Incorrect interpretation of L1 regularization",
      "Common pitfall in L1 regularization",
      "Correct principle of L1 regularization",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 36,
    "section": "Unit5_Complexity_Regularization",
    "text": "L1 regularization: Which statement is correct?",
    "options": [
      "Incorrect interpretation of L1 regularization",
      "Common pitfall in L1 regularization",
      "Correct principle of L1 regularization",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 37,
    "section": "Unit5_Complexity_Regularization",
    "text": "L1 regularization: Which statement is correct?",
    "options": [
      "Incorrect interpretation of L1 regularization",
      "Common pitfall in L1 regularization",
      "Correct principle of L1 regularization",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 38,
    "section": "Unit5_Complexity_Regularization",
    "text": "L1 regularization: Which statement is correct?",
    "options": [
      "Incorrect interpretation of L1 regularization",
      "Common pitfall in L1 regularization",
      "Correct principle of L1 regularization",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 39,
    "section": "Unit5_Complexity_Regularization",
    "text": "L1 regularization: Which statement is correct?",
    "options": [
      "Incorrect interpretation of L1 regularization",
      "Common pitfall in L1 regularization",
      "Correct principle of L1 regularization",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 40,
    "section": "Unit5_Complexity_Regularization",
    "text": "L1 regularization: Which statement is correct?",
    "options": [
      "Incorrect interpretation of L1 regularization",
      "Common pitfall in L1 regularization",
      "Correct principle of L1 regularization",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 41,
    "section": "Unit5_Complexity_Regularization",
    "text": "L2 regularization: Which statement is correct?",
    "options": [
      "Incorrect interpretation of L2 regularization",
      "Common pitfall in L2 regularization",
      "Correct principle of L2 regularization",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 42,
    "section": "Unit5_Complexity_Regularization",
    "text": "L2 regularization: Which statement is correct?",
    "options": [
      "Incorrect interpretation of L2 regularization",
      "Common pitfall in L2 regularization",
      "Correct principle of L2 regularization",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 43,
    "section": "Unit5_Complexity_Regularization",
    "text": "L2 regularization: Which statement is correct?",
    "options": [
      "Incorrect interpretation of L2 regularization",
      "Common pitfall in L2 regularization",
      "Correct principle of L2 regularization",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 44,
    "section": "Unit5_Complexity_Regularization",
    "text": "L2 regularization: Which statement is correct?",
    "options": [
      "Incorrect interpretation of L2 regularization",
      "Common pitfall in L2 regularization",
      "Correct principle of L2 regularization",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 45,
    "section": "Unit5_Complexity_Regularization",
    "text": "L2 regularization: Which statement is correct?",
    "options": [
      "Incorrect interpretation of L2 regularization",
      "Common pitfall in L2 regularization",
      "Correct principle of L2 regularization",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 46,
    "section": "Unit5_Complexity_Regularization",
    "text": "L2 regularization: Which statement is correct?",
    "options": [
      "Incorrect interpretation of L2 regularization",
      "Common pitfall in L2 regularization",
      "Correct principle of L2 regularization",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 47,
    "section": "Unit5_Complexity_Regularization",
    "text": "L2 regularization: Which statement is correct?",
    "options": [
      "Incorrect interpretation of L2 regularization",
      "Common pitfall in L2 regularization",
      "Correct principle of L2 regularization",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 48,
    "section": "Unit5_Complexity_Regularization",
    "text": "L2 regularization: Which statement is correct?",
    "options": [
      "Incorrect interpretation of L2 regularization",
      "Common pitfall in L2 regularization",
      "Correct principle of L2 regularization",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 49,
    "section": "Unit5_Complexity_Regularization",
    "text": "L2 regularization: Which statement is correct?",
    "options": [
      "Incorrect interpretation of L2 regularization",
      "Common pitfall in L2 regularization",
      "Correct principle of L2 regularization",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 50,
    "section": "Unit5_Complexity_Regularization",
    "text": "L2 regularization: Which statement is correct?",
    "options": [
      "Incorrect interpretation of L2 regularization",
      "Common pitfall in L2 regularization",
      "Correct principle of L2 regularization",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 51,
    "section": "Unit5_Complexity_Regularization",
    "text": "VC dimension: Which statement is correct?",
    "options": [
      "Incorrect interpretation of VC dimension",
      "Common pitfall in VC dimension",
      "Correct principle of VC dimension",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 52,
    "section": "Unit5_Complexity_Regularization",
    "text": "VC dimension: Which statement is correct?",
    "options": [
      "Incorrect interpretation of VC dimension",
      "Common pitfall in VC dimension",
      "Correct principle of VC dimension",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 53,
    "section": "Unit5_Complexity_Regularization",
    "text": "VC dimension: Which statement is correct?",
    "options": [
      "Incorrect interpretation of VC dimension",
      "Common pitfall in VC dimension",
      "Correct principle of VC dimension",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 54,
    "section": "Unit5_Complexity_Regularization",
    "text": "VC dimension: Which statement is correct?",
    "options": [
      "Incorrect interpretation of VC dimension",
      "Common pitfall in VC dimension",
      "Correct principle of VC dimension",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 55,
    "section": "Unit5_Complexity_Regularization",
    "text": "VC dimension: Which statement is correct?",
    "options": [
      "Incorrect interpretation of VC dimension",
      "Common pitfall in VC dimension",
      "Correct principle of VC dimension",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 56,
    "section": "Unit5_Complexity_Regularization",
    "text": "VC dimension: Which statement is correct?",
    "options": [
      "Incorrect interpretation of VC dimension",
      "Common pitfall in VC dimension",
      "Correct principle of VC dimension",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 57,
    "section": "Unit5_Complexity_Regularization",
    "text": "VC dimension: Which statement is correct?",
    "options": [
      "Incorrect interpretation of VC dimension",
      "Common pitfall in VC dimension",
      "Correct principle of VC dimension",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 58,
    "section": "Unit5_Complexity_Regularization",
    "text": "VC dimension: Which statement is correct?",
    "options": [
      "Incorrect interpretation of VC dimension",
      "Common pitfall in VC dimension",
      "Correct principle of VC dimension",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 59,
    "section": "Unit5_Complexity_Regularization",
    "text": "VC dimension: Which statement is correct?",
    "options": [
      "Incorrect interpretation of VC dimension",
      "Common pitfall in VC dimension",
      "Correct principle of VC dimension",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 60,
    "section": "Unit5_Complexity_Regularization",
    "text": "VC dimension: Which statement is correct?",
    "options": [
      "Incorrect interpretation of VC dimension",
      "Common pitfall in VC dimension",
      "Correct principle of VC dimension",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 61,
    "section": "Unit5_Complexity_Regularization",
    "text": "Early stopping: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Early stopping",
      "Common pitfall in Early stopping",
      "Correct principle of Early stopping",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 62,
    "section": "Unit5_Complexity_Regularization",
    "text": "Early stopping: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Early stopping",
      "Common pitfall in Early stopping",
      "Correct principle of Early stopping",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 63,
    "section": "Unit5_Complexity_Regularization",
    "text": "Early stopping: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Early stopping",
      "Common pitfall in Early stopping",
      "Correct principle of Early stopping",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 64,
    "section": "Unit5_Complexity_Regularization",
    "text": "Early stopping: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Early stopping",
      "Common pitfall in Early stopping",
      "Correct principle of Early stopping",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 65,
    "section": "Unit5_Complexity_Regularization",
    "text": "Early stopping: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Early stopping",
      "Common pitfall in Early stopping",
      "Correct principle of Early stopping",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 66,
    "section": "Unit5_Complexity_Regularization",
    "text": "Early stopping: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Early stopping",
      "Common pitfall in Early stopping",
      "Correct principle of Early stopping",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 67,
    "section": "Unit5_Complexity_Regularization",
    "text": "Early stopping: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Early stopping",
      "Common pitfall in Early stopping",
      "Correct principle of Early stopping",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 68,
    "section": "Unit5_Complexity_Regularization",
    "text": "Early stopping: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Early stopping",
      "Common pitfall in Early stopping",
      "Correct principle of Early stopping",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 69,
    "section": "Unit5_Complexity_Regularization",
    "text": "Early stopping: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Early stopping",
      "Common pitfall in Early stopping",
      "Correct principle of Early stopping",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 70,
    "section": "Unit5_Complexity_Regularization",
    "text": "Early stopping: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Early stopping",
      "Common pitfall in Early stopping",
      "Correct principle of Early stopping",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 71,
    "section": "Unit5_Complexity_Regularization",
    "text": "Model capacity: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Model capacity",
      "Common pitfall in Model capacity",
      "Correct principle of Model capacity",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 72,
    "section": "Unit5_Complexity_Regularization",
    "text": "Model capacity: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Model capacity",
      "Common pitfall in Model capacity",
      "Correct principle of Model capacity",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 73,
    "section": "Unit5_Complexity_Regularization",
    "text": "Model capacity: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Model capacity",
      "Common pitfall in Model capacity",
      "Correct principle of Model capacity",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 74,
    "section": "Unit5_Complexity_Regularization",
    "text": "Model capacity: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Model capacity",
      "Common pitfall in Model capacity",
      "Correct principle of Model capacity",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 75,
    "section": "Unit5_Complexity_Regularization",
    "text": "Model capacity: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Model capacity",
      "Common pitfall in Model capacity",
      "Correct principle of Model capacity",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 76,
    "section": "Unit5_Complexity_Regularization",
    "text": "Model capacity: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Model capacity",
      "Common pitfall in Model capacity",
      "Correct principle of Model capacity",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 77,
    "section": "Unit5_Complexity_Regularization",
    "text": "Model capacity: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Model capacity",
      "Common pitfall in Model capacity",
      "Correct principle of Model capacity",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 78,
    "section": "Unit5_Complexity_Regularization",
    "text": "Model capacity: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Model capacity",
      "Common pitfall in Model capacity",
      "Correct principle of Model capacity",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 79,
    "section": "Unit5_Complexity_Regularization",
    "text": "Model capacity: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Model capacity",
      "Common pitfall in Model capacity",
      "Correct principle of Model capacity",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 80,
    "section": "Unit5_Complexity_Regularization",
    "text": "Model capacity: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Model capacity",
      "Common pitfall in Model capacity",
      "Correct principle of Model capacity",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 81,
    "section": "Unit5_Complexity_Regularization",
    "text": "Hyperparameters: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Hyperparameters",
      "Common pitfall in Hyperparameters",
      "Correct principle of Hyperparameters",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 82,
    "section": "Unit5_Complexity_Regularization",
    "text": "Hyperparameters: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Hyperparameters",
      "Common pitfall in Hyperparameters",
      "Correct principle of Hyperparameters",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 83,
    "section": "Unit5_Complexity_Regularization",
    "text": "Hyperparameters: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Hyperparameters",
      "Common pitfall in Hyperparameters",
      "Correct principle of Hyperparameters",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 84,
    "section": "Unit5_Complexity_Regularization",
    "text": "Hyperparameters: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Hyperparameters",
      "Common pitfall in Hyperparameters",
      "Correct principle of Hyperparameters",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 85,
    "section": "Unit5_Complexity_Regularization",
    "text": "Hyperparameters: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Hyperparameters",
      "Common pitfall in Hyperparameters",
      "Correct principle of Hyperparameters",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 86,
    "section": "Unit5_Complexity_Regularization",
    "text": "Hyperparameters: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Hyperparameters",
      "Common pitfall in Hyperparameters",
      "Correct principle of Hyperparameters",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 87,
    "section": "Unit5_Complexity_Regularization",
    "text": "Hyperparameters: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Hyperparameters",
      "Common pitfall in Hyperparameters",
      "Correct principle of Hyperparameters",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 88,
    "section": "Unit5_Complexity_Regularization",
    "text": "Hyperparameters: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Hyperparameters",
      "Common pitfall in Hyperparameters",
      "Correct principle of Hyperparameters",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 89,
    "section": "Unit5_Complexity_Regularization",
    "text": "Hyperparameters: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Hyperparameters",
      "Common pitfall in Hyperparameters",
      "Correct principle of Hyperparameters",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 90,
    "section": "Unit5_Complexity_Regularization",
    "text": "Hyperparameters: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Hyperparameters",
      "Common pitfall in Hyperparameters",
      "Correct principle of Hyperparameters",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 91,
    "section": "Unit5_Complexity_Regularization",
    "text": "Generalization: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Generalization",
      "Common pitfall in Generalization",
      "Correct principle of Generalization",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 92,
    "section": "Unit5_Complexity_Regularization",
    "text": "Generalization: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Generalization",
      "Common pitfall in Generalization",
      "Correct principle of Generalization",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 93,
    "section": "Unit5_Complexity_Regularization",
    "text": "Generalization: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Generalization",
      "Common pitfall in Generalization",
      "Correct principle of Generalization",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 94,
    "section": "Unit5_Complexity_Regularization",
    "text": "Generalization: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Generalization",
      "Common pitfall in Generalization",
      "Correct principle of Generalization",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 95,
    "section": "Unit5_Complexity_Regularization",
    "text": "Generalization: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Generalization",
      "Common pitfall in Generalization",
      "Correct principle of Generalization",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 96,
    "section": "Unit5_Complexity_Regularization",
    "text": "Generalization: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Generalization",
      "Common pitfall in Generalization",
      "Correct principle of Generalization",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 97,
    "section": "Unit5_Complexity_Regularization",
    "text": "Generalization: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Generalization",
      "Common pitfall in Generalization",
      "Correct principle of Generalization",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 98,
    "section": "Unit5_Complexity_Regularization",
    "text": "Generalization: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Generalization",
      "Common pitfall in Generalization",
      "Correct principle of Generalization",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 99,
    "section": "Unit5_Complexity_Regularization",
    "text": "Generalization: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Generalization",
      "Common pitfall in Generalization",
      "Correct principle of Generalization",
      "Unrelated concept"
    ],
    "answer": 2
  },
  {
    "id": 100,
    "section": "Unit5_Complexity_Regularization",
    "text": "Generalization: Which statement is correct?",
    "options": [
      "Incorrect interpretation of Generalization",
      "Common pitfall in Generalization",
      "Correct principle of Generalization",
      "Unrelated concept"
    ],
    "answer": 2
  }
];