const QUESTIONS = [
  {
    "id": 1,
    "section": "Preprocessing",
    "text": "Z-score normalization is:",
    "options": [
      "$(x-\\min)/(\\max-\\min)$",
      "$(x-\\mu)/\\sigma$",
      "$x/\\|x\\|$",
      "$\\log x$"
    ],
    "answer": 1
  },
  {
    "id": 2,
    "section": "Trees",
    "text": "Entropy is defined as:",
    "options": [
      "$\\sum p_i$",
      "$-\\sum p_i\\log_2 p_i$",
      "$\\sum p_i^2$",
      "$\\log p$"
    ],
    "answer": 1
  },
  {
    "id": 3,
    "section": "Evaluation",
    "text": "Precision is:",
    "options": [
      "$TP/(TP+FN)$",
      "$TP/(TP+FP)$",
      "$TN/(TN+FP)$",
      "$FP/(FP+FN)$"
    ],
    "answer": 1
  },
  {
    "id": 4,
    "section": "Unsupervised",
    "text": "k-means minimizes:",
    "options": [
      "$\\sum\\|x_i\\|$",
      "$\\sum\\|x_i-\\mu_{c_i}\\|^2$",
      "$\\sum\\|x_i-x_j\\|$",
      "$\\sum\\mu_i$"
    ],
    "answer": 1
  },
  {
    "id": 5,
    "section": "Unsupervised",
    "text": "k-means minimizes:",
    "options": [
      "$\\sum\\|x_i\\|$",
      "$\\sum\\|x_i-\\mu_{c_i}\\|^2$",
      "$\\sum\\|x_i-x_j\\|$",
      "$\\sum\\mu_i$"
    ],
    "answer": 1
  },
  {
    "id": 6,
    "section": "Evaluation",
    "text": "Precision is:",
    "options": [
      "$TP/(TP+FN)$",
      "$TP/(TP+FP)$",
      "$TN/(TN+FP)$",
      "$FP/(FP+FN)$"
    ],
    "answer": 1
  },
  {
    "id": 7,
    "section": "Trees",
    "text": "Entropy is defined as:",
    "options": [
      "$\\sum p_i$",
      "$-\\sum p_i\\log_2 p_i$",
      "$\\sum p_i^2$",
      "$\\log p$"
    ],
    "answer": 1
  },
  {
    "id": 8,
    "section": "Regression Trees",
    "text": "Regression tree leaves predict:",
    "options": [
      "Mode",
      "Mean",
      "Median",
      "Linear model"
    ],
    "answer": 1
  },
  {
    "id": 9,
    "section": "ANN",
    "text": "Given $z=w_0+\\sum_i w_ix_i$, what is $w_0$?",
    "options": [
      "Learning rate",
      "Bias",
      "Loss",
      "Target"
    ],
    "answer": 1
  },
  {
    "id": 10,
    "section": "ANN",
    "text": "Given $z=w_0+\\sum_i w_ix_i$, what is $w_0$?",
    "options": [
      "Learning rate",
      "Bias",
      "Loss",
      "Target"
    ],
    "answer": 1
  },
  {
    "id": 11,
    "section": "Regularization",
    "text": "$L_1$ regularization encourages:",
    "options": [
      "Dense weights",
      "Sparse weights",
      "High variance",
      "Overfitting"
    ],
    "answer": 1
  },
  {
    "id": 12,
    "section": "SVM",
    "text": "The SVM margin is equal to:",
    "options": [
      "$\\|w\\|$",
      "$1/\\|w\\|$",
      "$2/\\|w\\|$",
      "$\\|x\\|$"
    ],
    "answer": 2
  },
  {
    "id": 13,
    "section": "Trees",
    "text": "Entropy is defined as:",
    "options": [
      "$\\sum p_i$",
      "$-\\sum p_i\\log_2 p_i$",
      "$\\sum p_i^2$",
      "$\\log p$"
    ],
    "answer": 1
  },
  {
    "id": 14,
    "section": "Evaluation",
    "text": "Precision is:",
    "options": [
      "$TP/(TP+FN)$",
      "$TP/(TP+FP)$",
      "$TN/(TN+FP)$",
      "$FP/(FP+FN)$"
    ],
    "answer": 1
  },
  {
    "id": 15,
    "section": "Preprocessing",
    "text": "Z-score normalization is:",
    "options": [
      "$(x-\\min)/(\\max-\\min)$",
      "$(x-\\mu)/\\sigma$",
      "$x/\\|x\\|$",
      "$\\log x$"
    ],
    "answer": 1
  },
  {
    "id": 16,
    "section": "ANN",
    "text": "Given $z=w_0+\\sum_i w_ix_i$, what is $w_0$?",
    "options": [
      "Learning rate",
      "Bias",
      "Loss",
      "Target"
    ],
    "answer": 1
  },
  {
    "id": 17,
    "section": "kNN",
    "text": "Euclidean distance is:",
    "options": [
      "$\\sum|x_i-z_i|$",
      "$\\sqrt{\\sum(x_i-z_i)^2}$",
      "$x^Tz$",
      "$\\max|x_i-z_i|$"
    ],
    "answer": 1
  },
  {
    "id": 18,
    "section": "SVM",
    "text": "The SVM margin is equal to:",
    "options": [
      "$\\|w\\|$",
      "$1/\\|w\\|$",
      "$2/\\|w\\|$",
      "$\\|x\\|$"
    ],
    "answer": 2
  },
  {
    "id": 19,
    "section": "kNN",
    "text": "Euclidean distance is:",
    "options": [
      "$\\sum|x_i-z_i|$",
      "$\\sqrt{\\sum(x_i-z_i)^2}$",
      "$x^Tz$",
      "$\\max|x_i-z_i|$"
    ],
    "answer": 1
  },
  {
    "id": 20,
    "section": "Unsupervised",
    "text": "k-means minimizes:",
    "options": [
      "$\\sum\\|x_i\\|$",
      "$\\sum\\|x_i-\\mu_{c_i}\\|^2$",
      "$\\sum\\|x_i-x_j\\|$",
      "$\\sum\\mu_i$"
    ],
    "answer": 1
  },
  {
    "id": 21,
    "section": "SVM",
    "text": "The SVM margin is equal to:",
    "options": [
      "$\\|w\\|$",
      "$1/\\|w\\|$",
      "$2/\\|w\\|$",
      "$\\|x\\|$"
    ],
    "answer": 2
  },
  {
    "id": 22,
    "section": "Unsupervised",
    "text": "k-means minimizes:",
    "options": [
      "$\\sum\\|x_i\\|$",
      "$\\sum\\|x_i-\\mu_{c_i}\\|^2$",
      "$\\sum\\|x_i-x_j\\|$",
      "$\\sum\\mu_i$"
    ],
    "answer": 1
  },
  {
    "id": 23,
    "section": "SVM",
    "text": "The SVM margin is equal to:",
    "options": [
      "$\\|w\\|$",
      "$1/\\|w\\|$",
      "$2/\\|w\\|$",
      "$\\|x\\|$"
    ],
    "answer": 2
  },
  {
    "id": 24,
    "section": "ANN",
    "text": "Given $z=w_0+\\sum_i w_ix_i$, what is $w_0$?",
    "options": [
      "Learning rate",
      "Bias",
      "Loss",
      "Target"
    ],
    "answer": 1
  },
  {
    "id": 25,
    "section": "ANN",
    "text": "Given $z=w_0+\\sum_i w_ix_i$, what is $w_0$?",
    "options": [
      "Learning rate",
      "Bias",
      "Loss",
      "Target"
    ],
    "answer": 1
  },
  {
    "id": 26,
    "section": "Regularization",
    "text": "$L_1$ regularization encourages:",
    "options": [
      "Dense weights",
      "Sparse weights",
      "High variance",
      "Overfitting"
    ],
    "answer": 1
  },
  {
    "id": 27,
    "section": "Regularization",
    "text": "$L_1$ regularization encourages:",
    "options": [
      "Dense weights",
      "Sparse weights",
      "High variance",
      "Overfitting"
    ],
    "answer": 1
  },
  {
    "id": 28,
    "section": "Regression Trees",
    "text": "Regression tree leaves predict:",
    "options": [
      "Mode",
      "Mean",
      "Median",
      "Linear model"
    ],
    "answer": 1
  },
  {
    "id": 29,
    "section": "kNN",
    "text": "Euclidean distance is:",
    "options": [
      "$\\sum|x_i-z_i|$",
      "$\\sqrt{\\sum(x_i-z_i)^2}$",
      "$x^Tz$",
      "$\\max|x_i-z_i|$"
    ],
    "answer": 1
  },
  {
    "id": 30,
    "section": "Preprocessing",
    "text": "Z-score normalization is:",
    "options": [
      "$(x-\\min)/(\\max-\\min)$",
      "$(x-\\mu)/\\sigma$",
      "$x/\\|x\\|$",
      "$\\log x$"
    ],
    "answer": 1
  },
  {
    "id": 31,
    "section": "Evaluation",
    "text": "Precision is:",
    "options": [
      "$TP/(TP+FN)$",
      "$TP/(TP+FP)$",
      "$TN/(TN+FP)$",
      "$FP/(FP+FN)$"
    ],
    "answer": 1
  },
  {
    "id": 32,
    "section": "Trees",
    "text": "Entropy is defined as:",
    "options": [
      "$\\sum p_i$",
      "$-\\sum p_i\\log_2 p_i$",
      "$\\sum p_i^2$",
      "$\\log p$"
    ],
    "answer": 1
  },
  {
    "id": 33,
    "section": "Regression Trees",
    "text": "Regression tree leaves predict:",
    "options": [
      "Mode",
      "Mean",
      "Median",
      "Linear model"
    ],
    "answer": 1
  },
  {
    "id": 34,
    "section": "Regression Trees",
    "text": "Regression tree leaves predict:",
    "options": [
      "Mode",
      "Mean",
      "Median",
      "Linear model"
    ],
    "answer": 1
  },
  {
    "id": 35,
    "section": "kNN",
    "text": "Euclidean distance is:",
    "options": [
      "$\\sum|x_i-z_i|$",
      "$\\sqrt{\\sum(x_i-z_i)^2}$",
      "$x^Tz$",
      "$\\max|x_i-z_i|$"
    ],
    "answer": 1
  },
  {
    "id": 36,
    "section": "SVM",
    "text": "The SVM margin is equal to:",
    "options": [
      "$\\|w\\|$",
      "$1/\\|w\\|$",
      "$2/\\|w\\|$",
      "$\\|x\\|$"
    ],
    "answer": 2
  },
  {
    "id": 37,
    "section": "Preprocessing",
    "text": "Z-score normalization is:",
    "options": [
      "$(x-\\min)/(\\max-\\min)$",
      "$(x-\\mu)/\\sigma$",
      "$x/\\|x\\|$",
      "$\\log x$"
    ],
    "answer": 1
  },
  {
    "id": 38,
    "section": "Regression Trees",
    "text": "Regression tree leaves predict:",
    "options": [
      "Mode",
      "Mean",
      "Median",
      "Linear model"
    ],
    "answer": 1
  },
  {
    "id": 39,
    "section": "Trees",
    "text": "Entropy is defined as:",
    "options": [
      "$\\sum p_i$",
      "$-\\sum p_i\\log_2 p_i$",
      "$\\sum p_i^2$",
      "$\\log p$"
    ],
    "answer": 1
  },
  {
    "id": 40,
    "section": "Regularization",
    "text": "$L_1$ regularization encourages:",
    "options": [
      "Dense weights",
      "Sparse weights",
      "High variance",
      "Overfitting"
    ],
    "answer": 1
  }
];